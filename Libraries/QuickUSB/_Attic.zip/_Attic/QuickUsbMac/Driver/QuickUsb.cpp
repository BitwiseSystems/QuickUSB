/*=============================================================================
 
 Title		: QuickUsb.cpp
 Description: QuickUSB Mac Driver
 Notes		: None
 
 Copyright 2010 Bitwise Systems.  All rights reserved.
 This software contains confidential information and trade secrets of
 Bitwise Systems and is protected by United States and international
 copyright laws.  Use, disclosure, or reproduction is prohibited without
 the prior express written permission of Bitwise Systems, except as agreed
 in the QuickUSB Plug-In Module license agreement.
 
 Use, duplication or disclosure by the U.S. Government is subject to
 restrictions as provided in DFARS 227.7202-1(a) and 227.7202-3(a)
 (1998), and FAR 12.212, as applicable.  Bitwise Systems, 6489 Calle Real,
 Suite E, Goleta, CA 93117.
 
 Bitwise Sytems
 6489 Calle Real, Suite E
 Goleta, CA 93117
 Voice	: (805) 683-6469
 Fax	: (805) 683-4833
 Web	: www.bitwisesys.com
 email	: support@bitwisesys.com
 
 $History: QuickUsb.cpp$
 
 *****************  Version 01 *****************
 User: Anh Nguyen  Data: 08/09/10  Time: 12:00p
 Updated in $/Projects/Bitwise/QuickUSB/Library/Software/QuickUsbMac/Driver
 
=============================================================================*/

// C and system headers
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>

// IOKit headers
#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOCFPlugIn.h>
#include <IOKit/usb/IOUSBLib.h>
#include <IOKit/usb/USB.h>

// QuickUSB headers
#include "QuickUsb.h"
#include "QuickUsbVersion.h"


// Driver version
#define QUSB_DRIVER_MAJOR_VERSION		02
#define QUSB_DRIVER_MINOR_VERSION		15
#define QUSB_DRIVER_BUILD_VERSION		00

// Bitwise vendor ID and QuickUSB product ID
#define BITWISE_VID						0x0FBB
#define QUSB2_PID						0x0001

// QuickUSB device base name and string
#define QUICKUSB_DEVICE_BASENAME		"QUSB"
#define QUICKUSB_DEVICE_STRING			"Bitwise Systems"

// Max values
#define MAX_WRITEDATA_SIZE				(16*1024*1024)
#define MAX_READDATA_SIZE				(16*1024*1024)
#define MAX_CNTL_XFER_SIZE				64
#define MAX_DEVICENUM					128
#define MAX_DEVICEPATH					128
#define MAX_STRINGDESCRIPTOR			128

// QuickUSB string descriptor indices
#define QUICKUSB_SERIAL_PERM			0x05
#define QUICKUSB_MAKE_PERM				0x06

// QuickUSB vendor specific requests
#define FIRMWARE_LOAD					0xA0
#define QUICKUSB_EEPROM					0xA9
#define QUICKUSB_SETTING				0xB0
#define QUICKUSB_FPGA					0xB1
#define QUICKUSB_COMMAND				0xB2
#define QUICKUSB_PORT					0xB3
#define QUICKUSB_RS232					0xB4
#define QUICKUSB_I2C					0xB5
#define QUICKUSB_SPI					0xB6
#define QUICKUSB_READDATALEN			0xB7
#define QUICKUSB_TIMER					0xB8
#define QUICKUSB_JTAG					0xB9
#define QUICKUSB_SCRIPT					0xBF

// QuickUSB FPGA commands (wIndex values for QUICKUSB_FPGA)
#define FPGA_START						0
#define FPGA_WRITE						1
#define FPGA_ISCONFIG					3

// QuickUSB RS-232 commands (wIndex values for QUICKUSB_PORT)
#define PORT_GETSET_DIR					0
#define PORT_READWRITE					1

// QuickUSB RS-232 commands (wIndex values for QUICKUSB_RS232)
#define RS232_SETGET_BAUD				0
#define RS232_SETGET_NUM				1
#define RS232_READWRITE					2

// QuickUSB I2C commands (wIndex values for QUICKUSB_I2C)
#define I2C_READWRITE					0

// QuickUSB SPI commands (wIndex values for QUICKUSB_SPI)
#define SPI_SETPINS						0
#define SPI_READWRITE					1
#define SPI_WRITEANDREAD				2

// QuickUSB JTAG commands (wIndex values for QUICKUSB_JTAG)
#define JTAG_DIRECT						0
#define JTAG_CLKRAW						1
#define JTAG_CLKMULT					2
#define JTAG_RECIRC						3
#define JTAG_FLUSH						4

// QuickUSB storage constants
#define STORAGE_SIZE					2048
#define STORAGE_PAGE_SIZE				32
#define STORAGE_BASE_ADDR				0x3800
#define STORAGE_I2C_ADDR				0x51

// Number of stream buffers
#define NUMSTREAMBUFFERS				6

// True/False values
#define TRUE							1
#define FALSE							0

// Invalid handle value
#define INVALID_QHANDLE_VALUE			-1
#define INVALID_HANDLE_VALUE			NULL

// Swap bytes for endianness
#if defined(__i386__)
#define SWAPBYTES(source, dest, length) swab(source, dest, length)
#else
#define SWAPBYTES(source, dest, length) memcpy(dest, source, length)
#endif


// Typedef for device handle
typedef IOUSBInterfaceInterface245 **	HANDLE;


// Driver error codes
enum {
	DriverErrorNone						= 0x0000,
	DriverErrorInvalidParameter			= 0x0001,
	DriverErrorMemory					= 0x0002,
	DriverErrorURB						= 0x0003,
	DriverErrorTimeout					= 0x0004,
	DriverErrorBulk						= 0x0005,
	DriverErrorAsync					= 0x0006,
	DriverErrorPipe						= 0x0007,
	DriverErrorBusy						= 0x0008
};

// Driver types
typedef enum {
	OTHER_DRIVER						= 0,
	QUSB_DRIVER							= 1
} QusbDriverType;


// Structure for driver error
typedef struct _QUSB_DRIVER_ERROR {
	QULONG UsbError;
	QWORD DriverError;
	QULONG DriverState;
} GET_DRIVER_ERROR, *PGET_DRIVER_ERROR;

// Structure for driver version
typedef struct _QUSB_DRIVER_VERSION {
	BOOL DeviceFound;
	QWORD MajorVersion;
	QWORD MinorVersion;
	QWORD BuildVersion;
	UCHAR QusbDriverNum;
} QUSB_DRIVER_VERSION, *PQUSB_DRIVER_VERSION;

// Structure for device info
typedef struct _QUSB_DEVICE_INFO {
	QCHAR devName[9];
	HANDLE hDevHandle;
	QusbDriverType devType;
	BOOL devOpen;
	QWORD iRefCount;
	QWORD defaultOffset;
} QUSB_DEVICE_INFO, *PQUSB_DEVICE_INFO;


// QuickUSB last error code
QULONG lastError = QUICKUSB_ERROR_NO_ERROR;

// QuickUSB driver version
QUSB_DRIVER_VERSION DriverVersion;

// QuickUSB device info array
QUSB_DEVICE_INFO QusbDeviceInfo[MAX_DEVICENUM];

// QuickUSB device offset
QULONG OpenDeviceOffset;

// QuickUSB initialization status
BOOL initialized = FALSE;



/*-----------------------------------------------------------------------------
 Purpose :  Initializes values.
 Input   :  Values to initialize
 Output  :  Return non-zero on success, zero on failure.
 Notes   :  This function is not referenced.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbInitialize(QULONG initValues) {
	return TRUE;
}



/*-----------------------------------------------------------------------------
 Purpose :  Check the QuickUsb.sys driver is recent enough for the requested
				function.
 Input   :  major - Minimum required QuickUsb.sys major driver version
			minor - Minimum required QuickUsb.sys minor driver version
			build - Minimum required QuickUsb.sys build driver version
 Output  :  Return non-zero on success, zero on failure.
 Notes   :  Driver version is obtained in QuickUsbFindModules.
 -----------------------------------------------------------------------------*/
BOOL CheckDriverVersion(QWORD major, QWORD minor, QWORD build) {
	if (DriverVersion.MajorVersion < major) {
		return FALSE;
	}
	if ((DriverVersion.MajorVersion == major) &&
		(DriverVersion.MinorVersion < minor)) {
		return FALSE;
	}
	if ((DriverVersion.MajorVersion == major) &&
		(DriverVersion.MinorVersion == minor) &&
		(DriverVersion.BuildVersion < build)) {
		return FALSE;
	}
	return TRUE;
}



/*-----------------------------------------------------------------------------
 Purpose :  To return a valid QUSB device handle.
 Input   :  hDevice - offset into array of _QUSB_DEVICE_INFO structures
 Output  :  hDevHandle - Handle to device interface
			Return non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbGetDeviceHandle(QHANDLE hDevice, HANDLE *hDevHandle) {
	if (hDevice != INVALID_QHANDLE_VALUE) {
		*hDevHandle = QusbDeviceInfo[hDevice].hDevHandle;
		if (hDevHandle == INVALID_HANDLE_VALUE) {
			return FALSE;
		}
		return TRUE;
	}
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  To identify device type.
 Input   :  hDevice - offset into array of _QUSB_DEVICE_INFO structures
 Output  :  pType - Device type
			Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbGetDeviceType(QHANDLE hDevice, QusbDriverType *pType) {
	if (hDevice == INVALID_QHANDLE_VALUE) {
		lastError = QUICKUSB_ERROR_INVALID_PARAMETER;
		return FALSE;
	}
	
	if (QusbDeviceInfo[hDevice].devType == QUSB_DRIVER) {
		*pType = QUSB_DRIVER;
		return TRUE;
	}
	else {
		*pType = OTHER_DRIVER;
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  To get driver specific error codes.
 Input   :  hDevice - offset into array of _QUSB_DEVICE_INFO structures
 Output  :  pGetError - Driver error
			Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbGetError(QHANDLE hDevice, PGET_DRIVER_ERROR pGetError) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  Open a QuickUSB device for use by the library.
 Input   :  deviceName - A valid QuickUSB device name
 Output  :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			Returns non-zero on success, zero on failure.
 Notes   :  This function will only open devices that are closed.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbOpen(QHANDLE *hDevice, QCHAR *deviceName) {
	HANDLE hDevHandle;
	QCHAR devList[256];
	UCHAR index;
	kern_return_t err;
	
	hDevHandle = INVALID_HANDLE_VALUE;
	
	// If FindModules has yet to be called, call it as it must be
	// called before this function executes or it will fail
	if (!initialized) {
		if (!QuickUsbFindModules(devList, 256))	{
			return FALSE;
		}
	}
	
	// Find device name from the QUSB_DEVICE_INFO array and access the
	// QusbDeviceType to determine which driver is called to open the module
	// interface.
	for (index = 0; index < MAX_DEVICENUM; index++) {
		if (!strcmp((const char *)deviceName,
					(const char *)QusbDeviceInfo[index].devName)) {
			break;
		}
	}
	
	// deviceName was not found in the QusbDeviceInfo array. Notify the user.
	if (index == MAX_DEVICENUM) {
		lastError = QUICKUSB_ERROR_CANNOT_OPEN_MODULE;
		return FALSE;
	}
	
	if (QusbDeviceInfo[index].devType == QUSB_DRIVER) {
		// Convert the generic handle to the device specific handle
		if (!QuickUsbGetDeviceHandle(index, &hDevHandle)) {
			lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;
			return FALSE;
		}
		
		// Open interface
		err = (*hDevHandle)->USBInterfaceOpen(hDevHandle);
		if (err) {
			lastError = QUICKUSB_ERROR_CANNOT_OPEN_MODULE;
			return FALSE;
		}
		
		OpenDeviceOffset = index;
		QusbDeviceInfo[index].devOpen = TRUE;
		QusbDeviceInfo[index].iRefCount++;
		
		*hDevice = index;
		
		return TRUE;
	}
	
	// Handle an undefined driver type   
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  To close a handle to a QuickUsb device.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbClose(QHANDLE hDevice) {
	QusbDriverType type;
	HANDLE hDevHandle;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) { // Sets lastError on failure
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Check handle value
		if (hDevice == INVALID_QHANDLE_VALUE) {
			lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;
			return FALSE;
		}
		
		// Decrement the open count for this QUSB device
		if (QusbDeviceInfo[hDevice].iRefCount > 0) {
			QusbDeviceInfo[hDevice].iRefCount--;
		}
		
		if (QusbDeviceInfo[hDevice].iRefCount == 0) {
			// Convert the generic handle to the device specific handle
			if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
				lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
				return FALSE;
			}
			
			(*hDevHandle)->USBInterfaceClose(hDevHandle);
			(*hDevHandle)->Release(hDevHandle);
			
			OpenDeviceOffset = 0;
			QusbDeviceInfo[hDevice].hDevHandle = INVALID_HANDLE_VALUE;
			QusbDeviceInfo[hDevice].devOpen = FALSE;
		}
		
		return TRUE;
	}
	
	// Handle an undefined driver type   
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Returns the string descriptor for the selected QuickUSB module.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			index - QuickUsb string descriptor index. See QuickUsb.h
			length - Length to read
 Output  :  buffer - Buffer to store string descriptor
			length - Length of string descriptor
			Returns non-zero on success, zero on failure.
 Notes   :  This function returns a NULL terminated string in the buffer.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbGetStringDescriptor(QHANDLE hDevice, QBYTE index, QCHAR *buffer, QWORD length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	
	UCHAR data[MAX_STRINGDESCRIPTOR];
	ULONG ulength;
	UCHAR i;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;
		return FALSE;
	}
	
	// Handle using QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = kUSBIn<<7|0<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = kUSBRqGetDescriptor;
		request.wValue = (kUSBStringDesc<<8)|index;
		request.wIndex = 0;
		request.wLength = MAX_STRINGDESCRIPTOR;
		request.pData = data;
		
		// Send control request to get string descriptor
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			return FALSE;
		}
	
		// Convert UNICODE to ASCII
		ulength = (request.wLenDone - 2) / 2;
		if (ulength > (MAX_STRINGDESCRIPTOR - 1)) {
			ulength = MAX_STRINGDESCRIPTOR - 1;
		}
		for (i = 0; i < ulength; i++) {
			buffer[i] = data[i*2 + 2];
		}
		buffer[i] = '\0';
		
		return TRUE;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Build a list of all QuickUSB modules connected to the host.
 Input   :  length - The length of the nameList buffer
 Output  :  nameList - Buffer containing module names
			Returns non-zero on success, zero on failure.
 Notes   :  devName is limited to 9 characters long.
			If successful, nameList will contain a NULL delimited list of
				QuickUSB module names found by the library.
			This routine will only find devices that are closed.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbFindModules(QCHAR *nameList, QULONG length) {
	mach_port_t masterPort;
	CFMutableDictionaryRef matchDict;
	CFNumberRef numberRef;
	SInt32 vid, pid;
	io_iterator_t itr, itritr;
	io_service_t usbDev, usbInterface;
	IOCFPlugInInterface **ioDev, **ioIntf;
	IOUSBDeviceInterface245 **dev;
	IOUSBInterfaceInterface245 **intf;
	IOUSBConfigurationDescriptorPtr confDesc;
	IOUSBFindInterfaceRequest interfaceRequest;
	SInt32 score;
	UInt8 numConf;
	kern_return_t err;
	
	QCHAR devName[9];
	PQCHAR namePtr; 
	UCHAR index;
	QRESULT result;
	UCHAR hDevice;
	
	QCHAR strDescriptor1[MAX_STRINGDESCRIPTOR];
	QCHAR strDescriptor6[MAX_STRINGDESCRIPTOR];
	HANDLE hDevHandle;
	
	matchDict = 0;
	vid = BITWISE_VID;
	pid = QUSB2_PID;
	itr = 0;
	itritr = 0;
	ioDev = NULL;
	dev = NULL;
	intf = NULL;
	
	namePtr = nameList;
	hDevice = 0;
	hDevHandle = 0;
	
	DriverVersion.DeviceFound = 0;
	
	// Initialize all device handles as invalid
	for (index = 0; index < MAX_DEVICENUM; index++) {
		QusbDeviceInfo[index].hDevHandle = INVALID_HANDLE_VALUE;
	}
	index = 0;
	
	// Obtain master port
	err = IOMasterPort(MACH_PORT_NULL, &masterPort);
	if (err || !masterPort) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;
		return FALSE;
	}
	
	// Obtain matching dictionary
	matchDict = IOServiceMatching(kIOUSBDeviceClassName);
	if (!matchDict) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;
		return FALSE;
	}
	
	// Get reference number for vendor id
	numberRef = CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &vid);
	if (!numberRef) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;
		return FALSE;
	}
	
	// Add vendor id in dictionary
	CFDictionaryAddValue(matchDict,
						 CFSTR(kUSBVendorID),
						 numberRef);
	CFRelease(numberRef);
	
	// Get reference number for product id
	numberRef = CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &pid);
	if (!numberRef) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;
		return FALSE;
	}
	
	// Add product id in dictionary
	CFDictionaryAddValue(matchDict,
						 CFSTR(kUSBProductID),
						 numberRef);
	CFRelease(numberRef);
	
	// Get services matching the dictionary
	err = IOServiceGetMatchingServices(masterPort,
									   matchDict,
									   &itr);
	if (err != kIOReturnSuccess) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;
		return FALSE;
	}
	
	// Iterate through devices
	while ((usbDev = IOIteratorNext(itr))) {
		// Get IO device
		err = IOCreatePlugInInterfaceForService(usbDev,
												kIOUSBDeviceUserClientTypeID,
												kIOCFPlugInInterfaceID,
												&ioDev,
												&score);
		if (err || !ioDev) {
			lastError = QUICKUSB_ERROR_CANNOT_OPEN_MODULE;
			IOObjectRelease(usbDev);
			continue;
		}
		
		// Get device
		err = (*ioDev)->QueryInterface(ioDev,
									   CFUUIDGetUUIDBytes(kIOUSBDeviceInterfaceID245),
									   (LPVOID *)&dev);
		IODestroyPlugInInterface(ioDev);
		if (err || !dev) {
			lastError = QUICKUSB_ERROR_CANNOT_OPEN_MODULE;
			IOObjectRelease(usbDev);
			continue;
		}
		
		// Open device
		err = (*dev)->USBDeviceOpen(dev);
		if (err) {
			lastError = QUICKUSB_ERROR_CANNOT_OPEN_MODULE;
			IOObjectRelease(usbDev);
			continue;
		}
		
		// Get number of configurations
		err = (*dev)->GetNumberOfConfigurations(dev, &numConf);
		if (err || !numConf) {
			lastError = QUICKUSB_ERROR_CANNOT_OPEN_MODULE;
			(*dev)->USBDeviceClose(dev);
			(*dev)->Release(dev);
			IOObjectRelease(usbDev);
			continue;
		}
		
		// Get configurations
		err = (*dev)->GetConfigurationDescriptorPtr(dev, 0, &confDesc);
		if (err) {
			lastError = QUICKUSB_ERROR_CANNOT_OPEN_MODULE;
			(*dev)->USBDeviceClose(dev);
			(*dev)->Release(dev);
			IOObjectRelease(usbDev);
			continue;
		}
		
		// Set configuration
		err= (*dev)->SetConfiguration(dev, confDesc->bConfigurationValue);
		if (err) {
			lastError = QUICKUSB_ERROR_CANNOT_OPEN_MODULE;
			(*dev)->USBDeviceClose(dev);
			(*dev)->Release(dev);
			IOObjectRelease(usbDev);
			continue;
		}
		
		// File interface request
		interfaceRequest.bInterfaceClass = kIOUSBFindInterfaceDontCare;
		interfaceRequest.bInterfaceSubClass = kIOUSBFindInterfaceDontCare;
		interfaceRequest.bInterfaceProtocol = kIOUSBFindInterfaceDontCare;
		interfaceRequest.bAlternateSetting = kIOUSBFindInterfaceDontCare;
		
		// Get iterator for interfaces
		err = (*dev)->CreateInterfaceIterator(dev, &interfaceRequest, &itritr);
		if (err)	{
			lastError = QUICKUSB_ERROR_CANNOT_OPEN_MODULE;
			(*dev)->USBDeviceClose(dev);
			(*dev)->Release(dev);
			IOObjectRelease(usbDev);
			continue;
		}
		
		// Iterate through interfaces
		while ((usbInterface = IOIteratorNext(itritr))) {
			// Get IO interface
			err = IOCreatePlugInInterfaceForService(usbInterface,
													kIOUSBInterfaceUserClientTypeID,
													kIOCFPlugInInterfaceID,
													&ioIntf,
													&score);
			if (err || !ioIntf) {
				lastError = QUICKUSB_ERROR_CANNOT_OPEN_MODULE;
				IOObjectRelease(usbInterface);
				continue;
			}
			
			// Get interface
			err = (*ioIntf)->QueryInterface(ioIntf,
											CFUUIDGetUUIDBytes(kIOUSBInterfaceInterfaceID245),
											(LPVOID *)&intf);
			if (err || !intf) {
				lastError = QUICKUSB_ERROR_CANNOT_OPEN_MODULE;
				IOObjectRelease(usbInterface);
				continue;
			}
			
			// Open interface
			err = (*intf)->USBInterfaceOpen(intf);
			if (err) {
				lastError = QUICKUSB_ERROR_CANNOT_OPEN_MODULE;
				IOObjectRelease(usbInterface);
				continue;
			}
			
			// Store interface and device type
			QusbDeviceInfo[index].hDevHandle = intf;
			QusbDeviceInfo[index].devType = QUSB_DRIVER;
			
			// Get make of device
			result = QuickUsbGetStringDescriptor(index,
												 QUICKUSB_MAKE,
												 (QCHAR *)strDescriptor1,
												 MAX_STRINGDESCRIPTOR);
			result = QuickUsbGetStringDescriptor(index,
												 QUICKUSB_MAKE_PERM,
												 (QCHAR *)strDescriptor6,
												 MAX_STRINGDESCRIPTOR);
			
			// Check make of device
			if (((strcmp((const char *)strDescriptor1, QUICKUSB_DEVICE_STRING) == 0) ||
				 (strcpy((char *)strDescriptor6, QUICKUSB_DEVICE_STRING) == 0) ||
				 (strstr((const char *)nameList, "*.*") != NULL)) &&
				(strlen((const char *)devName) < (size_t)(length - (namePtr-nameList)))) {
				// Create device name
				sprintf((char *)devName, "%s-%1d", QUICKUSB_DEVICE_BASENAME, index);
				
				// Add device name to nameList
				sprintf((char *)namePtr, "%s", devName);
				namePtr += strlen((const char *)devName)+1;
				
				// Now's a good time to go read out that device version number information.
				if (!DriverVersion.DeviceFound) {
					DriverVersion.MajorVersion = QUSB_DRIVER_MAJOR_VERSION;
					DriverVersion.MinorVersion = QUSB_DRIVER_MINOR_VERSION;
					DriverVersion.BuildVersion = QUSB_DRIVER_BUILD_VERSION;
					DriverVersion.DeviceFound = TRUE;
				}
				
				// Add device to device table
				strcpy((char *)QusbDeviceInfo[index].devName, (const char *)devName);
				QusbDeviceInfo[index].devType = QUSB_DRIVER;
				
				// Only increment index if the string descriptors match
				index++;
			}
			
			// Clean up
			(*intf)->USBInterfaceClose(intf);
			(*intf)->Release(intf);
			IOObjectRelease(usbInterface);
		}
		
		// Clean up
		(*dev)->USBDeviceClose(dev);
		(*dev)->Release(dev);
		IOObjectRelease(itritr);
		IOObjectRelease(usbDev);
	}
	
	// Clean up
	IOObjectRelease(itr);
	
	// Add a terminating null as the final character in the nameList
	*namePtr = '\0';
	
	if (index == 0) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;
		return FALSE;
	}
	
	initialized = TRUE;
	
	return TRUE;
}



/*-----------------------------------------------------------------------------
 Purpose :  Set QuickUSB to reset state.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			resetBit - Reset state
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbSetResetState(QHANDLE hDevice, UCHAR resetBit) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  To read data from the EEPROM.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Address for request
			length - Size of data buffer
 Output  :  data - Data from EEPROM
			length - Size of EEPROM data
			Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadEepromData(QHANDLE hDevice, QWORD address, UCHAR *data, QWORD *length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 1<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_EEPROM;
		request.wIndex = 0;
		request.wValue = address;
		request.wLength = *length;
		request.pData = data;
		
		// Send the command to the driver
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error, display the error status box
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		else {
			*length = (unsigned char)request.wLenDone;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  To write data to the EEPROM.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Address for request
			data - Data to EEPROM
			length - Size of data buffer
 Output  :  length - Size of written EEPROM data
			Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWriteEepromData(QHANDLE hDevice, QWORD address, UCHAR *data, QWORD length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Get device type
	if(!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_EEPROM;
		request.wIndex = 0;
		request.wValue = address;
		request.wLength = length;
		request.pData = data;
		
		// Send the command to the driver
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {   
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  To write data to RAM.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Address for request
			data - Data to RAM
			length - Size of data buffer
 Output  :  length - Size of written RAM data
			Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWriteRamData(QHANDLE hDevice, QWORD address, UCHAR *data, QWORD length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = FIRMWARE_LOAD;
		request.wIndex = 0;
		request.wValue = address;
		request.wLength = length;
		request.pData = data;
		
		// Send the command to the driver
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  To read QuickUSB module settings.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Address for request
 Output  :  value - Setting value
			Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadSetting(QHANDLE hDevice, QWORD address, QWORD *value) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	QWORD data;
	
	result = TRUE;
	data = 0;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 1<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_SETTING;
		request.wIndex = address;
		request.wValue = 0;
		request.wLength = sizeof(QWORD);
		request.pData = value;
		
		// Send control request to get string descriptor
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}

#ifdef __ppc__
		data = *value;
		swab(&data, value, request.wLenDone);
#endif
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  To write QuickUSB module settings.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Setting address
			value - Setting value
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWriteSetting(QHANDLE hDevice, QWORD address, QWORD value) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	QWORD data;
	
	data = value;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER)  {
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_SETTING;
		request.wIndex = address;
		request.wValue = 0;
		request.wLength = sizeof(QWORD);
		request.pData = &value;
		
#ifdef __ppc__
		swab(&data, &value, sizeof(QWORD));
#endif
		
		// Send control request to get string descriptor
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Start the process of FPGA configuration.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  If the FPGA is in the process of being configured, the process will
				restart. If the FPGA is already configured, it will be reset and
				reconfigured.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbStartFpgaConfiguration(QHANDLE hDevice) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	QWORD status, swap;
	
	result = TRUE;
	status = 0;
	swap = 0;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 1<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_FPGA;
		request.wIndex = FPGA_START;
		request.wValue = 0;
		request.wLength = sizeof(QWORD);
		request.pData = &status;
		
		// Send control request to get string descriptor
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		
#ifdef __ppc__
		swap = status;
		swab(&swap, &status, sizeof(QWORD));
#endif
		
		if (status != 0 && result != FALSE) {
			return TRUE;
		}
		else {
			return FALSE;
		}
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Sends FPGA configuration data to the FPGA using the QuickUSB FPGA
				configuration port.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			fpgadata - FPGA configuration data
			datalength - Length of the configuration data
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  Maximum data length is 64.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWriteFpgaData(QHANDLE hDevice, UCHAR *fpgadata, QULONG datalength) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	QULONG bytecount;
	QULONG bufferSize;
	kern_return_t err;
	QRESULT result;
	
	bytecount = 0;
	result = TRUE;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Check for datalength of 0
	if (datalength == 0) {
		lastError = QUICKUSB_ERROR_INVALID_PARAMETER;
		return FALSE;
	}
	
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_FPGA;
		request.wIndex = FPGA_WRITE;
		request.wValue = 0;
		
		// Send the config file to the FPGA in blocks of MAX_CNTL_XFER_SIZE
		while ((result != FALSE) && (bytecount < datalength)) {
			// Send the block
			bufferSize = datalength - bytecount;
			if (bufferSize > MAX_CNTL_XFER_SIZE) {
				bufferSize = MAX_CNTL_XFER_SIZE;
			}
			
			// Send control request
			request.wLength = bufferSize;
			request.pData = fpgadata + bytecount;
			err = (*hDevHandle)->ControlRequest(hDevHandle,
												0,
												&request);
			if (err != kIOReturnSuccess) {
				result = FALSE;
			}
			else {
				bytecount += bufferSize;
			}
		}
		
		// If there was an error set the last error code
		if (result == FALSE) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}	
}



/*-----------------------------------------------------------------------------
 Purpose :  Check to see if the FPGA is configured.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
 Output  :  isConfigured - Configuration status of the FPGA
			Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbIsFpgaConfigured(QHANDLE hDevice, QWORD *isConfigured) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	QWORD status, swap;
	
	result = TRUE;
	status = 0;
	swap = 0;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 1<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_FPGA;
		request.wIndex = FPGA_ISCONFIG;
		request.wValue = 0;
		request.wLength = sizeof(QWORD);
		request.pData = &status;
		
		// Send the command to the driver
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		
#ifdef __ppc__
		swap = status;
		swab(&swap, &status, sizeof(QWORD));
#endif
		
		// Return the configuration status
		if (status == TRUE) {
			*isConfigured = TRUE;
		}
		else {
			*isConfigured = FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  N/A.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			outputs - N/A
 Output  :  inputs - N/A
			Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbJtagDirect(QHANDLE hDevice, QWORD outputs, QWORD *inputs) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  Write a block of command values to the high-speed parallel port
				using the QuickUSB module.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Starting value of the HSPP address bus
			data - Data to write to the high-speed parallel port
			length - Length to write to the high-speed parallel port
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  The maximum length is 64 bytes.
			The data buffer can receive data values of any type.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWriteCommand(QHANDLE hDevice, QWORD address, UCHAR *data, QWORD length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_COMMAND;
		request.wIndex = address;
		request.wValue = length;
		request.wLength = length;
		request.pData = data;
		
		// Send the block
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Read a block of command values from the high-speed parallel port
			using the QuickUSB module.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Starting value of the HSPP address bus
			data - Buffer for data read from the high-speed parallel port
			length - Length to read from the high-speed parallel port
 Output  :  length - Length read from the high-speed parallel port
			Returns non-zero on success, zero on failure.
 Notes   :  The maximum length is 64 bytes.
			The data buffer can contain data values of any type.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadCommand(QHANDLE hDevice, QWORD address, UCHAR *data, QWORD *length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build vendor request
		request.bmRequestType = 1<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_COMMAND;
		request.wIndex = address;
		request.wValue = *length;
		request.wLength = *length;
		request.pData = data;
		
		// Send the block
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			*length = 0;
			result = FALSE;
		}
		else {
			*length = request.wLenDone;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Write a block of data values to the high-speed parallel port using
				the QuickuUSB module.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			data - Buffer of data values to write to the high-speed parallel
				port
			length - Length to write to the high-speed parallel port
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  The maximum length is 16 MB (16777216 bytes).
			The data buffer can contain data values of any type.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWriteData(QHANDLE hDevice, UCHAR *data, QULONG length) {
	GET_DRIVER_ERROR GetError;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	QWORD regVal;
	
	UCHAR *block;
	QULONG bytesWritten;
	QLONG blockSize;
	UInt8 numPipes, outPipe;
	UInt8 direction, number, transferType, interval;
	UInt16 maxPacketSize;
	UCHAR i;
	
	result = TRUE;
	regVal = 0;
	bytesWritten = 0;
	numPipes = 0;
	outPipe = 0;
	direction = 0;
	number = 0;
	transferType = 0;
	maxPacketSize = 0;
	interval = 0;
	block = data;
	
	// Check for a valid length
	if ((length < 1) || (length > MAX_WRITEDATA_SIZE)) {
		lastError = QUICKUSB_ERROR_INVALID_PARAMETER;
		return FALSE;
	}
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Get number of endpoints
		err = (*hDevHandle)->GetNumEndpoints(hDevHandle,
											 &numPipes);
		if (err || !numPipes) {
			lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;
			return FALSE;
		}
		
		// Get pipe properties
		for (i = 1; i <= numPipes; i++) {
			err = (*hDevHandle)->GetPipeProperties(hDevHandle,
												   i,
												   &direction,
												   &number,
												   &transferType,
												   &maxPacketSize,
												   &interval);
			if (err) {
				lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;
				return FALSE;
			}
			if ((transferType == kUSBBulk) && (direction == kUSBOut)) {
				outPipe = i;
				break;
			}
		}
		
		// Send the data one buffer at a time until sent
		while (result != FALSE) {
			// Calculate the current block size
			blockSize = length - (block - data);
			if (blockSize > MAX_WRITEDATA_SIZE) {
				blockSize = MAX_WRITEDATA_SIZE;
			}
			if (blockSize <= 0) {
				break;
			}
			
			printf("blockSize: %lu\n", (QULONG)blockSize);
			
			// Send block
			err = (*hDevHandle)->WritePipe(hDevHandle,	// Interface
										   outPipe,		// Pipe
										   block,		// Data
										   blockSize);	// Length
			if (err == kIOReturnSuccess) {
				block += blockSize;
			}
			else {
				result = FALSE;
			}
		}
		
		// If there was an error set the last error code
		if (result == FALSE) {
			QuickUsbGetError(hDevice, &GetError);
			 
			if (GetError.DriverError == DriverErrorTimeout) {
				lastError = QUICKUSB_ERROR_TIMEOUT;
			 
				// Reset all endpoint FIFOs
				sleep(100);
				QuickUsbReadSetting(hDevice, SETTING_FIFO_CONFIG, &regVal);
				QuickUsbWriteSetting(hDevice, SETTING_FIFO_CONFIG, regVal);
			}
			else {
				lastError = GetError.DriverError;
			}
			
			return FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Read a block of data values from the high-speed parallel port using
				the QuickUSB module.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			data - Buffer to store data values read from the high-speed parallel
				port
			length - Length to read from the high-speed parallel port
 Output  :  length - Length read from the high-speed parallel port
			Returns non-zero on success, zero on failure.
 Notes   :  The maximum length is 16 MB (16777216 bytes).
			The data buffer can receive data values of any type.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadData(QHANDLE hDevice, UCHAR *data, QULONG *length) {
	GET_DRIVER_ERROR GetError;
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	QWORD regVal;
	
	UCHAR *block;
	QULONG bytesReceived;
	UInt32 blockSize;
	UCHAR numPipes, inPipe;
	UCHAR direction, number, transferType, interval;
	QWORD maxPacketSize;
	UCHAR i;
	
	result = TRUE;
	regVal = 0;
	bytesReceived = 0;
	blockSize = 0;
	numPipes = 0;
	inPipe = 0;
	direction = 0;
	number = 0;
	transferType = 0;
	maxPacketSize = 0;
	interval = 0;
	block = data;
	
	// Check for a valid length
	if ((*length < 1) || (*length > MAX_READDATA_SIZE)) {
		lastError = QUICKUSB_ERROR_INVALID_PARAMETER;
		return FALSE;
	}
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Get number of endpoints
		err = (*hDevHandle)->GetNumEndpoints(hDevHandle,
											 &numPipes);
		if (err || !numPipes) {
			lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;
			return FALSE;
		}
		
		// Get pipe properties
		for (i = 1; i <= numPipes; i++) {
			err = (*hDevHandle)->GetPipeProperties(hDevHandle,
												   i,
												   &direction,
												   &number,
												   &transferType,
												   &maxPacketSize,
												   &interval);
			if (err) {
				lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;
				return FALSE;
			}
			if ((transferType == kUSBBulk) && (direction == kUSBIn)) {
				inPipe = i;
				break;
			}
		}
		
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_READDATALEN;
		request.wIndex = 0;
		request.wValue = 0;
		request.wLength = sizeof(UInt32);
		request.pData = &blockSize;
		
		// Send the data one buffer at a time until sent
		while (result != FALSE) {
			// Calculate the current block size
			blockSize = *length - (block - data);
			if (blockSize > MAX_READDATA_SIZE) {
				blockSize = MAX_READDATA_SIZE;
			}
			if (blockSize <= 0) {
				break;
			}
			
			// Send control request
			err = (*hDevHandle)->ControlRequest(hDevHandle,
												0,
												&request);
			if (err != kIOReturnSuccess) {
				lastError = QUICKUSB_ERROR_IOCTL_FAILED;
				result = FALSE;
				break;
			}
			
			// Send block
			err = (*hDevHandle)->ReadPipe(hDevHandle,	// Interface
										  inPipe,		// Pipe
										  block,		// Data
										  &blockSize);	// Length
			if (err == kIOReturnSuccess) {
				block += blockSize;
				bytesReceived += blockSize;
			}
			else {
				result = FALSE;
			}
		}
		
		// If there was an error set the last error code
		if (result == FALSE) {
			QuickUsbGetError(hDevice, &GetError);
			
			if (GetError.DriverError == DriverErrorTimeout) {
				lastError = QUICKUSB_ERROR_TIMEOUT;
				
				// Reset all endpoint FIFOs
				sleep(100);
				QuickUsbReadSetting(hDevice, SETTING_FIFO_CONFIG, &regVal);
				QuickUsbWriteSetting(hDevice, SETTING_FIFO_CONFIG, regVal);
			}
			else {
				lastError = GetError.DriverError;
			}
			
			return FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Read the data direction of each data port bit for the specified
				port.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Port address
 Output  :  data - Buffer to store data direction bit values
			Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadPortDir(QHANDLE hDevice, QWORD address, UCHAR *data) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 1<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_PORT;
		request.wIndex = PORT_GETSET_DIR;
		request.wValue = address;
		request.wLength = 1;
		request.pData = data;
		
		// Send the block
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Set the data direction of each data port bit for the specified port.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Port address
			data - Buffer containing data direction bit values
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWritePortDir(QHANDLE hDevice, QWORD address, UCHAR data) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_PORT;
		request.wIndex = PORT_GETSET_DIR;
		request.wValue = address;
		request.wLength = 1;
		request.pData = &data;
		
		// Send the block
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Read a series of bytes from the specified port.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Port address
			data - Buffer to store port values
			length - Length to read from port
 Output  :  length - Length read from port
			Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadPort(QHANDLE hDevice, QWORD address, UCHAR *data, QWORD *length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return(FALSE);
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 1<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_PORT;
		request.wIndex = PORT_READWRITE;
		request.wValue = address;
		request.wLength = *length;
		request.pData = data;
		
		// Send the block
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		else {
			*length = request.wLenDone;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Write a series of bytes to the specified port.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Port address
			data - Buffer containing values to write to port
			length - Length to write to port
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWritePort(QHANDLE hDevice, QWORD address, UCHAR *data, QWORD length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_PORT;
		request.wIndex = PORT_READWRITE;
		request.wValue = address;
		request.wLength = length;
		request.pData = data;
		
		// Send the block
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Set the baud rate of both serial ports.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			baudRate - Baud rate in bits per second
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbSetRS232BaudRate(QHANDLE hDevice, QULONG baudRate) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	QULONG swap;
	
	result = TRUE;
	swap = baudRate;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return(FALSE);
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_RS232;
		request.wIndex = RS232_SETGET_BAUD;
		request.wValue = 0;
		request.wLength = sizeof(QULONG);
		request.pData = &baudRate;
		
#ifdef __ppc__
		swab(&swap, &baudRate, sizeof(QULONG));
#endif
		
		// Send the block
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Read the number of characters waiting in the received buffer.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			portNum - Serial port number
			length - Length to read from serial port
 Output  :  length - Length read from serial port
			Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbGetNumRS232(QHANDLE hDevice, UCHAR portNum, QWORD *length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	QWORD numChars;
	
	result = TRUE;
	numChars = 0;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return(FALSE);
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 1<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_RS232;
		request.wIndex = RS232_SETGET_NUM;
		request.wValue = portNum;
		request.wLength = sizeof(QWORD);
		request.pData = &numChars;
		
		// Send the block
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		else {
#ifdef __ppc__
			swab(&numChars, length, sizeof(QWORD));
#else
			*length = numChars;
#endif
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Flush the RS232 port transmit and receive buffers.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			portNum - Serial port number
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbFlushRS232(QHANDLE hDevice, UCHAR portNum) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	QWORD numChars;
	
	result = TRUE;
	numChars = 0;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return(FALSE);
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_RS232;
		request.wIndex = RS232_SETGET_NUM;
		request.wValue = portNum;
		request.wLength = sizeof(QWORD);
		request.pData = &numChars;
		
		// Send the block
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Read a block of characters from the interrupt receive buffer of the
				specified QuickUSB serial port.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			portNum - Serial port number
			data - Buffer to store data read from the serial port
			length - Length to read from the serial port
 Output  :  length - Length read from the serial port
			Returns non-zero on success, zero on failure.
 Notes   :  The interrupt buffer is 128 bytes deep.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadRS232(QHANDLE hDevice, UCHAR portNum, UCHAR *data, QWORD *length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	UCHAR *block;
	QLONG blockSize;
	QULONG bytesReceived;	
	
	result = TRUE;
	block = data;
	bytesReceived = 0;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 1<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_RS232;
		request.wIndex = RS232_READWRITE;
		request.wValue = portNum;
		
		// Read the data one block at a time until sent
		while (result != FALSE) {
			// Calculate the current block size
			blockSize = *length - (block - data);
			if (blockSize > 64) {
				blockSize = 64;
			}
			if (blockSize <= 0) {
				break;
			}
			
			// Read the block
			request.wLength = blockSize;
			request.pData = block;
			
			// Send the block
			err = (*hDevHandle)->ControlRequest(hDevHandle,
												0,
												&request);
			
			// If there was an error set the last error code
			if (err != kIOReturnSuccess) {
				lastError = QUICKUSB_ERROR_IOCTL_FAILED;
				result = FALSE;
				break;
			}
			
			// Keep a running count of the bytes received
			bytesReceived += request.wLenDone;
			
			// Increment the block pointer
			block += blockSize;
		}
		
		// If there was an error set the last error code
		if (result == TRUE) {
			*length = (QWORD)bytesReceived;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Write a block of characters to the specified QuickUSB serial port.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			portNum - Serial port number
			data - Buffer containing data to write to the serial port
			length - Length of buffer to write to the serial port
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWriteRS232(QHANDLE hDevice, UCHAR portNum, UCHAR *data, QWORD length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	UCHAR *block;
	QLONG blockSize;
	QULONG bytesWritten;
	
	result = TRUE;
	block = data;
	bytesWritten = 0;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_RS232;
		request.wIndex = RS232_READWRITE;
		request.wValue = portNum;
		
		// Read the data one block at a time until sent
		while (result != FALSE) {
			// Calculate the current block size
			blockSize = length - (block - data);
			if (blockSize > 64) {
				blockSize = 64;
			}
			if (blockSize <= 0) {
				break;
			}
			
			// Read the block
			request.wLength = blockSize;
			request.pData = block;
			
			// Send the block
			err = (*hDevHandle)->ControlRequest(hDevHandle,
												0,
												&request);
			
			// If there was an error set the last error code
			if (err != kIOReturnSuccess) {
				lastError = QUICKUSB_ERROR_IOCTL_FAILED;
				result = FALSE;
				break;
			}
			
			// Increment the block pointer
			else {
				block += blockSize;
			}
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Read a block of bytes from the specified SPI slave port.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			portNum - SPI device address
			length - Length to read from SPI
 Output  :  data - Buffer containing data read from SPI
			length - Length read from SPI
			Returns non-zero on success, zero on failure.
 Notes   :  The maximum length is 64 bytes.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadSpi(QHANDLE hDevice, UCHAR portNum, UCHAR *data, QWORD *length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Check for valid length
	if ((*length < 1) || (*length > 64)) {
		lastError = QUICKUSB_ERROR_INVALID_PARAMETER;
		return FALSE;
	}
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER)  {
		// Build the vendor request
		request.bmRequestType = 1<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_SPI;
		request.wIndex = SPI_READWRITE;
		request.wValue = portNum;
		request.wLength = *length;
		request.pData = data;
		
		// Send control request to get string descriptor
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		else {
			*length = request.wLenDone;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Write a block of bytes to the specified SPI slave port.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			portNum - SPI device address
			data - Buffer containing data to write to SPI
			length - Length to write to SPI
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  The maximum length is 64 bytes.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWriteSpi(QHANDLE hDevice, UCHAR portNum, UCHAR *data, QWORD length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Check for valid length
	if ((length < 1) || (length > 64)) {
		lastError = QUICKUSB_ERROR_INVALID_PARAMETER;
		return FALSE;
	}
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER)  {
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_SPI;
		request.wIndex = SPI_READWRITE;
		request.wValue = portNum;
		request.wLength = length;
		request.pData = data;
		
		// Send control request to get string descriptor
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Simultaneously write and read a block of data to and from the
				specified SPI slave port.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			portNum - SPI device address
			data - Buffer containing data to write to SPI
			length - Length to write to SPI
 Output  :  data - Buffer containing data read from SPI
			length - Length read from SPI
			Returns non-zero on success, zero on failure.
 Notes   :  The maximum length is 64 bytes.
			This function uses the data buffer for both writing data to the SPI
				and to store read data from the SPI. Therefore, the data buffer
				will always be overwritten on each call to this function.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWriteReadSpi(QHANDLE hDevice, UCHAR portNum, UCHAR *data, QWORD length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Check for valid length
	if ((length < 1) || (length > 64)) {
		lastError = QUICKUSB_ERROR_INVALID_PARAMETER;
		return FALSE;
	}
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER)  {
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_SPI;
		request.wIndex = SPI_WRITEANDREAD;
		request.wValue = portNum;
		request.wLength = length;
		request.pData = data;
		
		// Send control request
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			return FALSE;
		}
		
		// Get the block of data
		request.bmRequestType = 1<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.wLength = request.wLenDone; // Set new request length as old request length
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			result = FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  To get I2C error.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
 Output  :  None.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
static void GetI2CError(QHANDLE hDevice) {
	QWORD I2CStatus;
	QULONG status;
	
	// The I2C error status is in the high order byte of setting 8, starting
	// with firmware 2.11 RC 7.
	status = QuickUsbReadSetting(hDevice, SETTING_I2CTL, &I2CStatus);
	
	if (status == TRUE) {
		// These values must match the values in FX2.H from the firmware.
		I2CStatus = I2CStatus >> 8;
		switch (I2CStatus) {
			case 6: // I2C_BERROR
				lastError = QUICKUSB_ERROR_I2C_BUS_ERROR;
				return;
			case 7: // I2C_NACK
				lastError = QUICKUSB_ERROR_I2C_NO_ACK;
				return;
			case 10: // I2C_SLAVE_WAIT
				lastError = QUICKUSB_ERROR_I2C_SLAVE_WAIT;
				return;
			case 11: // I2C_TIMEOUT
				lastError = QUICKUSB_ERROR_I2C_TIMEOUT;
				return;
		}
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Read a block of bytes from the specified I2C port
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - I2C device address
			length - Length to read from I2C
 Output  :  data - Buffer containing data read from I2C
			length - Length read from I2C
			Returns non-zero on success, zero on failure.
 Notes   :  The maximum length is 64 bytes.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadI2C(QHANDLE hDevice, unsigned short address, unsigned char *data, unsigned short *length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Check for valid length
	if ((*length < 1) || (*length > 64)) {
		lastError = QUICKUSB_ERROR_INVALID_PARAMETER;
		return FALSE;
	}
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER)  {
		// Build the vendor request
		request.bmRequestType = 1<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_I2C;
		request.wIndex = I2C_READWRITE;
		request.wValue = address;
		request.wLength = *length;
		request.pData = data;
		
		// Send control request to get string descriptor
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			GetI2CError(hDevice);
			result = FALSE;
		}
		else {
			*length = request.wLenDone;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Write a block of bytes to the specified I2C port.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - I2C device address
			data - Buffer containing data to write to I2C
			length - Length to write to I2C
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  The maximum length is 64 bytes.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWriteI2C(QHANDLE hDevice, QWORD address, QBYTE *data, QWORD length) {
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	
	result = TRUE;
	
	// Check for valid length
	if ((length < 1) || (length > 64)) {
		lastError = QUICKUSB_ERROR_INVALID_PARAMETER;
		return FALSE;
	}
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER)  {
		// Build the vendor request
		request.bmRequestType = 0<<7|2<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = QUICKUSB_I2C;
		request.wIndex = I2C_READWRITE;
		request.wValue = address;
		request.wLength = length;
		request.pData = data;
		
		// Send control request
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error set the last error code
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			GetI2CError(hDevice);
			result = FALSE;
		}
		
		return result;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  Write a block of bytes to the specified I2C port.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - I2C device address
			data - Buffer containing data to write to I2C
			length - Length to write to I2C
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  The maximum length is 64 bytes.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbCachedWriteI2C(QHANDLE hDevice, QWORD address, QBYTE *data, QWORD length) {
	return QuickUsbWriteI2C(hDevice, address | (length << 8), data, length);
}



/*-----------------------------------------------------------------------------
 Purpose :  Write a block of bytes to memory.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Byte offset into memory
			data - Buffer containing data to write to memory
			bytes - Length to write to memory
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  The address plus the number of bytes to write must not exceed 2048
				or the function will fail.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWriteStorage(QHANDLE hDevice, QWORD address, QBYTE *data, QWORD bytes) {
	QRESULT result;
	QBYTE payload[STORAGE_PAGE_SIZE + 2];
	QWORD bytesToWrite, numBytesWritten, eepromAddress, value;
	
	result = FALSE;
	numBytesWritten = 0;
	
	// Check that we are only writing a valid area of EEPROM
	if ((address + bytes) > STORAGE_SIZE) {
		return FALSE;
	}
	
	while (numBytesWritten < bytes)	{
		// Copy data to payload
		bytesToWrite = bytes - numBytesWritten;
		if (bytesToWrite > STORAGE_PAGE_SIZE) {
			bytesToWrite = STORAGE_PAGE_SIZE;
		}
		eepromAddress = STORAGE_BASE_ADDR + (address + numBytesWritten);
		payload[0] = (eepromAddress >> 8) & 0xff;
		payload[1] = (eepromAddress & 0xff);
		memcpy(&payload[2], &data[numBytesWritten], bytesToWrite);
		
		// Write the data to EEPROM
		result = QuickUsbWriteI2C(hDevice, STORAGE_I2C_ADDR, payload, bytesToWrite + 2);
		
		// Wait for I2C transaction to complete
		do {
			result = QuickUsbWriteI2C(hDevice, STORAGE_I2C_ADDR, payload, 2);
			QuickUsbReadSetting(hDevice, SETTING_I2CTL, &value);
		} while ((value >> 8) == 7);
		
		numBytesWritten += bytesToWrite;
	}
	
	return result;
}



/*-----------------------------------------------------------------------------
 Purpose :  Read a block of bytes from memory.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Byte offset into memory
			bytes - Length to read from memory
 Output  :  data - Buffer containing data read from memory
			Returns non-zero on success, zero on failure.
 Notes   :  The address plus the number of bytes to read must not exceed 2048
				or the function will fail.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadStorage(QHANDLE hDevice, QWORD address, QBYTE *data, QWORD bytes) {
	QRESULT result;
	QBYTE payload[STORAGE_PAGE_SIZE];
	QWORD bytesToRead, numBytesRead, eepromAddress;
	
	result = FALSE;
	numBytesRead = 0;
	
	// Check that we are only reading a valid area of EEPROM
	if ((address + bytes) > STORAGE_SIZE) {
		return FALSE;
	}
	
	while (numBytesRead < bytes) {
		// Copy data to payload
		bytesToRead = bytes - numBytesRead;
		if (bytesToRead > STORAGE_PAGE_SIZE) {
			bytesToRead = STORAGE_PAGE_SIZE;
		}
		eepromAddress = STORAGE_BASE_ADDR + (address + numBytesRead);
		payload[0] = (eepromAddress >> 8) & 0xff;
		payload[1] = (eepromAddress & 0xff);
		
		// Set starting address of the read
		result = QuickUsbWriteI2C(hDevice, STORAGE_I2C_ADDR, payload, 2);
		
		// Read the data
		result = QuickUsbReadI2C(hDevice, STORAGE_I2C_ADDR, &data[numBytesRead], &bytesToRead);
		
		numBytesRead += bytesToRead;
	}
	
	return result;
}



/*-----------------------------------------------------------------------------
 Purpose :  To set a timeout for synchronous bulk read/write calls to the
				driver.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			timeOut - Timeout value
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  The timeout is to the nearest millisecond.
			This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbSetTimeout(QHANDLE hDevice, QULONG timeOut) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  To get the driver version.
 Input   :  None.
 Output  :  MajorDriverVersion - Major driver version
			MinorDriverVersion - Minor driver version
			BuildDriverVersion - Build driver version
			Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbGetDriverVersion(QWORD *MajorDriverVersion, QWORD *MinorDriverVersion, QWORD *BuildDriverVersion) {
	QCHAR str[256];
	
	// Iterate the bus
	QuickUsbFindModules(str, 256);
	
	*MajorDriverVersion = DriverVersion.MajorVersion;
	*MinorDriverVersion = DriverVersion.MinorVersion;
	*BuildDriverVersion = DriverVersion.BuildVersion;
	
	if (!DriverVersion.DeviceFound) {
		return FALSE;
	}
	
	return TRUE;
}



/*-----------------------------------------------------------------------------
 Purpose :  To get the dll version.
 Input   :  None.
 Output  :  MajorDllVersion - Major Dll version
			MinorDllVersion - Minor Dll version
			BuildDllVersion - Build Dll version
			Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbGetDllVersion(QWORD *MajorDllVersion, QWORD *MinorDllVersion, QWORD *BuildDllVersion) {
	*MajorDllVersion = QUSB_DLL_MAJOR_VERSION;
	*MinorDllVersion = QUSB_DLL_MINOR_VERSION;
	*BuildDllVersion = QUSB_DLL_BUILD_VERSION;
	
	return TRUE;
}



/*-----------------------------------------------------------------------------
 Purpose :  To get the firmware version.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
 Output  :  MajorVersion - Major firmware version
			MinorVersion - Minor firmware version
			BuildVersion - Build firmware version
			Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbGetFirmwareVersion(QHANDLE hDevice, QWORD *MajorVersion, QWORD *MinorVersion, QWORD *BuildVersion) {
	IOUSBDeviceDescriptor deviceDescriptor;
	IOUSBDevRequest request;
	QusbDriverType type;
	HANDLE hDevHandle;
	kern_return_t err;
	QRESULT result;
	QWORD buildVer;
	QWORD bcdDevice;
	
	result = TRUE;
	buildVer = 0;
	bcdDevice = 0;
	
	// Get device type
	if (!QuickUsbGetDeviceType(hDevice, &type)) {
		return FALSE;
	}
	
	// Convert the generic handle to the device specific handle
	if (!QuickUsbGetDeviceHandle(hDevice, &hDevHandle)) {
		lastError = QUICKUSB_ERROR_CANNOT_FIND_DEVICE;         
		return FALSE;
	}
	
	// Handle using the QuickUSB driver
	if (type == QUSB_DRIVER) {
		// Build the vendor request
		request.bmRequestType = kUSBIn<<7|0<<5|0; // Direction<<7|RequestType<<5|Recepient
		request.bRequest = kUSBRqGetDescriptor;
		request.wIndex = 0;
		request.wValue = (kUSBDeviceDesc<<8);
		request.wLength = sizeof(IOUSBDeviceDescriptor);
		request.pData = &deviceDescriptor;
		
		// Query the device for interface information
		err = (*hDevHandle)->ControlRequest(hDevHandle,
											0,
											&request);
		
		// If there was an error, display the error status box
		if (err != kIOReturnSuccess) {
			lastError = QUICKUSB_ERROR_IOCTL_FAILED;
			return FALSE;
		}
		
		sleep(1);
		
		// Get the build version.  This requires firmware 2.11rc9 or later.
		if (!QuickUsbReadSetting(hDevice, SETTING_VERSIONBUILD, &buildVer)) {
			return FALSE;
		}
		
		bcdDevice = deviceDescriptor.bcdDevice;
		
#ifdef __ppc__
		swab(&deviceDescriptor.bcdDevice, &bcdDevice, sizeof(QWORD));
#endif
		
		*MajorVersion = (((bcdDevice & 0xF000) >> 12) * 10) +
		((bcdDevice & 0x0F00) >> 8);
		*MinorVersion = (((bcdDevice & 0x00F0) >> 4) * 10) +
		(bcdDevice & 0x000F);
		*BuildVersion = buildVer;
		
		return TRUE;
	}
	
	// Handle an undefined driver type
	else {
		lastError = QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE;
		return FALSE;
	}
}



/*-----------------------------------------------------------------------------
 Purpose :  To obtain USB and driver errors as well as driver state information.
 Input   :  None.
 Output  :  error - Last error value
			Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbGetLastError(unsigned long *error) {
	QULONG  UsbError;
	QWORD DriverError;
	QULONG  DriverState;
	GET_DRIVER_ERROR GetError;
	
	QuickUsbGetError((QHANDLE) OpenDeviceOffset, &GetError);
	UsbError = GetError.UsbError;
	DriverError = GetError.DriverError;
	DriverState = GetError.DriverState;
	
	*error = lastError;
	
	return TRUE;
}



/*-----------------------------------------------------------------------------
 Purpose :  Read a block of data values from the high-speed parallel port using
				an asynchronous function call.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			length - Length to read from high-speed parallel port
 Output  :  data - Buffer containing data read from high-speed parallel port
			length - Length read from high-speed parallel port
			transaction - Transaction identifier
			Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadDataAsync(QHANDLE hDevice, UCHAR *data, QULONG *length, UCHAR *transaction) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  Write a block of data values to the high-speed parallel port using
				an asynchronous function call.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			data - Buffer containing data to write to high-speed parallel port
			length - Length to read from high-speed parallel port
 Output  :  transaction - Transaction identifier
			Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWriteDataAsync(QHANDLE hDevice, UCHAR *data, QULONG length, UCHAR *transaction) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  Wait for an asynchronous transfer to complete.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			transaction - Transaction identifier
			immediate - Immediate value
 Output  :  bytecount - Length transferred asynchronously
			Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbAsyncWait(QHANDLE hDevice, QULONG *bytecount, UCHAR transaction, UCHAR immediate) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  To find default tag in the EEPROM.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
static QRETURN FindDefaultsInEeprom(QHANDLE hDevice) {
	UCHAR *eepromData;
	QWORD eepromAddress;
	QWORD fileLength;
	QWORD length;
	QWORD four;
	QWORD defaultAddress;
	QRESULT result;
	QWORD i;
	
	eepromAddress = 0;
	four = 4;
	defaultAddress = 0;
	
	eepromData = (UCHAR *)malloc(16384);
	if (eepromData == NULL) {
		lastError = QUICKUSB_ERROR_OUT_OF_MEMORY;         
		return FALSE;
	}
	
	// Check if this is an 8K or 16K EEPROM
	result = QuickUsbReadEepromData(hDevice, 0, eepromData + 0, &four);
	if (result == FALSE) {
		free(eepromData);
		return FALSE;
	}
	
	result = QuickUsbReadEepromData(hDevice, 8192, eepromData + 4, &four);
	if (result == FALSE) {
		free(eepromData);
		return FALSE;
	}
	
	// An 8K EEPROM will wrap after 8K
	if ((*(eepromData + 0) == *(eepromData + 4)) &&
		(*(eepromData + 1) == *(eepromData + 5)) &&
		(*(eepromData + 2) == *(eepromData + 6)) &&
		(*(eepromData + 3) == *(eepromData + 7))) {
		fileLength = 8192;
	}
	else {
		fileLength = 16384;
	}
	
	while (eepromAddress < fileLength) {
		// Calculate the block size
		if ((fileLength - eepromAddress) > MAX_CNTL_XFER_SIZE) {
			length = MAX_CNTL_XFER_SIZE;
		}
		else {
			length = fileLength - eepromAddress;
		}
		
		// Read the data from the EEPROM
		result = QuickUsbReadEepromData(hDevice,
										eepromAddress,
										eepromData + eepromAddress,
										&length);
		if (result == FALSE) {
			free(eepromData);
			return FALSE;
		}
		
		// Update the EEPROM address
		eepromAddress += length;
	}
	
	for (i = 0; i < (fileLength - 4); i++) {
		if (memcmp("DFLT", eepromData + i, 4) == 0) {
			defaultAddress = i + 4;
			result = TRUE;
			break;
		}
	}
	
	// DFLT string no found
	if (defaultAddress == 0) {
		defaultAddress = 0xFFFF; // Use special value
		result = FALSE;
	}
	
	QusbDeviceInfo[hDevice].defaultOffset = defaultAddress;
	free(eepromData);
	return result;
}



/*-----------------------------------------------------------------------------
 Purpose :  To read QuickUSB modules defaults.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Default address
 Output  :  data - Default value
			Returns non-zero on success, zero on failure.
 Notes   :  The defaults are non-volatile and are read into the settings table
				on power up.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadDefault(QHANDLE hDevice, QWORD address, QWORD *data) {
	QRESULT result;
	UCHAR EepromData[2];
	QWORD length;
	
	length = sizeof(QWORD);
	
	// Check for valid setting number
	if (address > 15) {
		lastError = QUICKUSB_ERROR_INVALID_PARAMETER;
		return FALSE;
	}
	
	// Never looked for defaults in this module
	if (QusbDeviceInfo[hDevice].defaultOffset == 0) {
		result = FindDefaultsInEeprom(hDevice);
		
		// Old firmware without DFLT section
		if (result == 0) {
			lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
			return FALSE;
		}
	}
	
	// Old firmware without DFLT section
	if (QusbDeviceInfo[hDevice].defaultOffset == 0xFFFF) {
		lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
		return FALSE;
	}
	
	// Write to the DFLT section of the EEPROM
	result = QuickUsbReadEepromData(hDevice, 
									QusbDeviceInfo[hDevice].defaultOffset + (address * sizeof(QWORD)),
									&EepromData[0],
									&length);
	
	if (result) {
		SWAPBYTES((char *)&EepromData[0], (char *)data, length);
		
		// Do not allow the user to read our reserved patch status byte.
		if (address == SETTING_PATCHES) {
			*data &= 0x00FF;
		}
	}
	
	return result;
}



/*-----------------------------------------------------------------------------
 Purpose :  To write QuickUSB modules defaults.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			address - Default address
			data - Default value
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  The defaults are non-volatile and are read into the settings table
				on power up.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbWriteDefault(QHANDLE hDevice, QWORD address, QWORD data) {
	QRESULT result;
	UCHAR EepromData[2];
	QWORD length;
	QWORD patch_status;
	
	length = sizeof(QWORD);
	
	// Check for valid setting number
	if (address > 15) {
		lastError = QUICKUSB_ERROR_INVALID_PARAMETER;
		return FALSE;
	}
	
	// Never looked for defaults in this module
	if (QusbDeviceInfo[hDevice].defaultOffset == 0) {
		result = FindDefaultsInEeprom(hDevice);
		
		// Old firmware without DFLT section
		if (result == 0) {
			lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
			return FALSE;
		}
	}
	
	// Old firmware without DFLT section
	if (QusbDeviceInfo[hDevice].defaultOffset == 0xFFFF) {
		lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
		return FALSE;
	}
	
	// Get the current firmware patch status setting.
	result = QuickUsbReadEepromData(hDevice, 
									QusbDeviceInfo[hDevice].defaultOffset + (SETTING_PATCHES * sizeof(QWORD)),
									&EepromData[0],
									&length);
	
	SWAPBYTES((char *)&EepromData[0], (char *)&patch_status, length);
	patch_status |= PATCHED_DEFAULTS;
	
	// Do not allow user writes to the patch status byte.
	if (address == SETTING_PATCHES) {
		data &= 0x00FF;
		data |= (patch_status & 0xFF00);
	}
	
	SWAPBYTES((char *)&data, (char *)&EepromData[0], length);
	
	// Write to the DFLT section of the EEPROM
	result = QuickUsbWriteEepromData(hDevice, 
									 QusbDeviceInfo[hDevice].defaultOffset + (address * sizeof(QWORD)),
									 &EepromData[0],
									 length);
	
	if (result == FALSE) {
		return FALSE;
	}
	
	if (address == SETTING_PATCHES) {
		return result;
	}
	
	// Set that we patched a default
	SWAPBYTES((char *)&patch_status, (char *)&EepromData[0], length);
	
	result = QuickUsbWriteEepromData(hDevice, 
									 QusbDeviceInfo[hDevice].defaultOffset + (SETTING_PATCHES * sizeof(QWORD)),
									 &EepromData[0],
									 length);
	
	return result;
}



/*-----------------------------------------------------------------------------
 Purpose :  Read data stream to file.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			filename - File to read
			blockSize - Size of block
			fileLength - Length of file
 Output  :  Returns non-zero on success, zero on failure.
 Notes   :  None.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadDataStreamToFile(QHANDLE hDevice, QCHAR *filename, QULONG blockSize, QULONG fileLength) {
	UCHAR *buffer[NUMSTREAMBUFFERS];
	UCHAR  transaction[NUMSTREAMBUFFERS];
	QRESULT result;
	UCHAR index;
	BOOL shutdown;
	QWORD lastIndex;
	QULONG bytesread, bytecount;
	size_t byteswritten;
	FILE *outFile;
	
	shutdown = FALSE;
	bytecount = 0;
	
	// Allocate the buffers
	for (index = 0; index < NUMSTREAMBUFFERS; index++) {
		buffer[index] = (UCHAR *)malloc(blockSize);
		if (buffer[index] == NULL) {
			return FALSE;
		}
	}
	
	// Set QuickUSB I/O timeout to 100 seconds
	// This is required with a 64 Meg block size and 253 buffers.
	// This value should probably be calculated to something reasonable.
	result = QuickUsbSetTimeout(hDevice, 1000000);
	if (result == FALSE) {
		return FALSE;
	}
	
	// Open the output file
	outFile = fopen((const char *)filename, "w+b");
	if (outFile == NULL) {
		return FALSE;
	}
	
	// Launch all the reads
	for (index = 0; index < NUMSTREAMBUFFERS; index++) {
		result = QuickUsbReadDataAsync(hDevice,
									   buffer[index],
									   &blockSize,
									   &transaction[index]);
		if (result == FALSE) {
			fclose(outFile);
			return FALSE;
		}
	}
	
	index = 0;
	bytecount = 0;
	while (TRUE) {
		// Wait for the next QuickUSB read operation to finish
		result = QuickUsbAsyncWait(hDevice,
								   &bytesread,
								   transaction[index],
								   FALSE);
		if (result == FALSE) {
			fclose(outFile);
			return FALSE;
		}
		
		if ((shutdown == TRUE) && (index == lastIndex)) {
			break;
		}
		
		// Check if any key was pressed
		if (shutdown == FALSE) {
			if (bytecount >= fileLength) {
				shutdown = TRUE;
			}
		}
		
		// Did write function complete?
		if (bytesread == blockSize) {
			bytecount += blockSize;
			
			// Write the block to disk
			byteswritten = fwrite(buffer[index], 1, blockSize, outFile);
			if (byteswritten != blockSize) {
				fclose(outFile);
				return FALSE;
			}
			
			// Start a new QuickUSB read
			if (shutdown == FALSE) {
				lastIndex = index;
				result = QuickUsbReadDataAsync(hDevice, buffer[index], &blockSize, &transaction[index]);
				if (result == FALSE) {
					fclose(outFile);
					return FALSE;
				}
			}
		}
		
		// Increment index
		index++;
		if (index == NUMSTREAMBUFFERS) {
			index = 0;
		}
	}
	
	// Close the output file
	fclose(outFile);
	
	// Free the buffers
	for (index = 0; index < NUMSTREAMBUFFERS; index++) {
		free(buffer[index]);
	}
	
	return TRUE;
}



/*-----------------------------------------------------------------------------
 Purpose :  N/A
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			filename - N/A
			options - N/A
 Output  :  result - N/A
			Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbProgramEEPROM(QHANDLE hDevice, QCHAR *fileName, QWORD options, QWORD *result) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  N/A
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			filename - N/A
 Output  :  result - N/A
			Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbVerifyEEPROM(QHANDLE hDevice, QCHAR *filename, QWORD *result) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  N/A.
 Input   :  deviceName - N/A
 Output  :  result - N/A
			Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbIChipPackIsProgrammed(QCHAR *deviceName, QBYTE *result) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  N/A.
 Input   :  deviceName - N/A
			accountName - N/A
			accountPassword - N/A
			qusbFirmwareFile - N/A
			options - N/A
 Output  :  result - N/A
			Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbIChipPack(QCHAR *deviceName, QCHAR *accountName, QCHAR *accountPassword, QCHAR *qusbFirmwareFile, QWORD options, QWORD *result) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  N/A.
 Input   :  accountName - N/A
			accountPassword - N/A
 Output  :  remainingLicenses - N/A
			Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbIChipPackGetNumLicenses(QCHAR *accountName, QCHAR *accountPassword, QWORD *remainingLicenses) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  N/A.
 Input   :  qucFile - N/A
 Output  :  qucData - N/A
			Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbReadQucData(QCHAR *qucFile, struct QUCDATASTRUCT *qucData) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  N/A.
 Input   :  originalQucFile - N/A
 Output  :  newQucFile - N/A
			newQucData - N/A
			Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbSaveQucData(QCHAR *originalQucFile, QCHAR *newQucFile, QUCDATASTRUCT *newQucData) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}



/*-----------------------------------------------------------------------------
 Purpose :  N/A.
 Input   :  hDevice - Offset into array of _QUSB_DEVICE_INFO structures
			qucFile - N/A
			qucData - N/A
 Output  :  result - N/A
			Returns non-zero on success, zero on failure.
 Notes   :  This function is currently not supported.
 -----------------------------------------------------------------------------*/
QRETURN QuickUsbCustomize(QHANDLE hDevice, QCHAR *qucFile, QUCDATASTRUCT *qucData, QWORD *result) {
	lastError = QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED;
	return FALSE;
}
