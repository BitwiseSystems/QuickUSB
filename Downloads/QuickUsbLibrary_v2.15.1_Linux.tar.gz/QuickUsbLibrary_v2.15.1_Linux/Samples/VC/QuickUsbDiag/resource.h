//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by QuickUsbDiag.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_QUICKUSBDIAG_DIALOG         102
#define IDR_MAINFRAME                   128
#define ModuleComboBox                  1001
#define SerialNumberEditBox             1002
#define ModuleDescriptionEditBox        1003
#define HwRevEditBox                    1004
#define BusSpeedEditBox                 1005
#define FpgaBrowseButton                1006
#define FpgaFileEditBox                 1007
#define FpgaUploadButton                1008
#define FpgaStatusButton                1009
#define FpgaLoadProgressBar             1010
#define I2CAddressTextBox               1011
#define I2CLengthTextBox                1012
#define I2CReadButton                   1013
#define I2CWriteButton                  1014
#define I2CBrowseButton                 1015
#define I2CFileTextBox                  1016
#define I2CDataTextBox                  1016
#define DataBrowseButton                1017
#define DataReadBrowseButton            1017
#define DataFileTextBox                 1018
#define DataReadFileTextBox             1018
#define DataAddressTextBox              1019
#define DataLengthTextBox               1020
#define DataReadButton                  1021
#define DataWriteButton                 1022
#define IncrementAddressCheckBox        1023
#define AsyncCheckBox                   1024
#define BufferSizeTextBox               1025
#define BufferCountTextBox              1026
#define BufferCountLabel                1027
#define BufferSizeLabel                 1028
#define StatusMessage                   1029
#define DataWriteBrowseButton           1030
#define DataWriteFileTextBox            1031
#define SpiPortComboBox                 1032
#define SpiLengthTextBox                1033
#define SpiReadButton                   1034
#define SpiWriteButton                  1035
#define SpiWriteReadButton              1036
#define SpiDataTextBox                  1037
#define Rs232PortComboBox               1038
#define Rs232BaudComboBox               1039
#define Rs232ReadButton                 1040
#define Rs232WriteButton                1041
#define Rs232FlushButton                1042
#define Rs232DataTextBox                1043
#define Rs232CharsWaitingTextBox        1044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
