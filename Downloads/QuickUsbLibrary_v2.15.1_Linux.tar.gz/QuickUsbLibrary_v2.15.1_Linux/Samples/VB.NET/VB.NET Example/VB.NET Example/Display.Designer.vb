﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.QuickUsbWinForms1 = New BitwiseSystems.QuickUsbWinForms
        Me.PortACheckBox = New System.Windows.Forms.CheckBox
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'QuickUsbWinForms1
        '
        Me.QuickUsbWinForms1.AutoScroll = True
        Me.QuickUsbWinForms1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.QuickUsbWinForms1.Dock = System.Windows.Forms.DockStyle.Top
        Me.QuickUsbWinForms1.Location = New System.Drawing.Point(0, 0)
        Me.QuickUsbWinForms1.MinimumSize = New System.Drawing.Size(100, 40)
        Me.QuickUsbWinForms1.Name = "QuickUsbWinForms1"
        Me.QuickUsbWinForms1.ScanEnabled = True
        Me.QuickUsbWinForms1.ScanInterval = 500
        Me.QuickUsbWinForms1.ScanOnLoad = True
        Me.QuickUsbWinForms1.Scrollable = True
        Me.QuickUsbWinForms1.Size = New System.Drawing.Size(283, 63)
        Me.QuickUsbWinForms1.TabIndex = 0
        Me.QuickUsbWinForms1.View = System.Windows.Forms.View.SmallIcon
        '
        'PortACheckBox
        '
        Me.PortACheckBox.AutoSize = True
        Me.PortACheckBox.Location = New System.Drawing.Point(88, 82)
        Me.PortACheckBox.Name = "PortACheckBox"
        Me.PortACheckBox.Size = New System.Drawing.Size(101, 17)
        Me.PortACheckBox.TabIndex = 1
        Me.PortACheckBox.Text = "PortACheckBox"
        Me.PortACheckBox.UseVisualStyleBackColor = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 136)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(283, 22)
        Me.StatusStrip1.TabIndex = 2
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(0, 17)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(283, 158)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.PortACheckBox)
        Me.Controls.Add(Me.QuickUsbWinForms1)
        Me.Name = "Form1"
        Me.Text = "QuickUSB Port A Example"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents QuickUsbWinForms1 As BitwiseSystems.QuickUsbWinForms
    Friend WithEvents PortACheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel

End Class
