﻿Public Class Form1
    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PortACheckBox.CheckedChanged
        Dim data(1) As Byte

        ' Make port A all outputs
        QuickUsbWinForms1.SelectedModule.WritePortDir(BitwiseSystems.QuickUsb.Port.A, &HFF)

        If (PortACheckBox.Checked) Then
            data(0) = &HFF
            QuickUsbWinForms1.SelectedModule.WritePort(BitwiseSystems.QuickUsb.Port.A, data, 1)
            ToolStripStatusLabel1.Text = "Writing FF to port A"
        Else
            data(0) = &H0
            QuickUsbWinForms1.SelectedModule.WritePort(BitwiseSystems.QuickUsb.Port.A, data, 1)
            ToolStripStatusLabel1.Text = "Writing 00 to port A"
        End If
    End Sub
End Class
