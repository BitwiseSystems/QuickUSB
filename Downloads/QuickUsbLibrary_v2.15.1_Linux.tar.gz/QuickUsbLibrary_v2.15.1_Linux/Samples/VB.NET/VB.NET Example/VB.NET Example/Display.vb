﻿Public Class Form1
    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PortACheckBox.CheckedChanged
        Dim data(1) As Byte
        Dim qusb As BitwiseSystems.QuickUsb

        ' Ensure a module is selected
        qusb = QuickUsbWinForms1.SelectedModule
        If qusb Is Nothing Then
            Exit Sub
        End If

        ' Make port A all outputs
        qusb.WritePortDir(BitwiseSystems.QuickUsb.Port.A, &HFF)

        If (PortACheckBox.Checked) Then
            data(0) = &HFF
            qusb.WritePort(BitwiseSystems.QuickUsb.Port.A, data, 1)
            ToolStripStatusLabel1.Text = "Writing FF to port A"
        Else
            data(0) = &H0
            qusb.WritePort(BitwiseSystems.QuickUsb.Port.A, data, 1)
            ToolStripStatusLabel1.Text = "Writing 00 to port A"
        End If
    End Sub
End Class
