#!/bin/bash
sudo insmod /lib/modules/$(uname -r)/kernel/drivers/usb/misc/qusb_lnx.ko
