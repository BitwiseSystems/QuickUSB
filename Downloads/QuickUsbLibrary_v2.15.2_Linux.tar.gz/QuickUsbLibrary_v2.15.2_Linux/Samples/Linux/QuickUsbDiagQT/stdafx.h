/* This dummy file is required so CQuickUsb.cpp will compile
   with both Borland and Microsoft compilers */
 