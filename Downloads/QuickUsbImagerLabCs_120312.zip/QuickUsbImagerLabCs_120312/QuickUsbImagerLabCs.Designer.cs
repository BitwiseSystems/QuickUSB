﻿namespace BitwiseSystems
{
	partial class QuickUsbImagerLabCs
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuickUsbImagerLabCs));
            BitwiseSystems.QuickUsb quickUsb1 = new BitwiseSystems.QuickUsb();
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.frameRateToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.dataRateToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.quickUSBSupportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quickUSBFAQToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.bRegExWrite = new System.Windows.Forms.Button();
            this.bRegExReset = new System.Windows.Forms.Button();
            this.cbbRegExRegister = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btRegExValue = new BitwiseSystems.BitTwiddler();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbVideoRecord = new System.Windows.Forms.CheckBox();
            this.bVideoBrowse = new System.Windows.Forms.Button();
            this.cbVideoAcquire = new System.Windows.Forms.CheckBox();
            this.tbVideoFile = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bLoadSettings = new System.Windows.Forms.Button();
            this.tbSensorAddress = new System.Windows.Forms.TextBox();
            this.tbSensorType = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pbFrame = new System.Windows.Forms.PictureBox();
            this.gbClock = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbClockPix = new System.Windows.Forms.ComboBox();
            this.cbClockCPU = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.updateTimer = new System.Windows.Forms.Timer(this.components);
            this.quickUsbWinForms = new BitwiseSystems.QuickUsbWinForms();
            this.statusStrip.SuspendLayout();
            this.menuStrip.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFrame)).BeginInit();
            this.gbClock.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // BottomToolStripPanel
            // 
            resources.ApplyResources(this.BottomToolStripPanel, "BottomToolStripPanel");
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            // 
            // TopToolStripPanel
            // 
            resources.ApplyResources(this.TopToolStripPanel, "TopToolStripPanel");
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            // 
            // RightToolStripPanel
            // 
            resources.ApplyResources(this.RightToolStripPanel, "RightToolStripPanel");
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            // 
            // LeftToolStripPanel
            // 
            resources.ApplyResources(this.LeftToolStripPanel, "LeftToolStripPanel");
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            // 
            // ContentPanel
            // 
            resources.ApplyResources(this.ContentPanel, "ContentPanel");
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel,
            this.frameRateToolStripStatusLabel,
            this.dataRateToolStripStatusLabel,
            this.toolStripProgressBar});
            resources.ApplyResources(this.statusStrip, "statusStrip");
            this.statusStrip.Name = "statusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            resources.ApplyResources(this.toolStripStatusLabel, "toolStripStatusLabel");
            this.toolStripStatusLabel.Spring = true;
            // 
            // frameRateToolStripStatusLabel
            // 
            this.frameRateToolStripStatusLabel.Name = "frameRateToolStripStatusLabel";
            resources.ApplyResources(this.frameRateToolStripStatusLabel, "frameRateToolStripStatusLabel");
            // 
            // dataRateToolStripStatusLabel
            // 
            this.dataRateToolStripStatusLabel.Name = "dataRateToolStripStatusLabel";
            resources.ApplyResources(this.dataRateToolStripStatusLabel, "dataRateToolStripStatusLabel");
            // 
            // toolStripProgressBar
            // 
            this.toolStripProgressBar.Name = "toolStripProgressBar";
            resources.ApplyResources(this.toolStripProgressBar, "toolStripProgressBar");
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpMenu});
            resources.ApplyResources(this.menuStrip, "menuStrip");
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem,
            this.saveToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            resources.ApplyResources(this.fileToolStripMenuItem, "fileToolStripMenuItem");
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            resources.ApplyResources(this.exitToolStripMenuItem, "exitToolStripMenuItem");
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            resources.ApplyResources(this.saveToolStripMenuItem, "saveToolStripMenuItem");
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // helpMenu
            // 
            this.helpMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quickUSBSupportToolStripMenuItem,
            this.quickUSBFAQToolStripMenuItem,
            this.toolStripSeparator8,
            this.aboutToolStripMenuItem});
            this.helpMenu.Name = "helpMenu";
            resources.ApplyResources(this.helpMenu, "helpMenu");
            // 
            // quickUSBSupportToolStripMenuItem
            // 
            this.quickUSBSupportToolStripMenuItem.Name = "quickUSBSupportToolStripMenuItem";
            resources.ApplyResources(this.quickUSBSupportToolStripMenuItem, "quickUSBSupportToolStripMenuItem");
            this.quickUSBSupportToolStripMenuItem.Click += new System.EventHandler(this.quickUSBSupportToolStripMenuItem_Click);
            // 
            // quickUSBFAQToolStripMenuItem
            // 
            this.quickUSBFAQToolStripMenuItem.Name = "quickUSBFAQToolStripMenuItem";
            resources.ApplyResources(this.quickUSBFAQToolStripMenuItem, "quickUSBFAQToolStripMenuItem");
            this.quickUSBFAQToolStripMenuItem.Click += new System.EventHandler(this.quickUSBFAQToolStripMenuItem_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            resources.ApplyResources(this.toolStripSeparator8, "toolStripSeparator8");
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            resources.ApplyResources(this.aboutToolStripMenuItem, "aboutToolStripMenuItem");
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.bRegExWrite);
            this.groupBox4.Controls.Add(this.bRegExReset);
            this.groupBox4.Controls.Add(this.cbbRegExRegister);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.btRegExValue);
            resources.ApplyResources(this.groupBox4, "groupBox4");
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.TabStop = false;
            // 
            // bRegExWrite
            // 
            resources.ApplyResources(this.bRegExWrite, "bRegExWrite");
            this.bRegExWrite.Name = "bRegExWrite";
            this.bRegExWrite.UseVisualStyleBackColor = true;
            this.bRegExWrite.Click += new System.EventHandler(this.bRegExWrite_Click);
            // 
            // bRegExReset
            // 
            resources.ApplyResources(this.bRegExReset, "bRegExReset");
            this.bRegExReset.Name = "bRegExReset";
            this.bRegExReset.UseVisualStyleBackColor = true;
            this.bRegExReset.Click += new System.EventHandler(this.bRegExWrite_Click);
            // 
            // cbbRegExRegister
            // 
            resources.ApplyResources(this.cbbRegExRegister, "cbbRegExRegister");
            this.cbbRegExRegister.FormattingEnabled = true;
            this.cbbRegExRegister.Name = "cbbRegExRegister";
            this.cbbRegExRegister.Sorted = true;
            this.cbbRegExRegister.SelectedIndexChanged += new System.EventHandler(this.cbbRegExRegister_SelectedIndexChanged);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // btRegExValue
            // 
            resources.ApplyResources(this.btRegExValue, "btRegExValue");
            this.btRegExValue.Bits = ((byte)(16));
            this.btRegExValue.Caption = "Value:";
            this.btRegExValue.CaptionWidth = 51;
            this.btRegExValue.Name = "btRegExValue";
            this.btRegExValue.TagInt = 1;
            this.btRegExValue.ToolTips = null;
            this.btRegExValue.Value = ((uint)(0u));
            this.btRegExValue.ValueChanged += new BitwiseSystems.ValueChangedHandler(this.btRegExValue_ValueChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbVideoRecord);
            this.groupBox2.Controls.Add(this.bVideoBrowse);
            this.groupBox2.Controls.Add(this.cbVideoAcquire);
            this.groupBox2.Controls.Add(this.tbVideoFile);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // cbVideoRecord
            // 
            resources.ApplyResources(this.cbVideoRecord, "cbVideoRecord");
            this.cbVideoRecord.Name = "cbVideoRecord";
            this.cbVideoRecord.UseVisualStyleBackColor = true;
            this.cbVideoRecord.CheckedChanged += new System.EventHandler(this.cbVideoRecord_CheckedChanged);
            // 
            // bVideoBrowse
            // 
            resources.ApplyResources(this.bVideoBrowse, "bVideoBrowse");
            this.bVideoBrowse.Name = "bVideoBrowse";
            this.bVideoBrowse.UseVisualStyleBackColor = true;
            this.bVideoBrowse.Click += new System.EventHandler(this.bVideoBrowse_Click);
            // 
            // cbVideoAcquire
            // 
            resources.ApplyResources(this.cbVideoAcquire, "cbVideoAcquire");
            this.cbVideoAcquire.Name = "cbVideoAcquire";
            this.cbVideoAcquire.UseVisualStyleBackColor = true;
            this.cbVideoAcquire.CheckedChanged += new System.EventHandler(this.cbVideoAcquire_CheckedChanged);
            // 
            // tbVideoFile
            // 
            resources.ApplyResources(this.tbVideoFile, "tbVideoFile");
            this.tbVideoFile.Name = "tbVideoFile";
            this.tbVideoFile.ReadOnly = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bLoadSettings);
            this.groupBox1.Controls.Add(this.tbSensorAddress);
            this.groupBox1.Controls.Add(this.tbSensorType);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // bLoadSettings
            // 
            resources.ApplyResources(this.bLoadSettings, "bLoadSettings");
            this.bLoadSettings.Name = "bLoadSettings";
            this.bLoadSettings.UseVisualStyleBackColor = true;
            this.bLoadSettings.Click += new System.EventHandler(this.bLoadSettings_Click);
            // 
            // tbSensorAddress
            // 
            resources.ApplyResources(this.tbSensorAddress, "tbSensorAddress");
            this.tbSensorAddress.Name = "tbSensorAddress";
            this.tbSensorAddress.ReadOnly = true;
            // 
            // tbSensorType
            // 
            resources.ApplyResources(this.tbSensorType, "tbSensorType");
            this.tbSensorType.Name = "tbSensorType";
            this.tbSensorType.ReadOnly = true;
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // pbFrame
            // 
            resources.ApplyResources(this.pbFrame, "pbFrame");
            this.pbFrame.Name = "pbFrame";
            this.pbFrame.TabStop = false;
            this.pbFrame.Click += new System.EventHandler(this.pbFrame_Click);
            // 
            // gbClock
            // 
            this.gbClock.Controls.Add(this.label5);
            this.gbClock.Controls.Add(this.label4);
            this.gbClock.Controls.Add(this.cbClockPix);
            this.gbClock.Controls.Add(this.cbClockCPU);
            resources.ApplyResources(this.gbClock, "gbClock");
            this.gbClock.Name = "gbClock";
            this.gbClock.TabStop = false;
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // cbClockPix
            // 
            this.cbClockPix.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cbClockPix, "cbClockPix");
            this.cbClockPix.FormattingEnabled = true;
            this.cbClockPix.Name = "cbClockPix";
            // 
            // cbClockCPU
            // 
            this.cbClockCPU.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.cbClockCPU, "cbClockCPU");
            this.cbClockCPU.FormattingEnabled = true;
            this.cbClockCPU.Items.AddRange(new object[] {
            resources.GetString("cbClockCPU.Items"),
            resources.GetString("cbClockCPU.Items1"),
            resources.GetString("cbClockCPU.Items2")});
            this.cbClockCPU.Name = "cbClockCPU";
            this.cbClockCPU.SelectedIndexChanged += new System.EventHandler(this.cbClockCPU_SelectedIndexChanged);
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.Add(this.pbFrame);
            this.panel1.Name = "panel1";
            // 
            // updateTimer
            // 
            this.updateTimer.Enabled = true;
            this.updateTimer.Interval = 30;
            this.updateTimer.Tick += new System.EventHandler(this.updateTimer_Tick);
            // 
            // quickUsbWinForms
            // 
            resources.ApplyResources(this.quickUsbWinForms, "quickUsbWinForms");
            this.quickUsbWinForms.AutoSelectFirstItem = true;
            this.quickUsbWinForms.MaximumSize = new System.Drawing.Size(275, 250);
            this.quickUsbWinForms.MinimumSize = new System.Drawing.Size(0, 45);
            this.quickUsbWinForms.Name = "quickUsbWinForms";
            this.quickUsbWinForms.ScanEnabled = true;
            this.quickUsbWinForms.ScanInterval = 500;
            this.quickUsbWinForms.ScanOnLoad = true;
            this.quickUsbWinForms.Scrollable = true;
            quickUsb1.Name = "QUSB-0";
            this.quickUsbWinForms.SelectedModule = quickUsb1;
            this.quickUsbWinForms.SelectedModules = new BitwiseSystems.QuickUsb[] {
        quickUsb1};
            this.quickUsbWinForms.ShowUnprogrammedDevices = false;
            this.quickUsbWinForms.View = System.Windows.Forms.View.SmallIcon;
            this.quickUsbWinForms.SelectionChanged += new BitwiseSystems.QuickUsbWinForms.SelectionChangedHandler(this.quickUsbWinForms_SelectionChanged);
            // 
            // QuickUsbImagerLabCs
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gbClock);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.quickUsbWinForms);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.MainMenuStrip = this.menuStrip;
            this.Name = "QuickUsbImagerLabCs";
            this.Load += new System.EventHandler(this.QuickUsbImagerLabCs_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.QuickUsbImagerLabCs_FormClosing);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFrame)).EndInit();
            this.gbClock.ResumeLayout(false);
            this.gbClock.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		private System.Windows.Forms.StatusStrip statusStrip;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
		private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar;
		private System.Windows.Forms.MenuStrip menuStrip;
		private System.Windows.Forms.ToolStripMenuItem helpMenu;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
		private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
		private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
		private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
		private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
		private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
		private System.Windows.Forms.ToolStripContentPanel ContentPanel;
		private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem quickUSBFAQToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem quickUSBSupportToolStripMenuItem;
		private System.Windows.Forms.OpenFileDialog openFileDialog;
		internal BitwiseSystems.QuickUsbWinForms quickUsbWinForms;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.Button bRegExWrite;
		private System.Windows.Forms.Button bRegExReset;
		private System.Windows.Forms.ComboBox cbbRegExRegister;
		private System.Windows.Forms.Label label3;
		private BitTwiddler btRegExValue;
        private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.CheckBox cbVideoRecord;
        private System.Windows.Forms.Button bVideoBrowse;
		private System.Windows.Forms.CheckBox cbVideoAcquire;
		private System.Windows.Forms.TextBox tbVideoFile;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button bLoadSettings;
		private System.Windows.Forms.TextBox tbSensorAddress;
		private System.Windows.Forms.TextBox tbSensorType;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pbFrame;
		private System.Windows.Forms.GroupBox gbClock;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox cbClockPix;
        private System.Windows.Forms.ComboBox cbClockCPU;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel frameRateToolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel dataRateToolStripStatusLabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer updateTimer;
	}
}



