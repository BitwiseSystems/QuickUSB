namespace QuickUsbDiagCs
{
    partial class Display
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.diagTabControl = new System.Windows.Forms.TabControl();
            this.fpgaCommandTabPage = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.fpgaUploadPanel = new System.Windows.Forms.Panel();
            this.isFpgaConfiguredButton = new System.Windows.Forms.Button();
            this.browseFpgaFileButton = new System.Windows.Forms.Button();
            this.fpgaFileTextBox = new System.Windows.Forms.TextBox();
            this.uploadFpgaButton = new System.Windows.Forms.Button();
            this.fpgaButtonFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.alteraPsRadioButton = new System.Windows.Forms.RadioButton();
            this.xilinxSsRadioButton = new System.Windows.Forms.RadioButton();
            this.jtagRadioButton = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.dataTabPage = new System.Windows.Forms.TabPage();
            this.ioPortsTabPage = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rs232tabPage = new System.Windows.Forms.TabPage();
            this.spiTabPage = new System.Windows.Forms.TabPage();
            this.i2cTabPage = new System.Windows.Forms.TabPage();
            this.settingsTabPage = new System.Windows.Forms.TabPage();
            this.defaultsTabPage = new System.Windows.Forms.TabPage();
            this.storageTabPage = new System.Windows.Forms.TabPage();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.quickUsbWinForms = new BitwiseSystems.QuickUsbWinForms();
            this.bitTwiddler11 = new QuickUsbDiagCs.BitTwiddler();
            this.portEVal = new QuickUsbDiagCs.BitTwiddler();
            this.portEDir = new QuickUsbDiagCs.BitTwiddler();
            this.portDVal = new QuickUsbDiagCs.BitTwiddler();
            this.portDDir = new QuickUsbDiagCs.BitTwiddler();
            this.portCVal = new QuickUsbDiagCs.BitTwiddler();
            this.portCDir = new QuickUsbDiagCs.BitTwiddler();
            this.portBVal = new QuickUsbDiagCs.BitTwiddler();
            this.portBDir = new QuickUsbDiagCs.BitTwiddler();
            this.portAVal = new QuickUsbDiagCs.BitTwiddler();
            this.portADir = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler12 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler40 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler39 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler38 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler37 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler36 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler35 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler34 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler33 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler32 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler31 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler30 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler18 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler15 = new QuickUsbDiagCs.BitTwiddler();
            this.bitTwiddler14 = new QuickUsbDiagCs.BitTwiddler();
            this.settingbitTwiddler = new QuickUsbDiagCs.BitTwiddler();
            this.diagTabControl.SuspendLayout();
            this.fpgaCommandTabPage.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.fpgaUploadPanel.SuspendLayout();
            this.fpgaButtonFlowLayoutPanel.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.ioPortsTabPage.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.settingsTabPage.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // diagTabControl
            // 
            this.diagTabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.diagTabControl.Controls.Add(this.fpgaCommandTabPage);
            this.diagTabControl.Controls.Add(this.dataTabPage);
            this.diagTabControl.Controls.Add(this.ioPortsTabPage);
            this.diagTabControl.Controls.Add(this.rs232tabPage);
            this.diagTabControl.Controls.Add(this.spiTabPage);
            this.diagTabControl.Controls.Add(this.i2cTabPage);
            this.diagTabControl.Controls.Add(this.settingsTabPage);
            this.diagTabControl.Controls.Add(this.defaultsTabPage);
            this.diagTabControl.Controls.Add(this.storageTabPage);
            this.diagTabControl.Location = new System.Drawing.Point(0, 92);
            this.diagTabControl.Multiline = true;
            this.diagTabControl.Name = "diagTabControl";
            this.diagTabControl.SelectedIndex = 0;
            this.diagTabControl.Size = new System.Drawing.Size(480, 420);
            this.diagTabControl.TabIndex = 1;
            // 
            // fpgaCommandTabPage
            // 
            this.fpgaCommandTabPage.Controls.Add(this.groupBox7);
            this.fpgaCommandTabPage.Controls.Add(this.groupBox6);
            this.fpgaCommandTabPage.Location = new System.Drawing.Point(4, 22);
            this.fpgaCommandTabPage.Name = "fpgaCommandTabPage";
            this.fpgaCommandTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.fpgaCommandTabPage.Size = new System.Drawing.Size(472, 394);
            this.fpgaCommandTabPage.TabIndex = 0;
            this.fpgaCommandTabPage.Text = "FGPA/Command";
            this.fpgaCommandTabPage.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.fpgaUploadPanel);
            this.groupBox7.Location = new System.Drawing.Point(6, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(466, 82);
            this.groupBox7.TabIndex = 6;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "FPGA Configuration";
            // 
            // fpgaUploadPanel
            // 
            this.fpgaUploadPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.fpgaUploadPanel.Controls.Add(this.isFpgaConfiguredButton);
            this.fpgaUploadPanel.Controls.Add(this.browseFpgaFileButton);
            this.fpgaUploadPanel.Controls.Add(this.fpgaFileTextBox);
            this.fpgaUploadPanel.Controls.Add(this.uploadFpgaButton);
            this.fpgaUploadPanel.Controls.Add(this.fpgaButtonFlowLayoutPanel);
            this.fpgaUploadPanel.Location = new System.Drawing.Point(7, 24);
            this.fpgaUploadPanel.Name = "fpgaUploadPanel";
            this.fpgaUploadPanel.Size = new System.Drawing.Size(452, 48);
            this.fpgaUploadPanel.TabIndex = 5;
            // 
            // isFpgaConfiguredButton
            // 
            this.isFpgaConfiguredButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.isFpgaConfiguredButton.Location = new System.Drawing.Point(353, 25);
            this.isFpgaConfiguredButton.Name = "isFpgaConfiguredButton";
            this.isFpgaConfiguredButton.Size = new System.Drawing.Size(20, 23);
            this.isFpgaConfiguredButton.TabIndex = 5;
            this.isFpgaConfiguredButton.Text = "?";
            this.isFpgaConfiguredButton.UseVisualStyleBackColor = true;
            this.isFpgaConfiguredButton.Click += new System.EventHandler(this.isFpgaConfiguredButton_Click);
            // 
            // browseFpgaFileButton
            // 
            this.browseFpgaFileButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.browseFpgaFileButton.Location = new System.Drawing.Point(379, 2);
            this.browseFpgaFileButton.Name = "browseFpgaFileButton";
            this.browseFpgaFileButton.Size = new System.Drawing.Size(73, 23);
            this.browseFpgaFileButton.TabIndex = 7;
            this.browseFpgaFileButton.Text = "Browse";
            this.browseFpgaFileButton.UseVisualStyleBackColor = true;
            this.browseFpgaFileButton.Click += new System.EventHandler(this.browseFpgaFileButton_Click);
            // 
            // fpgaFileTextBox
            // 
            this.fpgaFileTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.fpgaFileTextBox.Location = new System.Drawing.Point(3, 5);
            this.fpgaFileTextBox.Name = "fpgaFileTextBox";
            this.fpgaFileTextBox.Size = new System.Drawing.Size(370, 20);
            this.fpgaFileTextBox.TabIndex = 6;
            // 
            // uploadFpgaButton
            // 
            this.uploadFpgaButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.uploadFpgaButton.Location = new System.Drawing.Point(379, 25);
            this.uploadFpgaButton.Name = "uploadFpgaButton";
            this.uploadFpgaButton.Size = new System.Drawing.Size(73, 23);
            this.uploadFpgaButton.TabIndex = 4;
            this.uploadFpgaButton.Text = "Upload";
            this.uploadFpgaButton.UseVisualStyleBackColor = true;
            this.uploadFpgaButton.Click += new System.EventHandler(this.uploadFpgaButton_Click);
            // 
            // fpgaButtonFlowLayoutPanel
            // 
            this.fpgaButtonFlowLayoutPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.fpgaButtonFlowLayoutPanel.Controls.Add(this.alteraPsRadioButton);
            this.fpgaButtonFlowLayoutPanel.Controls.Add(this.xilinxSsRadioButton);
            this.fpgaButtonFlowLayoutPanel.Controls.Add(this.jtagRadioButton);
            this.fpgaButtonFlowLayoutPanel.Location = new System.Drawing.Point(0, 25);
            this.fpgaButtonFlowLayoutPanel.Name = "fpgaButtonFlowLayoutPanel";
            this.fpgaButtonFlowLayoutPanel.Size = new System.Drawing.Size(348, 23);
            this.fpgaButtonFlowLayoutPanel.TabIndex = 8;
            // 
            // alteraPsRadioButton
            // 
            this.alteraPsRadioButton.AutoSize = true;
            this.alteraPsRadioButton.Checked = true;
            this.alteraPsRadioButton.Location = new System.Drawing.Point(3, 3);
            this.alteraPsRadioButton.Name = "alteraPsRadioButton";
            this.alteraPsRadioButton.Size = new System.Drawing.Size(69, 17);
            this.alteraPsRadioButton.TabIndex = 0;
            this.alteraPsRadioButton.TabStop = true;
            this.alteraPsRadioButton.Text = "Altera PS";
            this.alteraPsRadioButton.UseVisualStyleBackColor = true;
            // 
            // xilinxSsRadioButton
            // 
            this.xilinxSsRadioButton.AutoSize = true;
            this.xilinxSsRadioButton.Location = new System.Drawing.Point(78, 3);
            this.xilinxSsRadioButton.Name = "xilinxSsRadioButton";
            this.xilinxSsRadioButton.Size = new System.Drawing.Size(66, 17);
            this.xilinxSsRadioButton.TabIndex = 1;
            this.xilinxSsRadioButton.Text = "Xilinx SS";
            this.xilinxSsRadioButton.UseVisualStyleBackColor = true;
            // 
            // jtagRadioButton
            // 
            this.jtagRadioButton.AutoSize = true;
            this.jtagRadioButton.Location = new System.Drawing.Point(150, 3);
            this.jtagRadioButton.Name = "jtagRadioButton";
            this.jtagRadioButton.Size = new System.Drawing.Size(52, 17);
            this.jtagRadioButton.TabIndex = 2;
            this.jtagRadioButton.Text = "JTAG";
            this.jtagRadioButton.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.tabControl1);
            this.groupBox6.Location = new System.Drawing.Point(6, 94);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(466, 296);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Command";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(6, 19);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(458, 271);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.flowLayoutPanel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(450, 245);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Registers";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.bitTwiddler11);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(6, 6);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(438, 233);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // dataTabPage
            // 
            this.dataTabPage.Location = new System.Drawing.Point(4, 22);
            this.dataTabPage.Name = "dataTabPage";
            this.dataTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.dataTabPage.Size = new System.Drawing.Size(472, 394);
            this.dataTabPage.TabIndex = 1;
            this.dataTabPage.Text = "Data";
            this.dataTabPage.UseVisualStyleBackColor = true;
            // 
            // ioPortsTabPage
            // 
            this.ioPortsTabPage.Controls.Add(this.groupBox5);
            this.ioPortsTabPage.Controls.Add(this.groupBox4);
            this.ioPortsTabPage.Controls.Add(this.groupBox3);
            this.ioPortsTabPage.Controls.Add(this.groupBox2);
            this.ioPortsTabPage.Controls.Add(this.groupBox1);
            this.ioPortsTabPage.Location = new System.Drawing.Point(4, 22);
            this.ioPortsTabPage.Name = "ioPortsTabPage";
            this.ioPortsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.ioPortsTabPage.Size = new System.Drawing.Size(472, 394);
            this.ioPortsTabPage.TabIndex = 2;
            this.ioPortsTabPage.Text = "I/O Ports";
            this.ioPortsTabPage.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.portEVal);
            this.groupBox5.Controls.Add(this.portEDir);
            this.groupBox5.Location = new System.Drawing.Point(6, 214);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(452, 46);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Port E";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.portDVal);
            this.groupBox4.Controls.Add(this.portDDir);
            this.groupBox4.Location = new System.Drawing.Point(6, 162);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(452, 46);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Port D";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.portCVal);
            this.groupBox3.Controls.Add(this.portCDir);
            this.groupBox3.Location = new System.Drawing.Point(6, 110);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(452, 46);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Port C";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.portBVal);
            this.groupBox2.Controls.Add(this.portBDir);
            this.groupBox2.Location = new System.Drawing.Point(6, 58);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(452, 46);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Port B";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.portAVal);
            this.groupBox1.Controls.Add(this.portADir);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(452, 46);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Port A";
            // 
            // rs232tabPage
            // 
            this.rs232tabPage.Location = new System.Drawing.Point(4, 22);
            this.rs232tabPage.Name = "rs232tabPage";
            this.rs232tabPage.Padding = new System.Windows.Forms.Padding(3);
            this.rs232tabPage.Size = new System.Drawing.Size(472, 394);
            this.rs232tabPage.TabIndex = 3;
            this.rs232tabPage.Text = "RS-232";
            this.rs232tabPage.UseVisualStyleBackColor = true;
            // 
            // spiTabPage
            // 
            this.spiTabPage.Location = new System.Drawing.Point(4, 22);
            this.spiTabPage.Name = "spiTabPage";
            this.spiTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.spiTabPage.Size = new System.Drawing.Size(472, 394);
            this.spiTabPage.TabIndex = 4;
            this.spiTabPage.Text = "SPI";
            this.spiTabPage.UseVisualStyleBackColor = true;
            // 
            // i2cTabPage
            // 
            this.i2cTabPage.Location = new System.Drawing.Point(4, 22);
            this.i2cTabPage.Name = "i2cTabPage";
            this.i2cTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.i2cTabPage.Size = new System.Drawing.Size(472, 394);
            this.i2cTabPage.TabIndex = 5;
            this.i2cTabPage.Text = "I2C";
            this.i2cTabPage.UseVisualStyleBackColor = true;
            // 
            // settingsTabPage
            // 
            this.settingsTabPage.Controls.Add(this.bitTwiddler12);
            this.settingsTabPage.Controls.Add(this.bitTwiddler40);
            this.settingsTabPage.Controls.Add(this.bitTwiddler39);
            this.settingsTabPage.Controls.Add(this.bitTwiddler38);
            this.settingsTabPage.Controls.Add(this.bitTwiddler37);
            this.settingsTabPage.Controls.Add(this.bitTwiddler36);
            this.settingsTabPage.Controls.Add(this.bitTwiddler35);
            this.settingsTabPage.Controls.Add(this.bitTwiddler34);
            this.settingsTabPage.Controls.Add(this.bitTwiddler33);
            this.settingsTabPage.Controls.Add(this.bitTwiddler32);
            this.settingsTabPage.Controls.Add(this.bitTwiddler31);
            this.settingsTabPage.Controls.Add(this.bitTwiddler30);
            this.settingsTabPage.Controls.Add(this.bitTwiddler18);
            this.settingsTabPage.Controls.Add(this.bitTwiddler15);
            this.settingsTabPage.Controls.Add(this.bitTwiddler14);
            this.settingsTabPage.Controls.Add(this.settingbitTwiddler);
            this.settingsTabPage.Location = new System.Drawing.Point(4, 22);
            this.settingsTabPage.Name = "settingsTabPage";
            this.settingsTabPage.Size = new System.Drawing.Size(472, 394);
            this.settingsTabPage.TabIndex = 6;
            this.settingsTabPage.Text = "Settings";
            this.settingsTabPage.UseVisualStyleBackColor = true;
            // 
            // defaultsTabPage
            // 
            this.defaultsTabPage.Location = new System.Drawing.Point(4, 22);
            this.defaultsTabPage.Name = "defaultsTabPage";
            this.defaultsTabPage.Size = new System.Drawing.Size(472, 394);
            this.defaultsTabPage.TabIndex = 7;
            this.defaultsTabPage.Text = "Defaults";
            this.defaultsTabPage.UseVisualStyleBackColor = true;
            // 
            // storageTabPage
            // 
            this.storageTabPage.Location = new System.Drawing.Point(4, 22);
            this.storageTabPage.Name = "storageTabPage";
            this.storageTabPage.Size = new System.Drawing.Size(472, 394);
            this.storageTabPage.TabIndex = 8;
            this.storageTabPage.Text = "Storage";
            this.storageTabPage.UseVisualStyleBackColor = true;
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel,
            this.toolStripProgressBar});
            this.statusStrip.Location = new System.Drawing.Point(0, 515);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(480, 22);
            this.statusStrip.TabIndex = 3;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.ForeColor = System.Drawing.SystemColors.WindowText;
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(465, 17);
            this.toolStripStatusLabel.Spring = true;
            this.toolStripStatusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripProgressBar
            // 
            this.toolStripProgressBar.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripProgressBar.MarqueeAnimationSpeed = 0;
            this.toolStripProgressBar.Name = "toolStripProgressBar";
            this.toolStripProgressBar.Size = new System.Drawing.Size(100, 16);
            this.toolStripProgressBar.Visible = false;
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "Altera RBF files|*.rbf|Xilinx BIN files|*.bin|All files|*.*";
            this.openFileDialog.RestoreDirectory = true;
            // 
            // quickUsbWinForms
            // 
            this.quickUsbWinForms.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.quickUsbWinForms.AutoSize = true;
            this.quickUsbWinForms.Location = new System.Drawing.Point(0, 0);
            this.quickUsbWinForms.Name = "quickUsbWinForms";
            this.quickUsbWinForms.Size = new System.Drawing.Size(480, 86);
            this.quickUsbWinForms.TabIndex = 2;
            // 
            // bitTwiddler11
            // 
            this.bitTwiddler11.AutoSize = true;
            this.bitTwiddler11.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler11.Bits = ((byte)(8));
            this.bitTwiddler11.Caption = "bits";
            this.bitTwiddler11.CaptionWidth = 75;
            this.bitTwiddler11.Location = new System.Drawing.Point(0, 0);
            this.bitTwiddler11.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler11.Name = "bitTwiddler11";
            this.bitTwiddler11.Size = new System.Drawing.Size(227, 23);
            this.bitTwiddler11.TabIndex = 0;
            this.bitTwiddler11.TagInt = 0;
            this.bitTwiddler11.Value = ((uint)(0u));
            // 
            // portEVal
            // 
            this.portEVal.AutoSize = true;
            this.portEVal.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.portEVal.Bits = ((byte)(8));
            this.portEVal.Caption = "Value";
            this.portEVal.CaptionWidth = 30;
            this.portEVal.Location = new System.Drawing.Point(245, 14);
            this.portEVal.Margin = new System.Windows.Forms.Padding(1);
            this.portEVal.Name = "portEVal";
            this.portEVal.Size = new System.Drawing.Size(182, 23);
            this.portEVal.TabIndex = 4;
            this.portEVal.Tag = "4";
            this.portEVal.TagInt = 4;
            this.portEVal.Value = ((uint)(0u));
            this.portEVal.ValueChanged += new QuickUsbDiagCs.ValueChangedHandler(this.bitTwiddler_ValueChanged);
            // 
            // portEDir
            // 
            this.portEDir.AutoSize = true;
            this.portEDir.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.portEDir.Bits = ((byte)(8));
            this.portEDir.Caption = "Dir";
            this.portEDir.CaptionWidth = 30;
            this.portEDir.Location = new System.Drawing.Point(16, 14);
            this.portEDir.Margin = new System.Windows.Forms.Padding(1);
            this.portEDir.Name = "portEDir";
            this.portEDir.Size = new System.Drawing.Size(182, 23);
            this.portEDir.TabIndex = 3;
            this.portEDir.Tag = "4";
            this.portEDir.TagInt = 4;
            this.portEDir.Value = ((uint)(0u));
            this.portEDir.ValueChanged += new QuickUsbDiagCs.ValueChangedHandler(this.bitTwiddler_DirChanged);
            // 
            // portDVal
            // 
            this.portDVal.AutoSize = true;
            this.portDVal.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.portDVal.Bits = ((byte)(8));
            this.portDVal.Caption = "Value";
            this.portDVal.CaptionWidth = 30;
            this.portDVal.Location = new System.Drawing.Point(245, 14);
            this.portDVal.Margin = new System.Windows.Forms.Padding(1);
            this.portDVal.Name = "portDVal";
            this.portDVal.Size = new System.Drawing.Size(182, 23);
            this.portDVal.TabIndex = 4;
            this.portDVal.Tag = "3";
            this.portDVal.TagInt = 3;
            this.portDVal.Value = ((uint)(0u));
            this.portDVal.ValueChanged += new QuickUsbDiagCs.ValueChangedHandler(this.bitTwiddler_ValueChanged);
            // 
            // portDDir
            // 
            this.portDDir.AutoSize = true;
            this.portDDir.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.portDDir.Bits = ((byte)(8));
            this.portDDir.Caption = "Dir";
            this.portDDir.CaptionWidth = 30;
            this.portDDir.Location = new System.Drawing.Point(16, 14);
            this.portDDir.Margin = new System.Windows.Forms.Padding(1);
            this.portDDir.Name = "portDDir";
            this.portDDir.Size = new System.Drawing.Size(182, 23);
            this.portDDir.TabIndex = 3;
            this.portDDir.Tag = "3";
            this.portDDir.TagInt = 3;
            this.portDDir.Value = ((uint)(0u));
            this.portDDir.ValueChanged += new QuickUsbDiagCs.ValueChangedHandler(this.bitTwiddler_DirChanged);
            // 
            // portCVal
            // 
            this.portCVal.AutoSize = true;
            this.portCVal.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.portCVal.Bits = ((byte)(8));
            this.portCVal.Caption = "Value";
            this.portCVal.CaptionWidth = 30;
            this.portCVal.Location = new System.Drawing.Point(245, 14);
            this.portCVal.Margin = new System.Windows.Forms.Padding(1);
            this.portCVal.Name = "portCVal";
            this.portCVal.Size = new System.Drawing.Size(182, 23);
            this.portCVal.TabIndex = 4;
            this.portCVal.Tag = "2";
            this.portCVal.TagInt = 2;
            this.portCVal.Value = ((uint)(0u));
            this.portCVal.ValueChanged += new QuickUsbDiagCs.ValueChangedHandler(this.bitTwiddler_ValueChanged);
            // 
            // portCDir
            // 
            this.portCDir.AutoSize = true;
            this.portCDir.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.portCDir.Bits = ((byte)(8));
            this.portCDir.Caption = "Dir";
            this.portCDir.CaptionWidth = 30;
            this.portCDir.Location = new System.Drawing.Point(16, 14);
            this.portCDir.Margin = new System.Windows.Forms.Padding(1);
            this.portCDir.Name = "portCDir";
            this.portCDir.Size = new System.Drawing.Size(182, 23);
            this.portCDir.TabIndex = 3;
            this.portCDir.Tag = "2";
            this.portCDir.TagInt = 2;
            this.portCDir.Value = ((uint)(0u));
            this.portCDir.ValueChanged += new QuickUsbDiagCs.ValueChangedHandler(this.bitTwiddler_DirChanged);
            // 
            // portBVal
            // 
            this.portBVal.AutoSize = true;
            this.portBVal.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.portBVal.Bits = ((byte)(8));
            this.portBVal.Caption = "Value";
            this.portBVal.CaptionWidth = 30;
            this.portBVal.Location = new System.Drawing.Point(245, 14);
            this.portBVal.Margin = new System.Windows.Forms.Padding(1);
            this.portBVal.Name = "portBVal";
            this.portBVal.Size = new System.Drawing.Size(182, 23);
            this.portBVal.TabIndex = 4;
            this.portBVal.Tag = "1";
            this.portBVal.TagInt = 1;
            this.portBVal.Value = ((uint)(0u));
            this.portBVal.ValueChanged += new QuickUsbDiagCs.ValueChangedHandler(this.bitTwiddler_ValueChanged);
            // 
            // portBDir
            // 
            this.portBDir.AutoSize = true;
            this.portBDir.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.portBDir.Bits = ((byte)(8));
            this.portBDir.Caption = "Dir";
            this.portBDir.CaptionWidth = 30;
            this.portBDir.Location = new System.Drawing.Point(16, 14);
            this.portBDir.Margin = new System.Windows.Forms.Padding(1);
            this.portBDir.Name = "portBDir";
            this.portBDir.Size = new System.Drawing.Size(182, 23);
            this.portBDir.TabIndex = 3;
            this.portBDir.Tag = "1";
            this.portBDir.TagInt = 1;
            this.portBDir.Value = ((uint)(0u));
            this.portBDir.ValueChanged += new QuickUsbDiagCs.ValueChangedHandler(this.bitTwiddler_DirChanged);
            // 
            // portAVal
            // 
            this.portAVal.AutoSize = true;
            this.portAVal.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.portAVal.Bits = ((byte)(8));
            this.portAVal.Caption = "Value";
            this.portAVal.CaptionWidth = 30;
            this.portAVal.Location = new System.Drawing.Point(245, 14);
            this.portAVal.Margin = new System.Windows.Forms.Padding(1);
            this.portAVal.Name = "portAVal";
            this.portAVal.Size = new System.Drawing.Size(182, 23);
            this.portAVal.TabIndex = 4;
            this.portAVal.Tag = "portAVal";
            this.portAVal.TagInt = 0;
            this.portAVal.Value = ((uint)(0u));
            this.portAVal.ValueChanged += new QuickUsbDiagCs.ValueChangedHandler(this.bitTwiddler_ValueChanged);
            // 
            // portADir
            // 
            this.portADir.AutoSize = true;
            this.portADir.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.portADir.Bits = ((byte)(8));
            this.portADir.Caption = "Dir";
            this.portADir.CaptionWidth = 30;
            this.portADir.Location = new System.Drawing.Point(16, 14);
            this.portADir.Margin = new System.Windows.Forms.Padding(1);
            this.portADir.Name = "portADir";
            this.portADir.Size = new System.Drawing.Size(182, 23);
            this.portADir.TabIndex = 3;
            this.portADir.Tag = "portADir";
            this.portADir.TagInt = 0;
            this.portADir.Value = ((uint)(0u));
            this.portADir.ValueChanged += new QuickUsbDiagCs.ValueChangedHandler(this.bitTwiddler_DirChanged);
            // 
            // bitTwiddler12
            // 
            this.bitTwiddler12.AutoSize = true;
            this.bitTwiddler12.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler12.Bits = ((byte)(16));
            this.bitTwiddler12.Caption = "FIFOPolar/IFCONFIG";
            this.bitTwiddler12.CaptionWidth = 130;
            this.bitTwiddler12.Location = new System.Drawing.Point(28, 82);
            this.bitTwiddler12.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler12.Name = "bitTwiddler12";
            this.bitTwiddler12.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler12.TabIndex = 30;
            this.bitTwiddler12.TagInt = 2;
            this.bitTwiddler12.Value = ((uint)(0u));
            // 
            // bitTwiddler40
            // 
            this.bitTwiddler40.AutoSize = true;
            this.bitTwiddler40.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler40.Bits = ((byte)(16));
            this.bitTwiddler40.Caption = "PINFLAGSAB/CD";
            this.bitTwiddler40.CaptionWidth = 130;
            this.bitTwiddler40.Location = new System.Drawing.Point(28, 358);
            this.bitTwiddler40.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler40.Name = "bitTwiddler40";
            this.bitTwiddler40.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler40.TabIndex = 29;
            this.bitTwiddler40.TagInt = 15;
            this.bitTwiddler40.Value = ((uint)(0u));
            // 
            // bitTwiddler39
            // 
            this.bitTwiddler39.AutoSize = true;
            this.bitTwiddler39.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler39.Bits = ((byte)(16));
            this.bitTwiddler39.Caption = "PORTACFG/PORTCCFG";
            this.bitTwiddler39.CaptionWidth = 130;
            this.bitTwiddler39.Location = new System.Drawing.Point(28, 335);
            this.bitTwiddler39.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler39.Name = "bitTwiddler39";
            this.bitTwiddler39.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler39.TabIndex = 28;
            this.bitTwiddler39.TagInt = 14;
            this.bitTwiddler39.Value = ((uint)(0u));
            // 
            // bitTwiddler38
            // 
            this.bitTwiddler38.AutoSize = true;
            this.bitTwiddler38.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler38.Bits = ((byte)(16));
            this.bitTwiddler38.Caption = "OEE/IOE";
            this.bitTwiddler38.CaptionWidth = 130;
            this.bitTwiddler38.Location = new System.Drawing.Point(28, 312);
            this.bitTwiddler38.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler38.Name = "bitTwiddler38";
            this.bitTwiddler38.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler38.TabIndex = 27;
            this.bitTwiddler38.TagInt = 13;
            this.bitTwiddler38.Value = ((uint)(0u));
            // 
            // bitTwiddler37
            // 
            this.bitTwiddler37.AutoSize = true;
            this.bitTwiddler37.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler37.Bits = ((byte)(16));
            this.bitTwiddler37.Caption = "OED/IOD";
            this.bitTwiddler37.CaptionWidth = 130;
            this.bitTwiddler37.Location = new System.Drawing.Point(28, 289);
            this.bitTwiddler37.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler37.Name = "bitTwiddler37";
            this.bitTwiddler37.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler37.TabIndex = 26;
            this.bitTwiddler37.TagInt = 12;
            this.bitTwiddler37.Value = ((uint)(0u));
            // 
            // bitTwiddler36
            // 
            this.bitTwiddler36.AutoSize = true;
            this.bitTwiddler36.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler36.Bits = ((byte)(16));
            this.bitTwiddler36.Caption = "OEC/IOC";
            this.bitTwiddler36.CaptionWidth = 130;
            this.bitTwiddler36.Location = new System.Drawing.Point(28, 266);
            this.bitTwiddler36.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler36.Name = "bitTwiddler36";
            this.bitTwiddler36.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler36.TabIndex = 25;
            this.bitTwiddler36.TagInt = 11;
            this.bitTwiddler36.Value = ((uint)(0u));
            // 
            // bitTwiddler35
            // 
            this.bitTwiddler35.AutoSize = true;
            this.bitTwiddler35.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler35.Bits = ((byte)(16));
            this.bitTwiddler35.Caption = "OEB/IOB";
            this.bitTwiddler35.CaptionWidth = 130;
            this.bitTwiddler35.Location = new System.Drawing.Point(28, 243);
            this.bitTwiddler35.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler35.Name = "bitTwiddler35";
            this.bitTwiddler35.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler35.TabIndex = 24;
            this.bitTwiddler35.TagInt = 10;
            this.bitTwiddler35.Value = ((uint)(0u));
            // 
            // bitTwiddler34
            // 
            this.bitTwiddler34.AutoSize = true;
            this.bitTwiddler34.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler34.Bits = ((byte)(16));
            this.bitTwiddler34.Caption = "OEA/IOA";
            this.bitTwiddler34.CaptionWidth = 130;
            this.bitTwiddler34.Location = new System.Drawing.Point(28, 220);
            this.bitTwiddler34.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler34.Name = "bitTwiddler34";
            this.bitTwiddler34.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler34.TabIndex = 23;
            this.bitTwiddler34.TagInt = 9;
            this.bitTwiddler34.Value = ((uint)(0u));
            // 
            // bitTwiddler33
            // 
            this.bitTwiddler33.AutoSize = true;
            this.bitTwiddler33.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler33.Bits = ((byte)(16));
            this.bitTwiddler33.Caption = "I2OPT/I2CTL";
            this.bitTwiddler33.CaptionWidth = 130;
            this.bitTwiddler33.Location = new System.Drawing.Point(28, 197);
            this.bitTwiddler33.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler33.Name = "bitTwiddler33";
            this.bitTwiddler33.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler33.TabIndex = 22;
            this.bitTwiddler33.TagInt = 8;
            this.bitTwiddler33.Value = ((uint)(0u));
            // 
            // bitTwiddler32
            // 
            this.bitTwiddler32.AutoSize = true;
            this.bitTwiddler32.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler32.Bits = ((byte)(16));
            this.bitTwiddler32.Caption = "SlaveFIFO";
            this.bitTwiddler32.CaptionWidth = 130;
            this.bitTwiddler32.Location = new System.Drawing.Point(28, 174);
            this.bitTwiddler32.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler32.Name = "bitTwiddler32";
            this.bitTwiddler32.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler32.TabIndex = 21;
            this.bitTwiddler32.TagInt = 7;
            this.bitTwiddler32.Value = ((uint)(0u));
            // 
            // bitTwiddler31
            // 
            this.bitTwiddler31.AutoSize = true;
            this.bitTwiddler31.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler31.Bits = ((byte)(16));
            this.bitTwiddler31.Caption = "PORTECFG/SPICONFIG";
            this.bitTwiddler31.CaptionWidth = 130;
            this.bitTwiddler31.Location = new System.Drawing.Point(28, 151);
            this.bitTwiddler31.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler31.Name = "bitTwiddler31";
            this.bitTwiddler31.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler31.TabIndex = 20;
            this.bitTwiddler31.TagInt = 6;
            this.bitTwiddler31.Value = ((uint)(0u));
            // 
            // bitTwiddler30
            // 
            this.bitTwiddler30.AutoSize = true;
            this.bitTwiddler30.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler30.Bits = ((byte)(16));
            this.bitTwiddler30.Caption = "BusSpeed/CPUCONFIG";
            this.bitTwiddler30.CaptionWidth = 130;
            this.bitTwiddler30.Location = new System.Drawing.Point(28, 128);
            this.bitTwiddler30.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler30.Name = "bitTwiddler30";
            this.bitTwiddler30.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler30.TabIndex = 19;
            this.bitTwiddler30.TagInt = 5;
            this.bitTwiddler30.Value = ((uint)(0u));
            // 
            // bitTwiddler18
            // 
            this.bitTwiddler18.AutoSize = true;
            this.bitTwiddler18.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler18.Bits = ((byte)(8));
            this.bitTwiddler18.Caption = "FPGATYPE";
            this.bitTwiddler18.CaptionWidth = 250;
            this.bitTwiddler18.Location = new System.Drawing.Point(28, 105);
            this.bitTwiddler18.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler18.Name = "bitTwiddler18";
            this.bitTwiddler18.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler18.TabIndex = 7;
            this.bitTwiddler18.TagInt = 4;
            this.bitTwiddler18.Value = ((uint)(0u));
            // 
            // bitTwiddler15
            // 
            this.bitTwiddler15.AutoSize = true;
            this.bitTwiddler15.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler15.Bits = ((byte)(16));
            this.bitTwiddler15.Caption = "DataAddress";
            this.bitTwiddler15.CaptionWidth = 130;
            this.bitTwiddler15.Location = new System.Drawing.Point(28, 57);
            this.bitTwiddler15.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler15.Name = "bitTwiddler15";
            this.bitTwiddler15.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler15.TabIndex = 4;
            this.bitTwiddler15.TagInt = 2;
            this.bitTwiddler15.Value = ((uint)(0u));
            // 
            // bitTwiddler14
            // 
            this.bitTwiddler14.AutoSize = true;
            this.bitTwiddler14.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bitTwiddler14.Bits = ((byte)(8));
            this.bitTwiddler14.Caption = "WORDWIDE";
            this.bitTwiddler14.CaptionWidth = 250;
            this.bitTwiddler14.Location = new System.Drawing.Point(28, 34);
            this.bitTwiddler14.Margin = new System.Windows.Forms.Padding(0);
            this.bitTwiddler14.Name = "bitTwiddler14";
            this.bitTwiddler14.Size = new System.Drawing.Size(0, 0);
            this.bitTwiddler14.TabIndex = 3;
            this.bitTwiddler14.TagInt = 1;
            this.bitTwiddler14.Value = ((uint)(0u));
            // 
            // settingbitTwiddler
            // 
            this.settingbitTwiddler.AutoSize = true;
            this.settingbitTwiddler.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.settingbitTwiddler.Bits = ((byte)(16));
            this.settingbitTwiddler.Caption = "EP2CFG/EP6CFG";
            this.settingbitTwiddler.CaptionWidth = 130;
            this.settingbitTwiddler.Location = new System.Drawing.Point(28, 11);
            this.settingbitTwiddler.Margin = new System.Windows.Forms.Padding(0);
            this.settingbitTwiddler.Name = "settingbitTwiddler";
            this.settingbitTwiddler.Size = new System.Drawing.Size(0, 0);
            this.settingbitTwiddler.TabIndex = 0;
            this.settingbitTwiddler.TagInt = 0;
            this.settingbitTwiddler.Value = ((uint)(0u));
            // 
            // Display
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(480, 537);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.quickUsbWinForms);
            this.Controls.Add(this.diagTabControl);
            this.MinimizeBox = false;
            this.Name = "Display";
            this.Text = "QuickUSB Diagnostics";
            this.Load += new System.EventHandler(this.Display_Load);
            this.diagTabControl.ResumeLayout(false);
            this.fpgaCommandTabPage.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.fpgaUploadPanel.ResumeLayout(false);
            this.fpgaUploadPanel.PerformLayout();
            this.fpgaButtonFlowLayoutPanel.ResumeLayout(false);
            this.fpgaButtonFlowLayoutPanel.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.ioPortsTabPage.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.settingsTabPage.ResumeLayout(false);
            this.settingsTabPage.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BitwiseSystems.QuickUsbWinForms quickUsbWinForms;
        private System.Windows.Forms.TabControl diagTabControl;
        private System.Windows.Forms.TabPage fpgaCommandTabPage;
        private System.Windows.Forms.TabPage dataTabPage;
        private System.Windows.Forms.TabPage ioPortsTabPage;
        private System.Windows.Forms.TabPage rs232tabPage;
        private System.Windows.Forms.TabPage spiTabPage;
        private System.Windows.Forms.TabPage i2cTabPage;
        private System.Windows.Forms.TabPage settingsTabPage;
        private System.Windows.Forms.TabPage defaultsTabPage;
        private System.Windows.Forms.TabPage storageTabPage;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar;
        private System.Windows.Forms.GroupBox groupBox1;
        private BitTwiddler portAVal;
        private BitTwiddler portADir;
        private System.Windows.Forms.GroupBox groupBox5;
        private BitTwiddler portEVal;
        private BitTwiddler portEDir;
        private System.Windows.Forms.GroupBox groupBox4;
        private BitTwiddler portDVal;
        private BitTwiddler portDDir;
        private System.Windows.Forms.GroupBox groupBox3;
        private BitTwiddler portCVal;
        private BitTwiddler portCDir;
        private System.Windows.Forms.GroupBox groupBox2;
        private BitTwiddler portBVal;
        private BitTwiddler portBDir;
        private BitTwiddler settingbitTwiddler;
        private BitTwiddler bitTwiddler14;
        private BitTwiddler bitTwiddler15;
        private BitTwiddler bitTwiddler18;
        private BitTwiddler bitTwiddler40;
        private BitTwiddler bitTwiddler39;
        private BitTwiddler bitTwiddler38;
        private BitTwiddler bitTwiddler37;
        private BitTwiddler bitTwiddler36;
        private BitTwiddler bitTwiddler35;
        private BitTwiddler bitTwiddler34;
        private BitTwiddler bitTwiddler33;
        private BitTwiddler bitTwiddler32;
        private BitTwiddler bitTwiddler31;
        private BitTwiddler bitTwiddler30;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Panel fpgaUploadPanel;
        private System.Windows.Forms.Button isFpgaConfiguredButton;
        private System.Windows.Forms.Button browseFpgaFileButton;
        private System.Windows.Forms.TextBox fpgaFileTextBox;
        private System.Windows.Forms.Button uploadFpgaButton;
        private System.Windows.Forms.FlowLayoutPanel fpgaButtonFlowLayoutPanel;
        private System.Windows.Forms.RadioButton alteraPsRadioButton;
        private System.Windows.Forms.RadioButton xilinxSsRadioButton;
        private System.Windows.Forms.RadioButton jtagRadioButton;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private BitTwiddler bitTwiddler11;
        private BitTwiddler bitTwiddler12;
    }
}

