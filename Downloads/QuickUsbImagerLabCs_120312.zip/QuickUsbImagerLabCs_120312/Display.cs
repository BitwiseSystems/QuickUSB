using System;
using System.IO;
using System.Text;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;
using BitwiseSystems;
using Microsoft.Win32;

namespace QuickUsbDiagCs
{
    public partial class Display : Form
    {
        public Display()
        {
            InitializeComponent();
        }

        private void Display_Load(object sender, EventArgs e)
        {
            fpgaFileTextBox.Text = Registry.CurrentUser.GetValue("fpgaFileName", "").ToString();
            UpdatePortDisplay();
        }

        private void browseFpgaFileButton_Click(object sender, EventArgs e)
        {
            string filename;
            DialogResult result;

            // Read the old filename from the registry
            filename = Registry.CurrentUser.GetValue("fpgaFileName", "").ToString();

            // Set the directory
            openFileDialog.InitialDirectory = filename;

            // Display the FileOpen dialog
            result = openFileDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                // Extract the selected filename and save it to the registry
                fpgaFileTextBox.Text = openFileDialog.FileName;
                Registry.CurrentUser.SetValue("fpgaFileName", fpgaFileTextBox.Text, RegistryValueKind.String);

                // Upload the file
                this.uploadFpgaButton_Click(sender, e);
            }
        }

        private void uploadFpgaButton_Click(object sender, EventArgs e)
        {            
            BitwiseSystems.QuickUsb qusb = (BitwiseSystems.QuickUsb) quickUsbWinForms.module;

            // See which Radiobutton is checked and set the configuration type
            if (alteraPsRadioButton.Checked)
            {
                qusb.WriteSetting((ushort) QuickUsb.Settings.SETTING_FPGATYPE, (ushort) QuickUsb.FpgaTypes.FPGATYPE_ALTERAPS);
            }
            if (xilinxSsRadioButton.Checked)
            {
                qusb.WriteSetting((ushort)QuickUsb.Settings.SETTING_FPGATYPE, (ushort)QuickUsb.FpgaTypes.FPGATYPE_XILINXSS);
            }
            if (jtagRadioButton.Checked)
            {
                qusb.WriteSetting((ushort)QuickUsb.Settings.SETTING_FPGATYPE, (ushort)QuickUsb.FpgaTypes.FPGATYPE_JTAG);
            }

            // Check to see if we can reset the FPGA
            // If not, the FPGA probably isn't on or connected up right
            if (!qusb.StartFpgaConfiguration())
            {
                ShowStatusMessage("Cannot Configure FPGA.  Is the power on?");
                return;
            }

            // Configure the FPGA
            ShowStatusMessage("Configuring FPGA...");
            qusb.UploadFpga(fpgaFileTextBox.Text, UpdateFpgaProgressBar);

            // Check to see if it configured
            isFpgaConfiguredButton_Click(sender, e);

            toolStripProgressBar.Visible = false;
        }

        private void isFpgaConfiguredButton_Click(object sender, EventArgs e)
        {
            ushort isConfigured = 0;

            BitwiseSystems.QuickUsb qusb = (BitwiseSystems.QuickUsb)quickUsbWinForms.module;

            qusb.IsFpgaConfigured(ref isConfigured);
            switch (isConfigured)
            {
                case 0:
                    toolStripStatusLabel.Text = "FPGA is not configured";
                    statusStrip.Refresh();
                    break;
                default:
                    toolStripStatusLabel.Text = "FPGA is configured";
                    statusStrip.Refresh();
                    break;
            }
        }

        private void UpdatePortDisplay()
        {
            byte dir = 0;
            byte[] value = new byte[1];
            ushort numread = 1;
            
            BitwiseSystems.QuickUsb qusb = (BitwiseSystems.QuickUsb)quickUsbWinForms.module;
            qusb.ReadPortDir(0, ref dir);
            portADir.Value = dir;
            numread = 1;
            qusb.ReadPort(0, ref value, ref numread);
            portAVal.Value = value[0];
            qusb.ReadPortDir(1, ref dir);
            portBDir.Value = dir;
            numread = 1;
            qusb.ReadPort(1, ref value, ref numread);
            portBVal.Value = value[0];
            qusb.ReadPortDir(2, ref dir);
            portCDir.Value = dir;
            numread = 1;
            qusb.ReadPort(2, ref value, ref numread);
            portCVal.Value = value[0];
            qusb.ReadPortDir(3, ref dir);
            portDDir.Value = dir;
            numread = 1;
            qusb.ReadPort(3, ref value, ref numread);
            portDVal.Value = value[0];
            qusb.ReadPortDir(4, ref dir);
            portEDir.Value = dir;
            numread = 1;
            qusb.ReadPort(4, ref value, ref numread);
            portEVal.Value = value[0];
        }

        private void bitTwiddler_DirChanged(object sender, uint value)
        {
            BitwiseSystems.QuickUsb qusb = (BitwiseSystems.QuickUsb)quickUsbWinForms.module;
            qusb.WritePortDir((ushort)((BitTwiddler)sender).TagInt, (byte)value);
        }

        private void bitTwiddler_ValueChanged(object sender, uint value)
        {
            BitwiseSystems.QuickUsb qusb = (BitwiseSystems.QuickUsb)quickUsbWinForms.module;
            byte[] values = new byte[1];
            values[0] = (byte) value;
            qusb.WritePort((ushort)((BitTwiddler)sender).TagInt, values, 1);
        }

        private void ShowStatusMessage(string message)
        {
            toolStripStatusLabel.Text = message;
            statusStrip.Refresh();
        }

        private void UpdateFpgaProgressBar(int value)
        {
            toolStripProgressBar.Visible = true;
            toolStripProgressBar.Value = value;
            statusStrip.Refresh();
        }
    }
}