﻿using System;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;


namespace BitwiseSystems
{
	public delegate void ValueChangedHandler(object sender, uint value);
	
	public partial class BitTwiddler : UserControl
	{
		const int space = 4;
		const int pad = 2;
		byte m_bits = 8;
		int m_captionWidth = 75;
		int m_valueWidth = 25;
		int m_tagint = 0;
		uint m_value = 0;
		string m_caption = "bits";
		Label label;
		CheckBox[] checkBoxes;
		TextBox textEdit;

        public String [] ToolTips { get; set; }

		public event ValueChangedHandler ValueChanged;

		public BitTwiddler()
		{
			InitializeComponent();
		}

		protected override void OnCreateControl()
		{
			// Make the control autosize to the size of the components
			AutoSize = true;
			AutoSizeMode = AutoSizeMode.GrowAndShrink;
			
			label = new Label();
			label.Name = "caption";
			label.Text = m_caption;
			label.Location = new Point(3, 4);
			label.Size = new Size(m_captionWidth+space, 14);
			label.Margin = new Padding(pad);
			Controls.Add(label);

			checkBoxes = new CheckBox[m_bits];
			for (int i = 0; i < m_bits; i++) {
				checkBoxes[i] = new CheckBox();
				checkBoxes[i].Name = "checkBox" + i;
				checkBoxes[i].Text = "checkBox" + i;
				checkBoxes[i].TabIndex = i;
				checkBoxes[i].Size = new Size(15, 14);
				checkBoxes[i].Location = new Point(3 + space + m_captionWidth + (((m_bits - 1) - i) * 15), 4);
				checkBoxes[i].Margin = new Padding(pad);
				checkBoxes[i].Click += new EventHandler(BitTwiddler_Click);
				checkBoxes[i].MouseHover += new EventHandler(BitTwiddler_MouseHover);
			}
			Controls.AddRange(checkBoxes);

			textEdit = new TextBox();
			textEdit.Name = "textEdit";
			textEdit.Location = new Point(3 + space + m_captionWidth + (m_bits * 15) + space, 1);
			textEdit.Size = new Size(m_valueWidth, 14);
			textEdit.Margin = new Padding(pad);
			textEdit.TextAlign = HorizontalAlignment.Right;

			UpdateCheckBoxes();
			UpdateTextEdit();
			Controls.Add(textEdit);

 			base.OnCreateControl();
		}

		private void BitTwiddler_Load(object sender, EventArgs e)
		{
			UpdateCheckBoxes();
			UpdateTextEdit();
		}
	   
		protected virtual void OnValueChanged(uint value)
		{
			ValueChangedHandler handler = ValueChanged;
			if (handler != null) {
				handler(this, value);
			}
		}

		private void UpdateCheckBoxes()
		{
            if (checkBoxes == null)
            {
                return;
            }

			for (int i = 0; i < m_bits; i++) {
				checkBoxes[i].Checked = (m_value & (1 << i)) != 0 ? true : false;
			}
		}

		private void UpdateTextEdit()
		{
            if (textEdit == null)
            {
                return;
            }
			textEdit.Text = String.Format("{0:X" + m_bits / 4 + "}", m_value);
			Point pt = new Point(TextRenderer.MeasureText(textEdit.Text, textEdit.Font));
			textEdit.Size = new Size(pt);
		}

		void BitTwiddler_Click(object sender, EventArgs e)
		{
			CheckBox cb = (CheckBox) sender;
			
			if (cb.Checked == true) {
				m_value |= (uint)(1 <<  cb.TabIndex);
			}
			else {
				m_value &= ~(uint)(1 << cb.TabIndex);
			}
			UpdateTextEdit();
			OnValueChanged(m_value);
		}

		public string Caption
		{
			get {
				return m_caption;
			}
			set {
				m_caption = value;
				if (label != null)
				{
					label.Text = m_caption;
				}
			}
		}

		public int CaptionWidth
		{
			get {
				return m_captionWidth;
			}
			set {
				m_captionWidth = value;
				if (label != null)
				{
					label.Size = new Size(m_captionWidth + space, 14);
				}
				if (checkBoxes != null)
				{
					for (int i = 0; i < m_bits; i++)
					{
						checkBoxes[i].Location = new Point(3 + space + m_captionWidth + (((m_bits - 1) - i) * 15), 4);
					}
				}
				if (textEdit != null)
				{
					textEdit.Location = new Point(3 + space + m_captionWidth + (m_bits * 15) + space, 1);
				}
			}
		}

		public byte Bits
		{
			get {
				return m_bits;
			}
			set {
				m_bits = value;
			}
		}

		public uint Value
		{
			get {
				return m_value;
			}
			set {
				m_value = value;
				try {
					UpdateCheckBoxes();
					UpdateTextEdit();
				}
				catch { }
			}
		}

		public string TextValue
		{
			get
			{
				return textEdit.Text;
			}
		}

        public int TagInt
		{
			get
			{
				return m_tagint;
			}
			set
			{
				m_tagint = value;
			}
		}

		private void BitTwiddler_MouseHover(object sender, EventArgs e)
		{
			CheckBox cb = (CheckBox) sender;
            if (cb == null || ToolTips == null || bitTwiddlerToolTip == null)
            {
                return;
            }

            bitTwiddlerToolTip.Show(ToolTips[cb.TabIndex], cb);
		}
	}
}
