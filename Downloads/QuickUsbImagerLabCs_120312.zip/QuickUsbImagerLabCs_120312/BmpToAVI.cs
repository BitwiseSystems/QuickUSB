// BitmapToAVI.cs originally written by Harry Fairhead
// Hosted on: http://www.i-programmer.info/projects/38-windows/220-bitmaps-into-videos.html
// Edited by Bitwise Systems

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Drawing.Imaging;

namespace BmpToAVI
{

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct AVI_RECT
	{
		public Int32 left;
		public Int32 top;
		public Int32 right;
		public Int32 bottom;
	};
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct AVISTREAMINFO
	{

		public Int32 fccType;
		public Int32 fccHandler;
		public Int32 dwFlags;
		public Int32 dwCaps;
		public Int16 wPriority;
		public Int16 wLanguage;
		public Int32 dwScale;
		public Int32 dwRate;
		public Int32 dwStart;
		public Int32 dwLength;
		public Int32 dwInitialFrames;
		public Int32 dwSuggestedBufferSize;
		public Int32 dwQuality;
		public Int32 dwSampleSize;
		public AVI_RECT rcFrame;
		public Int32 dwEditCount;
		public Int32 dwFormatChangeCount;
		[MarshalAs(UnmanagedType.ByValArray, SizeConst=64)]
		public char[] szName;

	};

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct AVICOMPRESSOPTIONS
	{
		public Int32 fccType;
		public Int32 fccHandler;
		public Int32 dwKeyFrameEvery;
		public Int32 dwQuality;
		public Int32 dwBytesPerSecond;
		public Int32 dwFlags;
		public Int32 lpFormat;
		public Int32 cbFormat;
		public Int32 lpParms;
		public Int32 cbParms;
		public Int32 dwInterleaveEvery;
	} ;

	class BmpToAVI
	{
		private IntPtr m_hWnd;
		private IntPtr pFile = IntPtr.Zero;
		private IntPtr pStream = IntPtr.Zero;
		private IntPtr psComp = IntPtr.Zero;

		private int FrameCount = 0;

		private const int OF_WRITE = 0x00000001;
		private const int OF_CREATE = 0x00001000;


		private const int ICMF_CHOOSE_KEYFRAME = 0x00000001;
		private const int ICMF_CHOOSE_DATARATE = 0x00000002;

		private const int AVIIF_KEYFRAME = 0x00000010;

		[DllImport("avifil32.dll")]
		extern static void AVIFileInit();

		[DllImport("avifil32.dll")]
		extern static void AVIFileExit();

		[DllImport("avifil32.dll")]
		extern static int AVIFileOpen(
			ref IntPtr pfile,
			string File,
			int Mode,
			int clsidHandler);

		[DllImport("winmm.dll", EntryPoint = "mmioStringToFOURCCA")]
		extern static int mmioStringToFOURCC(
			string sz,
			int Flags);

		[DllImport("avifil32.dll")]
		extern static int AVIFileCreateStream(
			IntPtr pfile,
			ref IntPtr pavi,
			ref AVISTREAMINFO lParam);


		[DllImport("avifil32.dll")]
		extern static int AVISaveOptions(
			IntPtr hWnd,
			int uiFlags,
			int noStreams,
			IntPtr ppavi,
			ref IntPtr ppOptions);


		[DllImport("avifil32.dll")]
		extern static int AVIMakeCompressedStream(
			ref IntPtr ppsComp,
			IntPtr ppavi,
			ref AVICOMPRESSOPTIONS opts,
			int pclisidHandler);

		[DllImport("avifil32.dll")]
		extern static int AVIStreamSetFormat(
			IntPtr ppavi,
			int lpos,
			IntPtr lpFormat,
			int cbFormat);

		[DllImport("avifil32.dll")]
		extern static int AVIStreamWrite(
			IntPtr ppavi,
			int lStart,
			int lSamples,
			IntPtr buffer,
			int cbBuffer,
			int dwFlags,
			int sampwritten,
			int bytes);


		[DllImport("avifil32.dll")]
		extern static int AVIStreamRelease(IntPtr ppavi);

		[DllImport("avifil32.dll")]
		extern static int AVIFileRelease(IntPtr pfile);

		public BmpToAVI(IntPtr hwnd)
		{
			m_hWnd = hwnd;
			AVIFileInit();
		}

		public void FirstFrame(string AVIfile, string BMPfile)
		{

			int result = AVIFileOpen(ref pFile,
				AVIfile,
				OF_WRITE | OF_CREATE,
				0);
			RawBitmap bm = new RawBitmap();
			bm.LoadFromFile(BMPfile);

			AVISTREAMINFO Sinfo = new AVISTREAMINFO();
			Sinfo.fccType = mmioStringToFOURCC("vids", 0);
			Sinfo.fccHandler = 0;
			Sinfo.dwScale = 1;
			Sinfo.dwRate = 10;
			Sinfo.dwSuggestedBufferSize = bm.bmIH.biSizeImage;
			Sinfo.rcFrame.top = 0;
			Sinfo.rcFrame.left = 0;
			Sinfo.rcFrame.right = bm.bmIH.biWidth;
			Sinfo.rcFrame.bottom = bm.bmIH.biHeight;


			result = AVIFileCreateStream(
	pFile,
	ref pStream,
	ref Sinfo);

			IntPtr buf = Marshal.AllocHGlobal(
			Marshal.SizeOf(typeof(AVICOMPRESSOPTIONS)));

			GCHandle handle1 = GCHandle.Alloc(
		pStream,
		GCHandleType.Pinned);




			result = AVISaveOptions(
		m_hWnd,
		ICMF_CHOOSE_KEYFRAME | ICMF_CHOOSE_DATARATE,
		1,
		handle1.AddrOfPinnedObject(),
		ref buf);

			AVICOMPRESSOPTIONS opts = (AVICOMPRESSOPTIONS)
	  Marshal.PtrToStructure(buf,
	  typeof(AVICOMPRESSOPTIONS));
			Marshal.FreeHGlobal(buf);
			handle1.Free();





			result = AVIMakeCompressedStream(ref psComp, pStream, ref opts, 0);


			GCHandle handle = GCHandle.Alloc(bm.bmIH, GCHandleType.Pinned);
			result = AVIStreamSetFormat(psComp, 0, handle.AddrOfPinnedObject(), bm.bmIH.biSize);
			handle.Free();


			handle = GCHandle.Alloc(bm.bits, GCHandleType.Pinned);
			result = AVIStreamWrite(psComp,
				1,
				1,
				handle.AddrOfPinnedObject(),
				bm.bits.GetLength(0),
				AVIIF_KEYFRAME, 0, 0);
			FrameCount = 1;
			handle.Free();
		}

		// Method added by Bitwise Systems
		public int Init(string AVIfile, int width, int height, int frameRate)
		{
			int result = AVIFileOpen(ref pFile, AVIfile, OF_WRITE | OF_CREATE, 0);
			if (result != 0)
			{
				closeAll();
				return result;
			}

			AVISTREAMINFO Sinfo = new AVISTREAMINFO();
			Sinfo.fccType = mmioStringToFOURCC("vids", 0);
			Sinfo.fccHandler = 0;
			Sinfo.dwQuality = -1;
			Sinfo.dwScale = 1;
			Sinfo.dwRate = frameRate;
			Sinfo.dwStart = 1;
			Sinfo.dwLength = width * height;
			Sinfo.dwSuggestedBufferSize = width * height * 30;
			Sinfo.rcFrame.top = 0;
			Sinfo.rcFrame.left = 0;
			Sinfo.rcFrame.right = width;
			Sinfo.rcFrame.bottom = height;

			result = AVIFileCreateStream(pFile, ref pStream, ref Sinfo);
			if (result != 0)
			{
				closeAll();
				return result;
			}

			/*IntPtr buf = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(AVICOMPRESSOPTIONS)));

			GCHandle handle1 = GCHandle.Alloc(pStream, GCHandleType.Pinned);

			result = AVISaveOptions(m_hWnd, ICMF_CHOOSE_KEYFRAME | ICMF_CHOOSE_DATARATE, 1, handle1.AddrOfPinnedObject(), ref buf);
			if (result != 1)
			{
				closeAll();
				return -1;
			}
			
			AVICOMPRESSOPTIONS opts = (AVICOMPRESSOPTIONS)Marshal.PtrToStructure(buf, typeof(AVICOMPRESSOPTIONS));
			Marshal.FreeHGlobal(buf);
			handle1.Free();

			result = AVIMakeCompressedStream(ref psComp, pStream, ref opts, 0);
			if (result != 0)
			{
				closeAll();
				return result;
			}*/

			FrameCount = 0;

			BITMAPINFO bmi = new BITMAPINFO();
			bmi.bmIH.biBitCount = 8;
			bmi.bmIH.biClrImportant = 0;
			bmi.bmIH.biClrUsed = 256;
			bmi.bmIH.biCompression = 0;
			bmi.bmIH.biHeight = -height;
			bmi.bmIH.biPlanes = 1;
			bmi.bmIH.biSize = Marshal.SizeOf(typeof(BITMAPINFOHEADER));
			bmi.bmIH.biSizeImage = height * width;
			bmi.bmIH.biWidth = width;
			bmi.bmIH.biXPelsPerMeter = 11811;
			bmi.bmIH.biYPelsPerMeter = 11811;
			bmi.bmColors = new BITMAP_RGBQUAD[256];
			for (int k = 0; k < 256; ++k)
			{
				bmi.bmColors[k].red = (byte)k;
				bmi.bmColors[k].green = (byte)k;
				bmi.bmColors[k].blue = (byte)k;
			}

			int size = Marshal.SizeOf(bmi);
			IntPtr ptr = Marshal.AllocHGlobal(size);
			Marshal.StructureToPtr(bmi, ptr, true);
			result = AVIStreamSetFormat(pStream, 0, ptr, size);
			Marshal.FreeHGlobal(ptr);

			if (result != 0)
			{
				closeAll();
				return result;
			}

			return 0;
		}

		// Method added by Bitwise Systems
		public int RecordFrame(BitmapData bm)
		{
			return AVIStreamWrite(pStream, ++FrameCount, 1, bm.Scan0, bm.Height * bm.Width, AVIIF_KEYFRAME, 0, 0);
		}

		public void NextFrame(string BMPFile)
		{
			RawBitmap bm = new RawBitmap();
			bm.LoadFromFile(BMPFile);
			GCHandle handle = GCHandle.Alloc(bm.bits, GCHandleType.Pinned);
			int result = AVIStreamWrite(psComp,
				++FrameCount,
				1,
				handle.AddrOfPinnedObject(),
				bm.bits.GetLength(0),
				AVIIF_KEYFRAME, 0, 0);
		}

		// Method edited by Bitwise Systems
		public void closeAll()
		{
			int result;
			if (psComp != IntPtr.Zero)
			{
				result = AVIStreamRelease(psComp);
				psComp = IntPtr.Zero;
			}
			if (pStream != IntPtr.Zero)
			{
				result = AVIStreamRelease(pStream);
				pStream = IntPtr.Zero;
			}
			if (pFile != IntPtr.Zero)
			{
				result = AVIFileRelease(pFile);
				pFile = IntPtr.Zero;
			}
		}

		// Method edited by Bitwise Systems
		~BmpToAVI()
		{
			closeAll();
			AVIFileExit();
		}
	}
}
