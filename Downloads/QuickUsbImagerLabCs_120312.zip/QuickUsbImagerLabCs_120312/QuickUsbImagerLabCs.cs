﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using BitwiseSystems;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices;
using System.Diagnostics;



namespace BitwiseSystems
{
	public partial class QuickUsbImagerLabCs : Form
    {
        #region DLL Imports

        [DllImport("Kernel32.dll", EntryPoint = "RtlMoveMemory", SetLastError = false)]
        static extern void MoveMemory(IntPtr dest, IntPtr src, int size);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool QueryPerformanceCounter(out long lpPerformanceCount);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool QueryPerformanceFrequency(out long frequency);

        #endregion


        #region Instance Variables

        public enum SensorClockSpeed
		{
			Clock12MHz = 0,
			Clock24MHz = 1,
			Clock48MHz = 3,
		}

		const byte ILAB_RESET = 0x08;
        const double MB = 1024.0f * 1024.0f;

		// Instance variables
        movingAverage maFPS = new movingAverage(16);
        movingAverage maDR = new movingAverage(16);
        double FPS, DataRate;
		SensorClockSpeed sensorClockSpeed;
		byte sensorAddress;
		byte sensorDepthBytes = 1;
		byte sensorRegWidth = 8;
		bool sensorUseCachedWrite = false;
		bool sensorResetActiveHigh;

		string sensorFile;
		BmpToAVI.BmpToAVI aviRecorder;
		bool recordVideo = false;

		long bytecount = 0;
        const int NumBuffers = 8;
        int m_rows = 480;
        int m_cols = 640;
        int m_framesize = 640 * 480;

        Bitmap image;
        QuickUsb qusb;
        string[] nameList;
        bool qResult;
        bool aquiring = false;
        int nextBuffer = 0;
        QuickUsb.Error qusbError;
        bool shutdown;
        IntPtr backBuffer;
        byte streamID;

        long tStart, tEnd, freq;
        double tElapsed;

        QuickUsb.BulkStreamCompletionRoutine cbDelegate;

		#endregion


		#region Public Methods


		// Contructor
		public QuickUsbImagerLabCs()
		{
			InitializeComponent();

            cbDelegate = new QuickUsb.BulkStreamCompletionRoutine(CompletionRoutine);
            
            quickUsbWinForms.ScanEnabled = true;
			quickUsbWinForms.ScanOnLoad = true;
            SetImageSize(m_rows, m_cols);
		}


        void CompletionRoutine(QuickUsb.BulkStream BulkStream)
        {
            if (BulkStream == null)
            {
                return;
            }

            if (BulkStream.Error != 0)
            {
                Debug.WriteLine(String.Format("Error: {0}, Lost bytes: {1}", BulkStream.Error, BulkStream.BytesRequested - BulkStream.BytesTransferred));
                return;
            }

            // Blit data to screen
            lock (image)
            {
                MoveMemory(backBuffer, BulkStream.Buffer, m_framesize);

                // Calculate FPS and data rates
                QueryPerformanceCounter(out tEnd);
                tElapsed = (double)(tEnd - tStart) / (double)(freq);
                tStart = tEnd;
                bytecount += m_framesize;
                double dataread = ((float)bytecount) / MB;
                FPS = 1.0f / (double)tElapsed;
                DataRate = (m_framesize / MB) / (double)tElapsed;

                maFPS.addSample(FPS);
                maDR.addSample(DataRate);
            }
        }

        void StartAcquisition()
        {
            if (aquiring)
            {
                return;
            }

            // Disable module scan
            quickUsbWinForms.ScanEnabled = false;

            // Query connected modules
            nameList = QuickUsb.FindModules();
            if (nameList.Length == 0)
            {
                return;
            }

            // Open the first module
            if (qusb == null)
            {
                qusb = new QuickUsb(nameList[0]);
            }
            qusb.Open(nameList[0]);

            maFPS.reset();
            maDR.reset();
            shutdown = false;
            nextBuffer = 0;
            aquiring = true;

            backBuffer = Marshal.AllocHGlobal(m_framesize);

            // Start timing
            QueryPerformanceFrequency(out freq);
            QueryPerformanceCounter(out tStart);

            qResult = qusb.ReadBulkDataStartStream(IntPtr.Zero, 8, (uint)m_framesize, cbDelegate, IntPtr.Zero, out streamID, 1, 1);
            if (!qResult)
            {
                ShowStatusMessage(String.Format("ReadBulkDataStartStream() failed with error: {0}", (QuickUsb.Error)qusb.LastError()));
            }
        }

        void StopAcquisition()
        {
            if (!aquiring || qusb == null || shutdown)
            {
                return;
            }

            // Stop the timer
            aquiring = false;
            shutdown = true;

            // Close the module
            qResult = qusb.StopStream(streamID, false);
            if (!qResult)
            {
                ShowStatusMessage(String.Format("BulkDataStopStream() failed with error: {0}", (QuickUsb.Error)qusb.LastError()));
            }
            qResult = qusb.Close();
            if (!qResult)
            {
                ShowStatusMessage(String.Format("Close() failed with error: {0}", (QuickUsb.Error)qusb.LastError()));
            }

            Marshal.FreeHGlobal(backBuffer);
            backBuffer = IntPtr.Zero;

            quickUsbWinForms.ScanEnabled = true;
            cbVideoAcquire.Checked = false;
        }

        public void AcquireSingle()
        {
            qusb = quickUsbWinForms.SelectedModule;
            if (qusb == null || aquiring)
            {
                return;
            }

            uint bytes;
            byte[] data = new byte[m_framesize];
            QuickUsb.Error qusbError;

            //  Grab the new frame
            bytes = (uint)m_framesize;

            if (!qusb.ReadData(data, ref bytes))
            {
                qusbError = QuickUsb.GetLastError();
                //return;
            }

            if (sensorDepthBytes == 1)
            {
                // Display the frame
                BitmapData bData = image.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.WriteOnly, PixelFormat.Format16bppRgb555);
                Marshal.Copy(data, 0, bData.Scan0, m_framesize);
                image.UnlockBits(bData);
            }
            else
            {
                // Convert data
                /*byte[] newData = new byte[bytes * 3];
                for (int k=0; k<bytes; ++k)
                {
                    newData[k*3+0] = data[k];
                    newData[k*3+1] = data[k];
                    newData[k*3+2] = data[k];
                }*/

                // Display the frame
                BitmapData bData = image.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.WriteOnly, PixelFormat.Format16bppRgb565);
                Marshal.Copy(data, 0, bData.Scan0, (int)bytes);
                image.UnlockBits(bData);
            }

            //BitmapData bData = image.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.WriteOnly, PixelFormat.Format8bppIndexed);
            
            // Update the PictureBox with the new image data
            pbFrame.Invalidate();
        }



		public void ShowStatusMessage(string message)
		{
			toolStripStatusLabel.Text = message;
		}



        public void SetImageSize(int rows, int cols)
        {
            m_rows = rows;
            m_cols = cols;
            m_framesize = rows * cols * sensorDepthBytes;

            pbFrame.Size = new Size(cols, rows);
            image = new Bitmap(cols, rows, System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
            ColorPalette palette = image.Palette;
            for (int k = 0; k < palette.Entries.Length; ++k)
            {
                palette.Entries[k] = Color.FromArgb(255, k, k, k);
            }
            image.Palette = palette;

            // Set the initial image (black)
            pbFrame.Image = image;

        }


		public void EnableSensor(bool enable, bool resetActiveHigh)
		{
			QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return;
			}

			ushort length;
			byte[] buffer = new byte[1];
			QuickUsb.Error qusbError;

			length = 1;
			if (!qusb.ReadPort((ushort)QuickUsb.Port.PORT_A, buffer, ref length))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}
			if ((enable && !resetActiveHigh) || (!enable && resetActiveHigh))
			{
				buffer[0] |= ILAB_RESET;
			}
			else
			{
				buffer[0] &= unchecked((byte)~ILAB_RESET);
			}
			if (!qusb.WritePort((ushort)QuickUsb.Port.PORT_A, buffer, 1))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}
			Thread.Sleep(50);
		}



		public void ResetSensor(bool resetActiveHigh)
		{
			EnableSensor(false, resetActiveHigh);
			EnableSensor(true, resetActiveHigh);
		}



        private void InitLumaView()
        {
            byte portVal=0, regVal=0;
            bool success;
            //QuickUsb qusb = quickUsbWinForms.SelectedModule;

            //Private Sub InitLumaView()
            //   Dim portVal As Byte
            //   Dim regVal As Byte

            //   '== Configure the LumaView ==
            //   ' Set the I/O ports direction
            //   QuickUsbCtl.WritePortDir 3, &H3F
            //   Sleep 10
            //return;
            success = qusb.WritePortDir(QuickUsb.Port.D, 0x3f);
            Thread.Sleep(10);
               
            //   ' Turn on port D bits in sequence
            //   portVal = &H28
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            portVal = 0x28;
            success = qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);
               
            //   portVal = portVal Or &H1      ' Set D0
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            portVal |= 0x01;
            success = qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);
               
            //   portVal = portVal Or &H2      ' Set D1
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            portVal |= 0x02;
            success = qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);

            //   ' Tell the sensor to turn off it's onboard regulator
            //   ReadSensorRegByte &H60, &H63, regVal, COM_I2C
            //   Sleep 10
            //   regVal = regVal Or &H4
            //   WriteSensorRegByte &H61, &H63, regVal, COM_I2C
            //   Sleep 10
            success = ReadSensorReg(sensorAddress, 0x63, ref regVal);
            Thread.Sleep(10);
            regVal |= 0x04;
            success = WriteSensorReg(sensorAddress, 0x63, regVal);
            Thread.Sleep(10);
               
            //   portVal = portVal Or &H4      ' Set D2
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            portVal |= 0x04;
            success = qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);
               
            //   portVal = portVal And &HDF    ' Clear D.5
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            portVal &= 0xDF;
            success = qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);
               
            //   portVal = portVal And &HF7    ' Clear D.3
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            portVal &= 0xF7;
            success = qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);
                              
            //   portVal = portVal Or &H8      ' Set D3 to take the sensor out of reset
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            //End Sub
            portVal |= 0x08;
            success = qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);
        }



		private void SensorSelect()
        {
			if (qusb == null)
			{
                qusb = quickUsbWinForms.SelectedModule;
                if (qusb == null)
                {
                    return;
                }
			}

			//qusb.SetTimeout(2000);

			byte valueByte;
			ushort valueWord;
			string sensorType = "";
			ushort setting;
			QuickUsb.Error qusbError;
			ushort length;

			byte[] buffer = new byte[3];

			bool foundSensor;
			byte[] i2cAddr;

			tbSensorType.Text = "";
			tbSensorAddress.Text = String.Format("0x{0:X2}", 0);

            ShowStatusMessage("Autodetecting sensor...");

            // Set byte wide mode
            if (!qusb.WriteSetting(QuickUsb.Setting.WordWide, 0))
            {
                // Error
                qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
                ShowStatusMessage("Cannot write WordWide setting");
                return;
            }

			// Disable IFCLK drive
			if (!qusb.ReadSetting(QuickUsb.Setting.FifoConfig, out setting))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}
			setting &= 0xFFDF; // IFCLKOE = tri-state (0xFFDF = ~0x20)
			setting |= 0x0002; // IFCFG = GPIF Master Mode
			if (!qusb.WriteSetting(QuickUsb.Setting.FifoConfig, setting))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}

			// Configure PA[5..0] to default values
			length = 1;
			if (!qusb.ReadPort((ushort)QuickUsb.Port.PORT_A, buffer, ref length))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}
			buffer[0] &= 0xC0; // nRESET = 0)
			if (!qusb.WritePort((ushort)QuickUsb.Port.PORT_A, buffer, 1))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}

			// Configure PA[5..0] to be outputs
			length = 1;
			if (!qusb.ReadPortDir((ushort)QuickUsb.Port.PORT_A, out valueByte))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}
			valueByte |= 0x3F;
			if (!qusb.WritePortDir((ushort)QuickUsb.Port.PORT_A, valueByte))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}

            // Just in case we have a 'LumaView' connected....
            sensorAddress = 0x60;
            InitLumaView();

			// Set the clock speed to 24 MHz
			//SetClockSpeed(SensorClockSpeed.Clock48MHz);


			// We don't know if the reset line is active high or active low, so we must try both
			foundSensor = false;
			i2cAddr = new byte[] { 0x60, (0xBA >> 1) };
			foreach (bool resetActiveHigh in new bool[] { false, true })
			{
				// Reset the sensor
				ResetSensor(resetActiveHigh);
				sensorResetActiveHigh = resetActiveHigh;

				// Loop through all I2C addresses
				for (int addr = 0; addr < 0xff; addr += 2)
				{
					// Disregard reserved I2C addresses
					if ((addr & 0x7f) == 81)
					{
						continue;
					}

					// Scan for Omnivision sensors
					valueByte = 0xff;
					sensorUseCachedWrite = false;
					if (!ReadSensorReg((byte)addr, 0x0A, ref valueByte))
					{
						continue;
					}

					switch (valueByte)
					{
						case 0x76:
							sensorType = "OV7640/OV7141";
							sensorAddress = (byte)addr;
							sensorFile = Directory.GetCurrentDirectory() + @"\..\..\Sensors\ov7141.txt";
							sensorDepthBytes = 1;
							sensorClockSpeed = SensorClockSpeed.Clock24MHz;
							sensorRegWidth = 8;
							foundSensor = true;
							break;
						case 0x96:
							sensorType = "OV9620/OV9121";
							sensorAddress = (byte)addr;
							sensorFile = Directory.GetCurrentDirectory() + @"\..\..\Sensors\ov9121.txt";
							sensorDepthBytes = 1;
							sensorClockSpeed = SensorClockSpeed.Clock24MHz;
							sensorRegWidth = 8;
							foundSensor = true;
							break;
                        case 0x97:
                            sensorType = "OV9712/OV9215";
                            sensorAddress = (byte)addr;
                            sensorFile = Directory.GetCurrentDirectory() + @"\..\..\Sensors\ov9215.txt";
                            sensorDepthBytes = 1;
                            sensorClockSpeed = SensorClockSpeed.Clock24MHz;
                            sensorRegWidth = 8;
                            foundSensor = true;
                            InitLumaView();
                            break;
                        default:
							break;
					}
					if (foundSensor)
					{
						break;
					}

					// Scan for Micron sensors
					sensorUseCachedWrite = true;
					valueWord = 0xffff;
					if (!ReadSensorReg((byte)addr, 0, ref valueWord))
					{
						break;
					}

					/*length = 1;
					buffer[0] = 0x00; // Register address: Chip version
					if (!qusb.WriteI2C((ushort)(addr | (length << 8)), buffer, length)) // Cached write of 1 byte
					{
						continue;
					}
					length = 2;
					if (!qusb.ReadI2C(addr, buffer, ref length))
					{
						continue;
					}*/
					//switch ((buffer[0] << 8) | buffer[1])

					switch (valueWord)
					{
						case 0x1801:// MT9P401
							sensorType = "MT9P401";
							sensorAddress = (byte)addr;
							sensorFile = Directory.GetCurrentDirectory() + @"\..\..\Sensors\MT9P401.txt";
							sensorDepthBytes = 2;
							sensorClockSpeed = SensorClockSpeed.Clock12MHz;
							sensorRegWidth = 16;
							foundSensor = true;
							break;
					}


					if (foundSensor)
					{
						break;
					}
				}


				if (foundSensor)
				{
					break;
				}
			}

			// Configure the identified sensor
			//cbVideoAcquire.Enabled = foundSensor;
			bLoadSettings.Enabled = foundSensor;
			bVideoBrowse.Enabled = foundSensor;
			cbbRegExRegister.Enabled = foundSensor;
			btRegExValue.Enabled = foundSensor;
			cbClockCPU.Enabled = foundSensor;
			if (foundSensor)
			{
				tbSensorType.Text = sensorType;
				tbSensorAddress.Text = String.Format("0x{0:X2}", sensorAddress);
				SetClockSpeed(sensorClockSpeed);
				LoadConfigFile(sensorFile);
            }
            ShowStatusMessage("");
		}



		public bool LoadConfigFile(string fileName)
		{
			if (!File.Exists(fileName))
			{
                ShowStatusMessage(String.Format("Unable to open sensor file: {0}", fileName));
                return false;
			}

			ShowStatusMessage(String.Format("Loading sensor configuration file from {0}", fileName));

			cbbRegExRegister.Items.Clear();

			using (StreamReader fin = new StreamReader(fileName))
			{
				// Clear the register combobox
				cbbRegExRegister.Items.Clear();

				string line;
				string[] tokens;
				while ((line = fin.ReadLine()) != null)
				{
					if (line.Contains(";"))
					{
						line = line.Split(';')[0];
					}
					tokens = line.Trim().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
					if (tokens.Length == 0)
					{
						continue;
					}

					switch (tokens[0].ToLower())
					{
						case "rows":
                            m_rows = ushort.Parse(tokens[1]);
							break;
						case "cols":
                            m_cols = ushort.Parse(tokens[1]);
                            break;
						case "depth":
							sensorDepthBytes = (byte)((Convert.ToInt32(tokens[1]) <= 8) ? 1 : 2);
							break;
						case "reg":
							// Add the register definition to the combobox
							cbbRegExRegister.Items.Add(String.Format("0x{0} - {1}", tokens[1], tokens[2]));
							break;
						case "regwidth":
							sensorRegWidth = (Convert.ToInt32(tokens[1]) <= 8) ? (byte)8 : (byte)16;
							btRegExValue.Bits = sensorRegWidth;
							break;
						case "i2ccachedwrite":
							sensorUseCachedWrite = (Convert.ToInt32(tokens[1]) == 0) ? false : true;
							break;
						default:
							// Execute sensor "boot code"
							if (tokens.Length == 3 && byte.Parse(tokens[0], System.Globalization.NumberStyles.HexNumber) == sensorAddress)
							{
								if (sensorRegWidth == 8)
								{
									if (!WriteSensorReg(byte.Parse(tokens[0], System.Globalization.NumberStyles.HexNumber),
														byte.Parse(tokens[1], System.Globalization.NumberStyles.HexNumber),
														byte.Parse(tokens[2], System.Globalization.NumberStyles.HexNumber)))
									{
										return false;
									}
                                    Thread.Sleep(10);
								}
								else if (sensorRegWidth == 16)
								{
									if (!WriteSensorReg(byte.Parse(tokens[0], System.Globalization.NumberStyles.HexNumber),
														byte.Parse(tokens[1], System.Globalization.NumberStyles.HexNumber),
														ushort.Parse(tokens[2], System.Globalization.NumberStyles.HexNumber)))
									{
										return false;
                                    }
                                    Thread.Sleep(10);
								}
								else
								{
									return false;
								}
							}
							else
							{
								return false;
							}
							break;
					}
				}

				// Select the first sensor registor
				cbbRegExRegister.SelectedIndex = 0;
			}

            SetImageSize(m_rows, m_cols);
			return true;
		}



		public bool ReadSensorReg(byte sensorAddr, byte regAddr, ref byte value)
		{
			QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return false;
			}

			bool result;
			byte[] data = new byte[2] { regAddr, 0 };
			ushort length;

			length = 1;
            result = qusb.WriteI2C((ushort)(sensorAddr >> 1), data, length);
            result &= qusb.ReadI2C((ushort)(sensorAddr >> 1), data, ref length);

			value = result ? data[0] : (byte)0xff;

			return result;
		}



		public bool ReadSensorReg(byte sensorAddr, byte regAddr, ref ushort value)
		{
			QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return false;
			}

			bool result;
			byte[] data = new byte[2] { regAddr, 0 };
			ushort length;

			length = 1;
			if (sensorUseCachedWrite)
			{
                result = qusb.WriteI2C((ushort)((sensorAddr >> 1) | (length << 8)), data, length);
				length = 2;
                result &= qusb.ReadI2C((ushort)(sensorAddr >> 1), data, ref length);
			}
			else
			{
                result = qusb.WriteI2C((ushort)(sensorAddr >> 1), data, length);
				length = 2;
                result &= qusb.ReadI2C((ushort)(sensorAddr >> 1), data, ref length);
			}

			value = (ushort)(result ? ((data[0] << 8) | data[1]) : 0xffff);

			return result;
		}



		public bool WriteSensorReg(byte sensorAddr, byte regAddr, byte value)
		{
			QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return false;
			}

            bool result = qusb.WriteI2C((ushort)(sensorAddr >> 1), new byte[] { regAddr, value }, 2);

            return result;
		}



		public bool WriteSensorReg(byte sensorAddr, byte regAddr, ushort value)
		{
			QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return false;
			}

            bool result = qusb.WriteI2C((ushort)(sensorAddr >> 1), new byte[] { regAddr, (byte)((value >> 8) & 0xff), (byte)(value & 0xff) }, 3);

            return result;
		}



		public void SetClockSpeed(SensorClockSpeed clock)
		{
			BitwiseSystems.QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return;
			}

			ushort value = 0;
			if (!qusb.ReadSetting(QuickUsb.Setting.CpuConfig, out value))
			{
				return;
			}

			switch (clock)
			{
				case SensorClockSpeed.Clock12MHz:
					qusb.WriteSetting(QuickUsb.Setting.CpuConfig, (ushort)(value & ~0x18));
					cbClockCPU.SelectedIndex = 0;
					break;
				case SensorClockSpeed.Clock24MHz:
					qusb.WriteSetting(QuickUsb.Setting.CpuConfig, (ushort)((value & ~0x18) | 0x08));
					cbClockCPU.SelectedIndex = 1;
					break;
				case SensorClockSpeed.Clock48MHz:
					qusb.WriteSetting(QuickUsb.Setting.CpuConfig, (ushort)(value | 0x18));
					cbClockCPU.SelectedIndex = 2;
					break;
			}
		}



		private int ParseForNumber(string input)
		{
			if (input == "")
			{
				return -1;
			}

			// Try to parse the input and figure out what register the user is trying to access
			System.Globalization.NumberStyles numStyle = System.Globalization.NumberStyles.Integer;
			input = cbbRegExRegister.Text.Trim().ToLower().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[0];
			if (input.Length == 0)
			{
				return -1;
			}
			if (input.StartsWith("0x") || input.StartsWith("&h"))
			{
				input = input.Substring(2);
				numStyle = System.Globalization.NumberStyles.HexNumber;
			}

			int reg = -1;
			while (true)
			{
				try
				{
					reg = int.Parse(input, numStyle);
					break;
				}
				catch
				{
					if (input.Length <= 1)
						break;
					input = input.Substring(0, input.Length - 1);
				}
			}
			return reg;
		}


		#endregion



		#region Event Handlers

        private void pbFrame_Click(object sender, EventArgs e)
        {
            AcquireSingle();
        }



        private void cbVideoAcquire_CheckedChanged(object sender, EventArgs e)
        {
            QuickUsb qusb = quickUsbWinForms.SelectedModule;

            ShowStatusMessage("");

            cbVideoRecord.Enabled = cbVideoAcquire.Checked;
            bLoadSettings.Enabled = !cbVideoAcquire.Checked;
            cbClockCPU.Enabled = !cbVideoAcquire.Checked;

            if (cbVideoAcquire.Checked)
            {
                StartAcquisition();
            }
            else
            {
                StopAcquisition();
            }
        }



        private void updateTimer_Tick(object sender, EventArgs e)
        {
            if (backBuffer == IntPtr.Zero)
            {
                return;
            }

            lock (image)
            {
                BitmapData bData = image.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.WriteOnly, PixelFormat.Format8bppIndexed);
                MoveMemory(bData.Scan0, backBuffer, m_framesize);
                image.UnlockBits(bData);

                frameRateToolStripStatusLabel.Text = String.Format("FPS: {0:0} Hz", FPS);
                dataRateToolStripStatusLabel.Text = String.Format("Data Rate: {0:0.0} MB/s", DataRate);

                //frameRateToolStripStatusLabel.Text = String.Format("FPS: {0:0.0} Hz", maFPS.Average);
                //dataRateToolStripStatusLabel.Text = String.Format("Data Rate: {0:0.0} MB/s", maDR.Average);

                pbFrame.Refresh();
            }
        }



		private void exitToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.Close();
		}



		private void quickUSBFAQToolStripMenuItem_Click(object sender, EventArgs e)
		{
			System.Diagnostics.Process proc = new System.Diagnostics.Process();
			proc.StartInfo.FileName = "iexplore";
			proc.StartInfo.Arguments = "http://www.quickusb.com/index.php?main_page=page&id=5";
			proc.Start();
		}



		private void quickUSBSupportToolStripMenuItem_Click(object sender, EventArgs e)
		{
			System.Diagnostics.Process proc = new System.Diagnostics.Process();
			proc.StartInfo.FileName = "iexplore";
			proc.StartInfo.Arguments = "http://www.quickusb.com/support/my_view_page.php";
			proc.Start();
		}



		private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
		{
			BitwiseSystems.AboutBox about = new BitwiseSystems.AboutBox();
			about.ShowDialog();
		}



		private void QuickUsbImagerLabCs_Load(object sender, EventArgs e)
		{
			tbVideoFile.Text = string.Format("{0}{1}{2}", Directory.GetCurrentDirectory(), Path.DirectorySeparatorChar, "QuickUsbImageLab.avi");
			tbVideoFile.SelectionStart = tbVideoFile.Text.Length;
			tbVideoFile.ScrollToCaret();
		}


		private void cbClockCPU_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (cbClockCPU.SelectedIndex == 0)
			{
				sensorClockSpeed = SensorClockSpeed.Clock12MHz;
			}
			else if (cbClockCPU.SelectedIndex == 1)
			{
				sensorClockSpeed = SensorClockSpeed.Clock24MHz;
			}
			else if (cbClockCPU.SelectedIndex == 2)
			{
				sensorClockSpeed = SensorClockSpeed.Clock48MHz;
			}
			SetClockSpeed(sensorClockSpeed);
		}



		private void QuickUsbImagerLabCs_FormClosing(object sender, FormClosingEventArgs e)
        {
            StopAcquisition();
		}

		void quickUsbWinForms_SelectionChanged(object sender, EventArgs e)
		{
			SensorSelect();
		}


		private void bVideoBrowse_Click(object sender, EventArgs e)
		{
			using (var diag = new SaveFileDialog())
			{
				diag.Filter = "AVI file type (*.avi)|*.avi";
				if (diag.ShowDialog(this) == DialogResult.OK)
				{
					tbVideoFile.Text = diag.FileName;
					tbVideoFile.SelectionStart = tbVideoFile.Text.Length;
					tbVideoFile.ScrollToCaret();
				}
			}
		}

		private void bLoadSettings_Click(object sender, EventArgs e)
		{
			using (var diag = new OpenFileDialog())
			{
				diag.Filter = "Camera settings file (*.txt)|*.txt";
                //diag.InitialDirectory = Directory.GetCurrentDirectory();
				if (File.Exists(sensorFile))
				{
					diag.FileName = sensorFile;
				}
				else
				{
					diag.FileName = Directory.GetCurrentDirectory();
				}
				if (diag.ShowDialog(this) == DialogResult.OK)
				{
					LoadConfigFile(diag.FileName);
				}
			}
		}



		private void cbbRegExRegister_SelectedIndexChanged(object sender, EventArgs e)
		{
			byte valueByte;
			ushort valueWord;
			int regAddr;

			if (cbbRegExRegister == null)
			{
				return;
			}
			bRegExWrite.Enabled = (cbbRegExRegister.SelectedItem != null);

			// Read sensor register
			regAddr = ParseForNumber(cbbRegExRegister.Text);
			if (regAddr != -1)
			{
				if (sensorRegWidth == 8)
				{
					valueByte = 0;
					if (!ReadSensorReg(sensorAddress, (byte)regAddr, ref valueByte))
					{
						return;
					}

					// Update the BitTwiddler control
					if (btRegExValue.Value != valueByte)
					{
						btRegExValue.Value = (uint)valueByte;
					}
				}
				else
				{
					valueWord = 0;
					if (!ReadSensorReg(sensorAddress, (byte)regAddr, ref valueWord))
					{
						return;
					}

					// Update the BitTwiddler control
					if (btRegExValue.Value != valueWord)
					{
						btRegExValue.Value = (uint)valueWord;
					}
				}
			}
		}



		private void btRegExValue_ValueChanged(object sender, uint btValue)
		{
			// Get the register address
			int regAddr = ParseForNumber(cbbRegExRegister.Text);
			if (regAddr != -1)
			{
				// Write the sensor register
				if (sensorRegWidth == 8)
				{
					WriteSensorReg(sensorAddress, (byte)regAddr, (byte)btValue);
				}
				else
				{
					WriteSensorReg(sensorAddress, (byte)regAddr, (ushort)btValue);
				}
			}
		}



		private void bRegExWrite_Click(object sender, EventArgs e)
		{
			byte value;
			try
			{
				value = byte.Parse(btRegExValue.TextValue, System.Globalization.NumberStyles.HexNumber);
			}
			catch (FormatException)
			{
				MessageBox.Show("Register value must be a valid two-digit (1 byte) hex number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			catch (OverflowException)
			{
				MessageBox.Show("Register value must be a valid two-digit (1 byte) hex number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			// Write the sensor register
			btRegExValue.Value = value;
			btRegExValue_ValueChanged(sender, value);
		}



		private void cbVideoRecord_CheckedChanged(object sender, EventArgs e)
		{
			if (cbVideoRecord.Checked)
			{
				if (tbVideoFile.Text == "")
				{
					MessageBox.Show("Please select a file to save the video to", "Video Capture Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					cbVideoRecord.Checked = false;
					return;
				}
				if (File.Exists(tbVideoFile.Text))
				{
					if (MessageBox.Show("The file you are intending to record to already exists.  Would you like to overwrite it?", "Video Capture", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No)
					{
						cbVideoRecord.Checked = false;
						return;
					}
				}
				aviRecorder = new BmpToAVI.BmpToAVI(this.Handle);
				int result = aviRecorder.Init(tbVideoFile.Text, pbFrame.Width, pbFrame.Height, 15/*(int)maFps.Average*/);
				if (result != 0)
				{
					MessageBox.Show(String.Format("Unable to record video with selected codec (Error: {0})", result), "Video Recording Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					cbVideoRecord.Checked = false;
					return;
				}
				recordVideo = true;
			}
			else
			{
				recordVideo = false;
				if (aviRecorder != null)
				{
					aviRecorder.closeAll();
					aviRecorder = null;
				}
			}
		}



		private void regTimer_Tick(object sender, EventArgs e)
		{
			cbbRegExRegister_SelectedIndexChanged(sender, null);
		}



		private void cbbRegExRegister_TextChanged(object sender, EventArgs e)
		{
			cbbRegExRegister_SelectedIndexChanged(sender, null);
		}



        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pbFrame.Image.Save("snap.jpg", ImageFormat.Jpeg);
        }

		#endregion

	}


	
	class movingAverage
	{
		double[] samples;
		int lastSample = 0, numSamples = 0;
        double sum;

		public movingAverage(int maxSamples)
		{
            samples = new double[maxSamples];
		}



		public void reset()
		{
			numSamples = 0;
			samples.Initialize();
		}



        public void addSample(double value)
		{
			sum -= samples[lastSample];
			samples[lastSample] = value;
			sum += value;

			if (++lastSample == samples.Length)
			{
				lastSample = 0;
			}

			++numSamples;
		}



        public double Average
		{
			get
			{
				if (numSamples == 0)
				{
					return 0.0f;
				}
				else if (numSamples < samples.Length)
				{
					return sum / numSamples;
				}
				else
				{
					return sum / samples.Length;
				}
			}
		}
	}
}
