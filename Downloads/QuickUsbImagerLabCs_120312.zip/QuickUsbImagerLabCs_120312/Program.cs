using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace BitwiseSystems
{
	static class Program
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		/// 

		static QuickUsbImagerLabCs qusbUsbDiag;

		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			qusbUsbDiag = new QuickUsbImagerLabCs();
			Application.Run(qusbUsbDiag);
		}

		static public QuickUsbImagerLabCs QuickUsbImagerLabCs {
			get { return qusbUsbDiag; }
		}
	}
}