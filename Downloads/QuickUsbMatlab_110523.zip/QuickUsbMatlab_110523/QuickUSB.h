/*=============================================================================
 Title        : QuickUSB.c
 Description  : QuickUSB QUSB2 Module API
 Notes        : None
 History      :

 Copyright (c) 2003-2010 Bitwise Systems.  All rights reserved.
 This software contains confidential information and trade secrets of
 Bitwise Systems and is protected by United States and international
 copyright laws.  Use, disclosure, or reproduction is prohibited without
 the prior express written permission of Bitwise Systems, except as agreed
 in the QuickUSB Plug-In Module license agreement.

 Use, duplication or disclosure by the U.S. Government is subject to
 restrictions as provided in DFARS 227.7202-1(a) and 227.7202-3(a)
 (1998), and FAR 12.212, as applicable.  Bitwise Systems, 6489 Calle Real, Suite E,
 Goleta, CA  93117.

 Bitwise Systems
 6489 Calle Real, Suite E
 Santa Barbara, CA  93117
 Voice: (805) 683-6469
 Fax  : (805) 683-4833
 Web  : www.bitwisesys.com
 email: support@bitwisesys.com

=============================================================================*/
#ifndef __QUICKUSB_LIBRARY_HEADER__
#define __QUICKUSB_LIBRARY_HEADER__

#ifdef __cplusplus
extern "C" {
#endif

#ifdef _WIN32
#include <windows.h>
#endif

// QuickUSB String Descriptor Indices
#define QUICKUSB_MAKE                           1
#define QUICKUSB_MODEL                          2
#define QUICKUSB_SERIAL                         3

// QuickUSB Port Addresses
#define PORT_A									0
#define PORT_B									1
#define PORT_C									2
#define PORT_D									3
#define PORT_E									4

// QuickUSB Settings
#define SETTING_EP26CONFIG                      0
#define SETTING_WORDWIDE                        1
#define SETTING_DATAADDRESS                     2
#define SETTING_FIFO_CONFIG                     3
#define SETTING_FPGATYPE                        4
#define SETTING_CPUCONFIG                       5
#define SETTING_SPICONFIG                       6
#define SETTING_SLAVEFIFOFLAGS                  7
#define SETTING_I2CTL                           8
#define SETTING_PORTA                           9
#define SETTING_PORTB                           10
#define SETTING_PORTC                           11
#define SETTING_PORTD                           12
#define SETTING_PORTE                           13
#define SETTING_PORTACCFG                       14
#define SETTING_PINFLAGS                        15
#define SETTING_VERSIONBUILD                    16
#define SETTING_VERSIONSPEED                    17
#define SETTING_TIMEOUT_HIGH                    18
#define SETTING_TIMEOUT_LOW                     19

// FPGA Configuration Type Settings
#define FPGATYPE_ALTERAPS                       0
#define FPGATYPE_XILINXSS                       1


/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  QuickUSB Error Codes
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
#define QUICKUSB_ERROR_NO_ERROR                 0
#define QUICKUSB_ERROR_OUT_OF_MEMORY            1
#define QUICKUSB_ERROR_CANNOT_OPEN_MODULE       2
#define QUICKUSB_ERROR_CANNOT_FIND_DEVICE       3
#define QUICKUSB_ERROR_IOCTL_FAILED             4
#define QUICKUSB_ERROR_INVALID_PARAMETER        5
#define QUICKUSB_ERROR_TIMEOUT                  6
#define QUICKUSB_ERROR_FUNCTION_NOT_SUPPORTED   7
#define QUICKUSB_ERROR_I2C_BUS_ERROR            8
#define QUICKUSB_ERROR_I2C_NO_ACK               9
#define QUICKUSB_ERROR_I2C_SLAVE_WAIT           10
#define QUICKUSB_ERROR_I2C_TIMEOUT              11
#define QUICKUSB_ERROR_UNKNOWN_DRIVER_TYPE      12
#define QUICKUSB_ERROR_ALREADY_OPENED           13
#define QUICKUSB_ERROR_CANNOT_CLOSE_MODULE      14
#define QUICKUSB_ERROR_FPGA_INIT_FAILED			15
#define QUICKUSB_ERROR_PACKET_NOT_MULTIPLE_512  16
#define QUICKUSB_ERROR_PACKET_NOT_MULTIPLE_64   17
#define QUICKUSB_ERROR_UNKNOWN_SYSTEM_ERROR     18
#define QUICKUSB_ERROR_ABORTED                  19

#define QUICKUSB_ERROR_DRIVER                   100
#define QUICKUSB_ERROR_DRIVER_URB               101
#define QUICKUSB_ERROR_DRIVER_BULK              102
#define QUICKUSB_ERROR_DRIVER_ASYNC             103
#define QUICKUSB_ERROR_DRIVER_PIPE              104
#define QUICKUSB_ERROR_DRIVER_BUSY              104


/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  QuickUSB Flags 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
#define QUICKUSB_OPEN_NORMAL					0x0000
#define QUICKUSB_OPEN_IF_CLOSED					0x0001


/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  QuickUSB Type Defintions
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
#define QBOOL	unsigned char
#if defined __APPLE__
#define BOOL    unsigned char
#endif
#define QBYTE	unsigned char
#define PQBYTE	*QBYTE
#define QCHAR	char
#define PQCHAR	*QCHAR
#define QWORD   unsigned short
#define PQWORD	*QWORD
#define QLONG	signed long
#define PQLONG	*QLONG
#define QULONG	unsigned long
#define PQULONG *QULONG
#ifdef _WIN32
#define QHANDLE	HANDLE
#elif defined __linux__
#define HANDLE  signed short
#define QHANDLE HANDLE
#elif defined __APPLE__
#define QHANDLE QLONG
#define HANDLE IOUSBInterfaceInterface245 **
#endif
#define PQHANDLE *QHANDLE
#define QRESULT	QLONG
#ifdef _WIN32
#define QRETURN QRESULT __stdcall
#elif defined __linux__
#define QRETURN QRESULT
#elif defined __APPLE__
#define QRETURN QRESULT
#endif
#define QUSBLIB extern


/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  External Function Declarations
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
QUSBLIB QRETURN QuickUsbGetLastError(QULONG *error);

QUSBLIB QRETURN QuickUsbFindModules(QCHAR *nameList,
                                   QULONG length);

QUSBLIB QRETURN QuickUsbOpen(QHANDLE *hDevice, 
                            QCHAR *deviceName);

QUSBLIB QRETURN QuickUsbOpenEx(QHANDLE *hDevice, 
							   QCHAR *deviceName, 
							   QWORD flags);

QUSBLIB QRETURN QuickUsbClose(QHANDLE hDevice);

QUSBLIB QRETURN QuickUsbGetStringDescriptor(QHANDLE hDevice, 
                                           QBYTE index,
                                           QCHAR *buffer, 
                                           QWORD length);

QUSBLIB QRETURN QuickUsbReadSetting(QHANDLE hDevice, 
                                   QWORD address, 
                                   QWORD *value);

QUSBLIB QRETURN QuickUsbWriteSetting(QHANDLE hDevice,
                                    QWORD address, 
                                    QWORD value);

QUSBLIB QRETURN QuickUsbStartFpgaConfiguration(QHANDLE hDevice);

QUSBLIB QRETURN QuickUsbWriteFpgaData(QHANDLE hDevice, 
                                     QBYTE *fpgadata, 
                                     QULONG datalength);

QUSBLIB QRETURN QuickUsbIsFpgaConfigured(QHANDLE hDevice, 
              	                        QWORD *isConfigured);

QUSBLIB QRETURN QuickUsbReadCommand(QHANDLE hDevice, 
                                   QWORD address, 
                                   QBYTE *data, 
                                   QWORD *length);

QUSBLIB QRETURN QuickUsbWriteCommand(QHANDLE hDevice, 
                                    QWORD address, 
                                    QBYTE *data, 
                                    QWORD length);

QUSBLIB QRETURN QuickUsbReadData(QHANDLE hDevice, 
                                QBYTE *data, 
                                QULONG *length);
/*
QUSBLIB QRETURN QuickUsbReadDataEx(QHANDLE hDevice,
								  QBYTE *buffer, 
								  QULONG length,
								  QOVERLAPPED *overlapped);

QUSBLIB QRETURN QuickUsbWaitEx(QHANDLE hDevice,
							  QOVERLAPPED *overlapped,
							  QULONG *bytesTransferred,
							  BOOL wait);*/

QUSBLIB QRETURN QuickUsbWriteData(QHANDLE hDevice, 
                                 QBYTE *data, 
                                 QULONG length);

QUSBLIB QRETURN QuickUsbReadPortDir(QHANDLE hDevice, 
                                   QWORD address, 
                                   QBYTE *data);

QUSBLIB QRETURN QuickUsbWritePortDir(QHANDLE hDevice, 
                                    QWORD address, 
                                    QBYTE data);

QUSBLIB QRETURN QuickUsbReadPort(QHANDLE hDevice, 
                                QWORD address, 
                                QBYTE *data, 
                                QWORD *length);

QUSBLIB QRETURN QuickUsbWritePort(QHANDLE hDevice, 
                                 QWORD address, 
                                 QBYTE *data, 
                                 QWORD length);

QUSBLIB QRETURN QuickUsbSetRS232BaudRate(QHANDLE hDevice, 
                                        QULONG baudRate);

QUSBLIB QRETURN QuickUsbGetNumRS232(QHANDLE hDevice, 
                                   QBYTE portNum, 
                                   QWORD *length);

QUSBLIB QRETURN QuickUsbFlushRS232(QHANDLE hDevice, 
                                  QBYTE portNum);

QUSBLIB QRETURN QuickUsbReadRS232(QHANDLE hDevice, 
                                 QBYTE portNum, 
                                 QBYTE *data, 
                                 QWORD *length);

QUSBLIB QRETURN QuickUsbWriteRS232(QHANDLE hDevice, 
                                  QBYTE portNum, 
                                  QBYTE *data, 
                                  QWORD length);

QUSBLIB QRETURN QuickUsbReadSpi(QHANDLE hDevice, 
                               QBYTE portNum,
                               QBYTE *data, 
                               QWORD *length);

QUSBLIB QRETURN QuickUsbWriteSpi(QHANDLE hDevice, 
                                QBYTE portNum,
                                QBYTE *data, 
                                QWORD length);

QUSBLIB QRETURN QuickUsbWriteReadSpi(QHANDLE hDevice, 
                                    QBYTE portNum, 
                                    QBYTE *data, 
                                    QWORD length);

QUSBLIB QRETURN QuickUsbReadI2C(QHANDLE hDevice, 
                               QWORD address, 
                               QBYTE *data, 
                               QWORD *length);

QUSBLIB QRETURN QuickUsbWriteI2C(QHANDLE hDevice, 
                                QWORD address, 
                                QBYTE *data,
                                QWORD length);

QUSBLIB QRETURN QuickUsbCachedWriteI2C(QHANDLE hDevice,
									  QWORD address,
									  QBYTE *data,
									  QWORD length);

QUSBLIB QRETURN QuickUsbSetTimeout(QHANDLE hDevice,
                                  QULONG timeOut);

QUSBLIB QRETURN QuickUsbGetDriverVersion(QWORD *MajorDriverVersion,
                                        QWORD *MinorDriverVersion,
                                        QWORD *BuildDriverVersion);

QUSBLIB QRETURN QuickUsbGetDllVersion(QWORD *MajorDllVersion,
                                     QWORD *MinorDllVersion,
                                     QWORD *BuildDllVersion);

QUSBLIB QRETURN QuickUsbGetFirmwareVersion(QHANDLE hDevice, 
                                          QWORD *MajorFirmwareVersion,
                                          QWORD *MinorFirmwareVersion,
                                          QWORD *BuildFirmwareVersion);

QUSBLIB QRETURN QuickUsbWriteDataAsync(QHANDLE hDevice, 
                                      QBYTE *data, 
                                      QULONG length, 
                                      QBYTE *transaction);

QUSBLIB QRETURN QuickUsbReadDataAsync(QHANDLE hDevice, 
                                     QBYTE *data, 
                                     QULONG *length, 
                                     QBYTE *transaction);

QUSBLIB QRETURN QuickUsbAsyncWait(QHANDLE hDevice, 
                                 QULONG *bytecount,
                                 QBYTE transaction,
                                 QBYTE immediate);

QUSBLIB QRETURN QuickUsbReadDefault(QHANDLE hDevice,
                                   QWORD address, 
                                   QWORD *data);

QUSBLIB QRETURN QuickUsbWriteDefault(QHANDLE hDevice,
                                    QWORD address, 
                                    QWORD data);

QUSBLIB QRETURN QuickUsbReadStorage(QHANDLE hDevice, 
                               QWORD address, 
                               QBYTE *data, 
                               QWORD bytes);

QUSBLIB QRETURN QuickUsbWriteStorage(QHANDLE hDevice, 
                                QWORD address, 
                                QBYTE *data,
                                QWORD bytes);


//struct QOVERLAPPED;

typedef void (WINAPI *QOVERLAPPED_COMPLETION_ROUTINE) (
	QHANDLE hDevice,
	QULONG errorCode,
	QBYTE *buffer,
	QULONG bytesRequested,
	QULONG bytesTransfered,
	struct QOVERLAPPED *overlapped
);


typedef struct QOVERLAPPED {
	QHANDLE hDevice;
	QBYTE *buffer;
	QULONG bytesRequested;
	OVERLAPPED /*ctlOvl, */bulkOvl;
	DWORD errorCode;

	//QOVERLAPPED_COMPLETION_ROUTINE completionRoutine;
	QULONG *completionRoutine;

	QULONG *tag;
} QOVERLAPPED, *PQOVERLAPPED;


VOID CALLBACK QuickUsbCompletionRoutine(
  __in  DWORD dwErrorCode,
  __in  DWORD dwNumberOfBytesTransferred,
  __in  LPOVERLAPPED lpOverlapped
);


QUSBLIB QRETURN QuickUsbReadDataEx(
	QHANDLE hDevice,
	QBYTE *buffer, 
	QULONG length,
	QOVERLAPPED *overlapped,
	QOVERLAPPED_COMPLETION_ROUTINE completionRoutine);

QUSBLIB QRETURN QuickUsbWaitEx(
	QHANDLE hDevice, 
	QULONG milliseconds, 
	QOVERLAPPED *overlapped
);


#ifdef __cplusplus
}
#endif

#endif // #ifdef __QUICKUSB_LIBRARY_HEADER__

