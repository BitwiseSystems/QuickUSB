﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using BitwiseSystems;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices;



namespace BitwiseSystems
{
	public partial class QuickUsbImagerLabCs : Form
	{
		#region Instance Variables


		public enum SensorClockSpeed
		{
			Clock12MHz = 0,
			Clock24MHz = 1,
			Clock48MHz = 3,
		}

		const byte ILAB_RESET = 0x08;
        const float MB = 1024.0f * 1024.0f;

		// Instance variables		
		SensorClockSpeed sensorClockSpeed;
		byte sensorAddress;
		byte sensorDepthBytes = 2;
		byte sensorRegWidth = 8;
		bool sensorUseCachedWrite = false;
		bool sensorResetActiveHigh;

		string sensorFile;
		BmpToAVI.BmpToAVI aviRecorder;
		bool recordVideo = false;

		int t1, t2, tStart;
		uint bytecount = 0;
        ushort m_rows = 480;
        ushort m_cols = 640;
        uint m_framesize;
        bool active = true;
		List<byte[]> imageBuffer;
		Bitmap image;
		bool firmwareWarning = false;


		#endregion


		#region Public Methods


		// Contructor
		public QuickUsbImagerLabCs()
		{
			InitializeComponent();
            
            quickUsbWinForms.ScanEnabled = true;
			quickUsbWinForms.ScanOnLoad = true;
            SetImageSize(m_rows, m_cols);
		}



		public void ShowStatusMessage(string message)
		{
			toolStripStatusLabel.Text = message;
		}



        public void SetImageSize(ushort rows, ushort cols)
        {
            m_rows = rows;
            m_cols = cols;
            m_framesize = (uint)rows * (uint)cols * sensorDepthBytes;

            imageBuffer = new List<byte[]>();
            for (int i = 0; i < 6; i++)
            {
                imageBuffer.Add(new byte[rows * cols]);
            }

            image = new Bitmap(cols, rows, System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
            ColorPalette palette = image.Palette;
            for (int k = 0; k < palette.Entries.Length; ++k)
            {
                palette.Entries[k] = Color.FromArgb(255, k, k, k);
            }
            image.Palette = palette;

            // Set the initial image (black)
            pbFrame.Image = image;

        }


		public void EnableSensor(bool enable, bool resetActiveHigh)
		{
			QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return;
			}

			ushort length;
			byte[] buffer = new byte[1];
			QuickUsb.Error qusbError;

			length = 1;
			if (!qusb.ReadPort((ushort)QuickUsb.Port.PORT_A, buffer, ref length))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}
			if ((enable && !resetActiveHigh) || (!enable && resetActiveHigh))
			{
				buffer[0] |= ILAB_RESET;
			}
			else
			{
				buffer[0] &= unchecked((byte)~ILAB_RESET);
			}
			if (!qusb.WritePort((ushort)QuickUsb.Port.PORT_A, buffer, 1))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}
			Thread.Sleep(50);
		}



		public void ResetSensor(bool resetActiveHigh)
		{
			EnableSensor(false, resetActiveHigh);
			EnableSensor(true, resetActiveHigh);
		}



        private void InitLumaView()
        {
            byte portVal=0, regVal=0;
            QuickUsb qusb = quickUsbWinForms.SelectedModule;

            //Private Sub InitLumaView()
            //   Dim portVal As Byte
            //   Dim regVal As Byte

            //   '== Configure the LumaView ==
            //   ' Set the I/O ports direction
            //   QuickUsbCtl.WritePortDir 3, &H3F
            //   Sleep 10
            qusb.WritePortDir(QuickUsb.Port.D, 0x3f);
            Thread.Sleep(10);
               
            //   ' Turn on port D bits in sequence
            //   portVal = &H28
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            portVal = 0x28;
            qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);
               
            //   portVal = portVal Or &H1      ' Set D0
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            portVal |= 0x01;
            qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);
               
            //   portVal = portVal Or &H2      ' Set D1
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            portVal |= 0x02;
            qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);

            //   ' Tell the sensor to turn off it's onboard regulator
            //   ReadSensorRegByte &H60, &H63, regVal, COM_I2C
            //   Sleep 10
            //   regVal = regVal Or &H4
            //   WriteSensorRegByte &H61, &H63, regVal, COM_I2C
            //   Sleep 10

            ReadSensorReg(sensorAddress, 0x63, ref regVal);
            Thread.Sleep(10);
            regVal |= 0x04;
            WriteSensorReg(sensorAddress, 0x63, regVal);
            Thread.Sleep(10);
               
            //   portVal = portVal Or &H4      ' Set D2
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            portVal |= 0x04;
            qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);
               
            //   portVal = portVal And &HDF    ' Clear D.5
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            portVal &= 0xDF;
            qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);
               
            //   portVal = portVal And &HF7    ' Clear D.3
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            portVal &= 0xF7;
            qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);
                              
            //   portVal = portVal Or &H8      ' Set D3 to take the sensor out of reset
            //   QuickUsbCtl.WritePort 3, portVal
            //   Sleep 10
            //End Sub
            portVal |= 0x08;
            qusb.WritePort(QuickUsb.Port.D, portVal);
            Thread.Sleep(10);
        }



		private bool ValidateHardware()
		{
			QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return false;
			}

			// Check that the module has ImagerLab firmware installed
			if (!firmwareWarning && !qusb.Model.Contains("ImagerLab"))
			{
				MessageBox.Show("The selected module does nt contain the ImagerLab firmware", "Firmware Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				firmwareWarning = true;
				return false;
			}

			return true;
		}



		private void SensorSelect()
		{
			QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return;
			}

			qusb.SetTimeout(2000);

			byte valueByte;
			ushort valueWord;
			string sensorType = "";
			ushort setting;
			QuickUsb.Error qusbError;
			ushort length;

			byte[] buffer = new byte[3];

			bool foundSensor;
			byte[] i2cAddr;

			tbSensorType.Text = "";
			tbSensorAddress.Text = String.Format("0x{0:X2}", 0);

			ShowStatusMessage("Autodetecting sensor...");


			// Disable IFCLK drive
			if (!qusb.ReadSetting(QuickUsb.Setting.FifoConfig, out setting))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}
			setting &= 0xFFDF; // IFCLKOE = tri-state (0xFFDF = ~0x20)
			setting |= 0x0002; // IFCFG = GPIF Master Mode
			if (!qusb.WriteSetting(QuickUsb.Setting.FifoConfig, setting))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}

			// Configure PA[5..0] to default values
			length = 1;
			if (!qusb.ReadPort((ushort)QuickUsb.Port.PORT_A, buffer, ref length))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}
			buffer[0] &= 0xC0; // nRESET = 0)
			if (!qusb.WritePort((ushort)QuickUsb.Port.PORT_A, buffer, 1))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}

			// Configure PA[5..0] to be outputs
			length = 1;
			if (!qusb.ReadPortDir((ushort)QuickUsb.Port.PORT_A, out valueByte))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}
			valueByte |= 0x3F;
			if (!qusb.WritePortDir((ushort)QuickUsb.Port.PORT_A, valueByte))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				ShowStatusMessage("Sensor error...");
				return;
			}

            // Just in case we have a 'LumaView' connected....
            InitLumaView();

			// Set the clock speed to 24 MHz
			//SetClockSpeed(SensorClockSpeed.Clock48MHz);


			// We don't know if the reset line is active high or active low, so we must try both
			foundSensor = false;
			i2cAddr = new byte[] { 0x60, (0xBA >> 1) };
			foreach (bool resetActiveHigh in new bool[] { false, true })
			{
				// Reset the sensor
				ResetSensor(resetActiveHigh);
				sensorResetActiveHigh = resetActiveHigh;

				// Loop through all I2C addresses
				for (int addr = 0; addr < 0xff; addr += 2)
				{
					// Disregard reserved I2C addresses
					if ((addr & 0x7f) == 81)
					{
						continue;
					}

					// Scan for Omnivision sensors
					valueByte = 0xff;
					sensorUseCachedWrite = false;
					if (!ReadSensorReg((byte)addr, 0x0A, ref valueByte))
					{
						break;
					}

					switch (valueByte)
					{
						case 0x76:
							sensorType = "OV7640/OV7141";
							sensorAddress = (byte)addr;
							sensorFile = Directory.GetCurrentDirectory() + @"\..\..\Sensors\ov7141.txt";
							sensorDepthBytes = 1;
							sensorClockSpeed = SensorClockSpeed.Clock24MHz;
							sensorRegWidth = 8;
							sensorDepthBytes = 1;
							foundSensor = true;
							break;
						case 0x96:
							sensorType = "OV9620/OV9121";
							sensorAddress = (byte)addr;
							sensorFile = Directory.GetCurrentDirectory() + @"\..\..\Sensors\ov9121.txt";
							sensorDepthBytes = 1;
							sensorClockSpeed = SensorClockSpeed.Clock24MHz;
							sensorRegWidth = 8;
							sensorDepthBytes = 1;
							foundSensor = true;
							break;
                        case 0x97:
                            sensorType = "OV9715/OV9215";
                            sensorAddress = (byte)addr;
                            sensorFile = Directory.GetCurrentDirectory() + @"\..\..\Sensors\ov9215.txt";
                            sensorDepthBytes = 1;
                            sensorClockSpeed = SensorClockSpeed.Clock24MHz;
                            sensorRegWidth = 8;
                            sensorDepthBytes = 1;
                            foundSensor = true;
                            break;
                        default:
							break;
					}
					if (foundSensor)
					{
						break;
					}

					// Scan for Micron sensors
					sensorUseCachedWrite = true;
					valueWord = 0xffff;
					if (!ReadSensorReg((byte)addr, 0, ref valueWord))
					{
						break;
					}

					/*length = 1;
					buffer[0] = 0x00; // Register address: Chip version
					if (!qusb.WriteI2C((ushort)(addr | (length << 8)), buffer, length)) // Cached write of 1 byte
					{
						continue;
					}
					length = 2;
					if (!qusb.ReadI2C(addr, buffer, ref length))
					{
						continue;
					}*/
					//switch ((buffer[0] << 8) | buffer[1])

					switch (valueWord)
					{
						case 0x1801:// MT9P401
							sensorType = "MT9P401";
							sensorAddress = (byte)addr;
							sensorFile = Directory.GetCurrentDirectory() + @"\..\..\Sensors\MT9P401.txt";
							sensorDepthBytes = 2;
							sensorClockSpeed = SensorClockSpeed.Clock12MHz;
							sensorRegWidth = 16;
							foundSensor = true;
							break;
					}


					if (foundSensor)
					{
						break;
					}
				}


				if (foundSensor)
				{
					break;
				}
			}

			// Configure the identified sensor
			cbVideoAcquire.Enabled = foundSensor;
			bLoadSettings.Enabled = foundSensor;
			bVideoBrowse.Enabled = foundSensor;
			cbbRegExRegister.Enabled = foundSensor;
			btRegExValue.Enabled = foundSensor;
			cbClockCPU.Enabled = foundSensor;
			if (foundSensor)
			{
				tbSensorType.Text = sensorType;
				tbSensorAddress.Text = String.Format("0x{0:X2}", sensorAddress);
				SetClockSpeed(sensorClockSpeed);
				LoadConfigFile(sensorFile);
			}
		}



		public bool LoadConfigFile(string fileName)
		{
			if (!File.Exists(fileName))
			{
				return false;
			}

			ShowStatusMessage(String.Format("Loading sensor configuration file from {0}", fileName));

			cbbRegExRegister.Items.Clear();

			using (StreamReader fin = new StreamReader(fileName))
			{
				// Clear the register combobox
				cbbRegExRegister.Items.Clear();

				string line;
				string[] tokens;
				while ((line = fin.ReadLine()) != null)
				{
					if (line.Contains(";"))
					{
						line = line.Split(';')[0];
					}
					tokens = line.Trim().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
					if (tokens.Length == 0)
					{
						continue;
					}

					switch (tokens[0].ToLower())
					{
						case "rows":
                            m_rows = ushort.Parse(tokens[1]);
							break;
						case "cols":
                            m_cols = ushort.Parse(tokens[1]);
                            break;
						case "depth":
							sensorDepthBytes = (byte)((Convert.ToInt32(tokens[1]) <= 8) ? 1 : 2);
							break;
						case "reg":
							// Add the register definition to the combobox
							cbbRegExRegister.Items.Add(String.Format("0x{0} - {1}", tokens[1], tokens[2]));
							break;
						case "regwidth":
							sensorRegWidth = (Convert.ToInt32(tokens[1]) <= 8) ? (byte)8 : (byte)16;
							btRegExValue.Bits = sensorRegWidth;
							break;
						case "i2ccachedwrite":
							sensorUseCachedWrite = (Convert.ToInt32(tokens[1]) == 0) ? false : true;
							break;
						default:
							// Execute sensor "boot code"
							if (tokens.Length == 3 && byte.Parse(tokens[0], System.Globalization.NumberStyles.HexNumber) == sensorAddress)
							{
								if (sensorRegWidth == 8)
								{
									if (!WriteSensorReg(byte.Parse(tokens[0], System.Globalization.NumberStyles.HexNumber),
														byte.Parse(tokens[1], System.Globalization.NumberStyles.HexNumber),
														byte.Parse(tokens[2], System.Globalization.NumberStyles.HexNumber)))
									{
										return false;
									}
								}
								else if (sensorRegWidth == 16)
								{
									if (!WriteSensorReg(byte.Parse(tokens[0], System.Globalization.NumberStyles.HexNumber),
														byte.Parse(tokens[1], System.Globalization.NumberStyles.HexNumber),
														ushort.Parse(tokens[2], System.Globalization.NumberStyles.HexNumber)))
									{
										return false;
									}
								}
								else
								{
									return false;
								}
							}
							else
							{
								return false;
							}
							break;
					}
				}

                SetImageSize(m_rows, m_cols);

				// Select the first sensor registor
				cbbRegExRegister.SelectedIndex = 0;
			}

			return true;
		}



		public bool ReadSensorReg(byte sensorAddr, byte regAddr, ref byte value)
		{
			QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return false;
			}

			bool result;
			byte[] data = new byte[2] { regAddr, 0 };
			ushort length;

			length = 1;
			result = qusb.WriteI2C((ushort)(sensorAddr >> 1), data, length);
			result &= qusb.ReadI2C((ushort)(sensorAddr >> 1), data, ref length);

			value = result ? data[0] : (byte)0xff;

			return result;
		}



		public bool ReadSensorReg(byte sensorAddr, byte regAddr, ref ushort value)
		{
			QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return false;
			}

			bool result;
			byte[] data = new byte[2] { regAddr, 0 };
			ushort length;

			length = 1;
			if (sensorUseCachedWrite)
			{
				result = qusb.WriteI2C((ushort)((sensorAddr >> 1) | (length << 8)), data, length);
				length = 2;
				result &= qusb.ReadI2C((ushort)(sensorAddr >> 1), data, ref length);
			}
			else
			{
				result = qusb.WriteI2C((ushort)(sensorAddr >> 1), data, length);
				length = 2;
				result &= qusb.ReadI2C((ushort)(sensorAddr >> 1), data, ref length);
			}

			value = (ushort)(result ? ((data[0] << 8) | data[1]) : 0xffff);

			return result;
		}



		public bool WriteSensorReg(byte sensorAddr, byte regAddr, byte value)
		{
			QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return false;
			}

			return qusb.WriteI2C((ushort)(sensorAddr >> 1), new byte[] { regAddr, value }, 2);
		}



		public bool WriteSensorReg(byte sensorAddr, byte regAddr, ushort value)
		{
			QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return false;
			}

			return qusb.WriteI2C((ushort)(sensorAddr >> 1), new byte[] { regAddr, (byte)((value >> 8) & 0xff), (byte)(value & 0xff) }, 3);
		}



		public void SetClockSpeed(SensorClockSpeed clock)
		{
			BitwiseSystems.QuickUsb qusb = quickUsbWinForms.SelectedModule;
			if (qusb == null)
			{
				return;
			}

			ushort value = 0;
			if (!qusb.ReadSetting(QuickUsb.Setting.CpuConfig, out value))
			{
				return;
			}

			switch (clock)
			{
				case SensorClockSpeed.Clock12MHz:
					qusb.WriteSetting(QuickUsb.Setting.CpuConfig, (ushort)(value & ~0x18));
					cbClockCPU.SelectedIndex = 0;
					break;
				case SensorClockSpeed.Clock24MHz:
					qusb.WriteSetting(QuickUsb.Setting.CpuConfig, (ushort)((value & ~0x18) | 0x08));
					cbClockCPU.SelectedIndex = 1;
					break;
				case SensorClockSpeed.Clock48MHz:
					qusb.WriteSetting(QuickUsb.Setting.CpuConfig, (ushort)(value | 0x18));
					cbClockCPU.SelectedIndex = 2;
					break;
			}
		}



		private int ParseForNumber(string input)
		{
			if (input == "")
			{
				return -1;
			}

			// Try to parse the input and figure out what register the user is trying to access
			System.Globalization.NumberStyles numStyle = System.Globalization.NumberStyles.Integer;
			input = cbbRegExRegister.Text.Trim().ToLower().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)[0];
			if (input.Length == 0)
			{
				return -1;
			}
			if (input.StartsWith("0x") || input.StartsWith("&h"))
			{
				input = input.Substring(2);
				numStyle = System.Globalization.NumberStyles.HexNumber;
			}

			int reg = -1;
			while (true)
			{
				try
				{
					reg = int.Parse(input, numStyle);
					break;
				}
				catch
				{
					if (input.Length <= 1)
						break;
					input = input.Substring(0, input.Length - 1);
				}
			}
			return reg;
		}



		private void GrabFrame(Object module)
		{
			QuickUsb.Error qusbError;
			//QuickUsb qusb = quickUsbWinForms.SelectedModule;
            QuickUsb qusb = (QuickUsb) module;
			uint bytes;

			if (qusb == null)
			{
				return;
			}

            //  Grab the new frame
            bytes = m_framesize;
			if (sensorDepthBytes == 1)
			{
                if (!qusb.ReadData(imageBuffer[active ? 1 : 0], ref bytes))
				{
					qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
					return;
				}
			}
			else if (sensorDepthBytes == 2)
			{
                /*
				if (!qusb.ReadData(imageRawData, ref bytes))
				{
					qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
					return;
				}

				for (int k = 0; k < imageBackBuffer.Length; ++k)
				{
					pixel = ((imageRawData[(k * 2) + 1] & 0x0f) << 8) | imageRawData[k * 2];
					imageBackBuffer[k] = (byte)(pixel >> 4);
				}
                */
			}
			else
			{
				return;
			}
        }



		private void Display()
		{
            // Lock the image data so we can write to it
            BitmapData bData = image.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.WriteOnly, PixelFormat.Format8bppIndexed);

            // Copy the backbuffer raw data into the image buffer
            Marshal.Copy(imageBuffer[active ? 0 : 1], 0, bData.Scan0, imageBuffer[active ? 0 : 1].Length);

            // If we're recording video, write the image data to the movie file
			if (recordVideo)
			{
				int result = aviRecorder.RecordFrame(bData);
				if (result != 0)
				{
					MessageBox.Show(this, String.Format("Unable to record video with selected codec (Error: {0})", result), "Video Recording Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					cbVideoRecord.Checked = false;
					recordVideo = false;
				}
			}

            // Unlock the image so it can move around
			image.UnlockBits(bData);

			// Update the PictureBox with the new image data
            pbFrame.Invalidate();
		}
		

		#endregion


		#region Event Handlers


		private void exitToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.Close();
		}



		private void quickUSBFAQToolStripMenuItem_Click(object sender, EventArgs e)
		{
			System.Diagnostics.Process proc = new System.Diagnostics.Process();
			proc.StartInfo.FileName = "iexplore";
			proc.StartInfo.Arguments = "http://www.quickusb.com/index.php?main_page=page&id=5";
			proc.Start();
		}



		private void quickUSBSupportToolStripMenuItem_Click(object sender, EventArgs e)
		{
			System.Diagnostics.Process proc = new System.Diagnostics.Process();
			proc.StartInfo.FileName = "iexplore";
			proc.StartInfo.Arguments = "http://www.quickusb.com/support/my_view_page.php";
			proc.Start();
		}



		private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
		{
			BitwiseSystems.AboutBox about = new BitwiseSystems.AboutBox();
			about.ShowDialog();
		}



		private void QuickUsbImagerLabCs_Load(object sender, EventArgs e)
		{
			tbVideoFile.Text = string.Format("{0}{1}{2}", Directory.GetCurrentDirectory(), Path.DirectorySeparatorChar, "QuickUsbImageLab.avi");
			tbVideoFile.SelectionStart = tbVideoFile.Text.Length;
			tbVideoFile.ScrollToCaret();
		}



		private void cbVideoAcquire_CheckedChanged(object sender, EventArgs e)
		{
			ShowStatusMessage("");

			cbVideoRecord.Enabled = cbVideoAcquire.Checked;
			grabTimer.Enabled = cbVideoAcquire.Checked;
			if (cbVideoAcquire.Checked)
			{
				tStart = Environment.TickCount;
				bytecount = 0;
				grabTimer.Start();
			}
			else
			{
				grabTimer.Stop();
			}
		}



		private void cbClockCPU_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (cbClockCPU.SelectedIndex == 0)
			{
				sensorClockSpeed = SensorClockSpeed.Clock12MHz;
			}
			else if (cbClockCPU.SelectedIndex == 1)
			{
				sensorClockSpeed = SensorClockSpeed.Clock24MHz;
			}
			else if (cbClockCPU.SelectedIndex == 2)
			{
				sensorClockSpeed = SensorClockSpeed.Clock48MHz;
			}
			SetClockSpeed(sensorClockSpeed);
		}



		private void QuickUsbImagerLabCs_FormClosing(object sender, FormClosingEventArgs e)
		{
		}

		void quickUsbWinForms_SelectionChanged(object sender, EventArgs e)
		{
			SensorSelect();
			ValidateHardware();
		}


		private void bVideoBrowse_Click(object sender, EventArgs e)
		{
			using (var diag = new SaveFileDialog())
			{
				diag.Filter = "AVI file type (*.avi)|*.avi";
				if (diag.ShowDialog(this) == DialogResult.OK)
				{
					tbVideoFile.Text = diag.FileName;
					tbVideoFile.SelectionStart = tbVideoFile.Text.Length;
					tbVideoFile.ScrollToCaret();
				}
			}
		}

		private void bLoadSettings_Click(object sender, EventArgs e)
		{
			using (var diag = new OpenFileDialog())
			{
				diag.Filter = "Camera settings file (*.txt)|*.txt";
                //diag.InitialDirectory = Directory.GetCurrentDirectory();
				if (File.Exists(sensorFile))
				{
					diag.FileName = sensorFile;
				}
				else
				{
					diag.FileName = Directory.GetCurrentDirectory();
				}
				if (diag.ShowDialog(this) == DialogResult.OK)
				{
					LoadConfigFile(diag.FileName);
				}
			}
		}



		private void cbbRegExRegister_SelectedIndexChanged(object sender, EventArgs e)
		{
			byte valueByte;
			ushort valueWord;
			int regAddr;

			if (cbbRegExRegister == null)
			{
				return;
			}
			bRegExWrite.Enabled = (cbbRegExRegister.SelectedItem != null);

			// Read sensor register
			regAddr = ParseForNumber(cbbRegExRegister.Text);
			if (regAddr != -1)
			{
				if (sensorRegWidth == 8)
				{
					valueByte = 0;
					if (!ReadSensorReg(sensorAddress, (byte)regAddr, ref valueByte))
					{
						return;
					}

					// Update the BitTwiddler control
					if (btRegExValue.Value != valueByte)
					{
						btRegExValue.Value = (uint)valueByte;
					}
				}
				else
				{
					valueWord = 0;
					if (!ReadSensorReg(sensorAddress, (byte)regAddr, ref valueWord))
					{
						return;
					}

					// Update the BitTwiddler control
					if (btRegExValue.Value != valueWord)
					{
						btRegExValue.Value = (uint)valueWord;
					}
				}
			}
		}



		private void btRegExValue_ValueChanged(object sender, uint btValue)
		{
			// Get the register address
			int regAddr = ParseForNumber(cbbRegExRegister.Text);
			if (regAddr != -1)
			{
				// Write the sensor register
				if (sensorRegWidth == 8)
				{
					WriteSensorReg(sensorAddress, (byte)regAddr, (byte)btValue);
				}
				else
				{
					WriteSensorReg(sensorAddress, (byte)regAddr, (ushort)btValue);
				}
			}
		}



		private void bRegExWrite_Click(object sender, EventArgs e)
		{
			byte value;
			try
			{
				value = byte.Parse(btRegExValue.TextValue, System.Globalization.NumberStyles.HexNumber);
			}
			catch (FormatException)
			{
				MessageBox.Show("Register value must be a valid two-digit (1 byte) hex number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			catch (OverflowException)
			{
				MessageBox.Show("Register value must be a valid two-digit (1 byte) hex number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			// Write the sensor register
			btRegExValue.Value = value;
			btRegExValue_ValueChanged(sender, value);
		}



		private void cbVideoRecord_CheckedChanged(object sender, EventArgs e)
		{
			if (cbVideoRecord.Checked)
			{
				if (tbVideoFile.Text == "")
				{
					MessageBox.Show("Please select a file to save the video to", "Video Capture Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					cbVideoRecord.Checked = false;
					return;
				}
				if (File.Exists(tbVideoFile.Text))
				{
					if (MessageBox.Show("The file you are intending to record to already exists.  Would you like to overwrite it?", "Video Capture", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No)
					{
						cbVideoRecord.Checked = false;
						return;
					}
				}
				aviRecorder = new BmpToAVI.BmpToAVI(this.Handle);
				int result = aviRecorder.Init(tbVideoFile.Text, pbFrame.Width, pbFrame.Height, 15/*(int)maFps.Average*/);
				if (result != 0)
				{
					MessageBox.Show(String.Format("Unable to record video with selected codec (Error: {0})", result), "Video Recording Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					cbVideoRecord.Checked = false;
					return;
				}
				recordVideo = true;
			}
			else
			{
				recordVideo = false;
				if (aviRecorder != null)
				{
					aviRecorder.closeAll();
					aviRecorder = null;
				}
			}
		}



		private void regTimer_Tick(object sender, EventArgs e)
		{
			cbbRegExRegister_SelectedIndexChanged(sender, null);
		}



		private void cbbRegExRegister_TextChanged(object sender, EventArgs e)
		{
			cbbRegExRegister_SelectedIndexChanged(sender, null);
		}



		private void pbFrame_Click(object sender, EventArgs e)
		{
			// Don't try to grab a frame when we're grabbing video
			if (cbVideoAcquire.Checked)
			{
				return;
			}

            // Grab a frame of image data
            GrabFrame(quickUsbWinForms.SelectedModule);

            // Flip data buffers
            active = !active;

            // Display the inactive buffer
            Display();
		}



		private void grabTimer_Tick(object sender, EventArgs e)
		{
            // Create the two operating threads
            Thread grab = new Thread(GrabFrame);
            Thread show = new Thread(Display);

            // Start the acquisition and display at the same time
            grab.Start(quickUsbWinForms.SelectedModule);
            show.Start();

			// Track the FPS, bytes read, and data rate
			t2 = Environment.TickCount;
            float secs = (float) (t2 - t1) / 1000.0f;
            frameRateToolStripStatusLabel.Text = String.Format("FPS: {0:0.00} Hz", 1.0f / secs);
			t1 = t2;

            bytecount += m_framesize;
            float dataread = ((float) bytecount) / MB;
            if (dataread < 1024)
			{
                dataReadToolStripStatusLabel.Text = String.Format("Data Read: {0:0.00} MB", dataread);
			}
			else
			{
                dataReadToolStripStatusLabel.Text = String.Format("Data Read: {0:0.00} GB", dataread / 1024.0f);
			}

            dataRateToolStripStatusLabel.Text = String.Format("Data Rate: {0:0.00} MB/s", (m_framesize / MB) / secs);

            // Wait for both threads to expire
            while (grab.IsAlive || show.IsAlive)
                ;

            // Flip data buffers
            active = !active;
		}

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pbFrame.Image.Save("snap.jpg", ImageFormat.Jpeg);
        }


		#endregion
	}


	/*
	class movingAverage
	{
		float[] samples;
		int lastSample = 0, numSamples = 0;
		float sum;


		#region Public Methods


		public movingAverage(int maxSamples)
		{
			samples = new float[maxSamples];
		}



		public void reset()
		{
			numSamples = 0;
			samples.Initialize();
		}



		public void addSample(float value)
		{
			sum -= samples[lastSample];
			samples[lastSample] = value;
			sum += value;

			if (++lastSample == samples.Length)
			{
				lastSample = 0;
			}

			++numSamples;
		}



		public float Average
		{
			get
			{
				if (numSamples == 0)
				{
					return 0.0f;
				}
				else if (numSamples < samples.Length)
				{
					return sum / numSamples;
				}
				else
				{
					return sum / samples.Length;
				}
			}
		}


		#endregion


		#region Static Methods


		public static int ParseNumber(string x)
		{
			int value, numbase = 10;
			if (x.ToLower().StartsWith("&h") || x.ToLower().StartsWith("0x"))
			{
				numbase = 16;
				x = x.Substring(2, x.Length - 2);
			}
			value = Convert.ToInt32(x, numbase);
			return value;
		}


		#endregion
	}*/
}
