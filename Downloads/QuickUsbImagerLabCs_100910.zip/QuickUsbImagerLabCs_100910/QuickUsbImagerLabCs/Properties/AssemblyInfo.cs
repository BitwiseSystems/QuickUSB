﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("QuickUsbImagerLabCs")]
[assembly: AssemblyDescription("QuickUSB ImagerLab")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Bitwise Systems")]
[assembly: AssemblyProduct("QuickUsbImagerLabCs")]
[assembly: AssemblyCopyright("Copyright © 2010 Bitwise Systems")]
[assembly: AssemblyTrademark("QuickUSB®")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(true)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("8f12ba7f-8663-4e2f-bddf-d5a9363d3cd0")]

// Version information for an assembly consists of the following four values:
//
//	  Major Version
//	  Minor Version 
//	  Build Number
//	  Revision
//
[assembly: AssemblyVersion("2.20.0.0")]
[assembly: AssemblyFileVersion("2.20.0.0")]
