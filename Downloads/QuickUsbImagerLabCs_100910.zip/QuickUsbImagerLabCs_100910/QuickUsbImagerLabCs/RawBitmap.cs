// RawBitmap.cs originally written by Harry Fairhead
// Hosted on: http://www.i-programmer.info/projects/38-windows/220-bitmaps-into-videos.html
// Edited by Bitwise Systems

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.IO;

namespace BmpToAVI
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct BITMAPFILEHEADER
	{
		public Int16 bfType;
		public Int32 bfSize;
		public Int16 bfReserved1;
		public Int16 bfReserved2;
		public Int32 bfOffBits;
	};

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct BITMAPINFOHEADER
	{
		public int biSize;
		public int biWidth;
		public int biHeight;
		public short biPlanes;
		public short biBitCount;
		public int biCompression;
		public int biSizeImage;
		public int biXPelsPerMeter;
		public int biYPelsPerMeter;
		public int biClrUsed;
		public int biClrImportant;
	};

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct BITMAP_RGBQUAD
	{
		public byte blue;
		public byte green;
		public byte red;
		byte reserved;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct BITMAPINFO
	{
		public BITMAPINFOHEADER bmIH;
		[MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
		public BITMAP_RGBQUAD[] bmColors;
	}

	class RawBitmap
	{
		public BITMAPFILEHEADER bmFH = new BITMAPFILEHEADER();
		public BITMAPINFOHEADER bmIH = new BITMAPINFOHEADER();
		public byte[] bits;
		public void LoadFromFile(string filename)
		{
		FileStream fs = new FileStream(
			filename,
			FileMode.Open,
			FileAccess.Read);
		bmFH = (BITMAPFILEHEADER) ReadStruct(fs, typeof(BITMAPFILEHEADER));
		bmIH = (BITMAPINFOHEADER)ReadStruct(fs, typeof(BITMAPINFOHEADER));
				 
		fs.Position = bmFH.bfOffBits;
		bits = new byte[bmIH.biSizeImage];
		fs.Read(
			bits,
			0,
			bits.GetLength(0));
		fs.Close();
		}
		private object ReadStruct(FileStream fs, Type t)
		{
			byte[] buffer = new byte[Marshal.SizeOf(t)];
			fs.Read(
			  buffer,
			  0,
			  Marshal.SizeOf(t));
			GCHandle handle = GCHandle.Alloc(
				buffer,
				GCHandleType.Pinned);

			Object temp = Marshal.PtrToStructure(
				handle.AddrOfPinnedObject(),t);
			handle.Free();
			return temp;
		}
	}
}
