﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;

namespace BitwiseSystems
{
	class ImagerLabSensor
	{
		const byte ILAB_RESET = 0x08;
		const float MB = 1024.0f * 1024.0f;

		public enum SensorClockSpeed
		{
			Clock12MHz = 0,
			Clock24MHz = 1,
			Clock48MHz = 3,
		}

		// Instance variables		
		SensorClockSpeed sensorClockSpeed;
		byte sensorAddress;
		byte sensorDepthBytes = 2;
		byte sensorRegWidth = 8;
		bool sensorUseCachedWrite = false;
		bool sensorResetActiveHigh;
		string sensorFile;

		ushort m_rows = 480;
		ushort m_cols = 640;

		public void EnableSensor(QuickUsb qusb, bool enable, bool resetActiveHigh)
		{
			if (qusb == null)
			{
				return;
			}

			ushort length;
			byte[] buffer = new byte[1];
			QuickUsb.Error qusbError;

			length = 1;
			if (!qusb.ReadPort((ushort)QuickUsb.Port.PORT_A, buffer, ref length))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				return;
			}
			if ((enable && !resetActiveHigh) || (!enable && resetActiveHigh))
			{
				buffer[0] |= ILAB_RESET;
			}
			else
			{
				buffer[0] &= unchecked((byte)~ILAB_RESET);
			}
			if (!qusb.WritePort((ushort)QuickUsb.Port.PORT_A, buffer, 1))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				return;
			}
			Thread.Sleep(50);
		}



		public void ResetSensor(QuickUsb qusb, bool resetActiveHigh)
		{
			EnableSensor(qusb, false, resetActiveHigh);
			EnableSensor(qusb, true, resetActiveHigh);
		}



		private void InitLumaView(QuickUsb qusb)
		{
			byte portVal = 0, regVal = 0;

			//Private Sub InitLumaView()
			//   Dim portVal As Byte
			//   Dim regVal As Byte

			//   '== Configure the LumaView ==
			//   ' Set the I/O ports direction
			//   QuickUsbCtl.WritePortDir 3, &H3F
			//   Sleep 10
			qusb.WritePortDir(QuickUsb.Port.D, 0x3f);
			Thread.Sleep(10);

			//   ' Turn on port D bits in sequence
			//   portVal = &H28
			//   QuickUsbCtl.WritePort 3, portVal
			//   Sleep 10
			portVal = 0x28;
			qusb.WritePort(QuickUsb.Port.D, portVal);
			Thread.Sleep(10);

			//   portVal = portVal Or &H1      ' Set D0
			//   QuickUsbCtl.WritePort 3, portVal
			//   Sleep 10
			portVal |= 0x01;
			qusb.WritePort(QuickUsb.Port.D, portVal);
			Thread.Sleep(10);

			//   portVal = portVal Or &H2      ' Set D1
			//   QuickUsbCtl.WritePort 3, portVal
			//   Sleep 10
			portVal |= 0x02;
			qusb.WritePort(QuickUsb.Port.D, portVal);
			Thread.Sleep(10);

			//   ' Tell the sensor to turn off it's onboard regulator
			//   ReadSensorRegByte &H60, &H63, regVal, COM_I2C
			//   Sleep 10
			//   regVal = regVal Or &H4
			//   WriteSensorRegByte &H61, &H63, regVal, COM_I2C
			//   Sleep 10

			ReadSensorReg(qusb, sensorAddress, 0x63, ref regVal);
			Thread.Sleep(10);
			regVal |= 0x04;
			WriteSensorReg(qusb, sensorAddress, 0x63, regVal);
			Thread.Sleep(10);

			//   portVal = portVal Or &H4      ' Set D2
			//   QuickUsbCtl.WritePort 3, portVal
			//   Sleep 10
			portVal |= 0x04;
			qusb.WritePort(QuickUsb.Port.D, portVal);
			Thread.Sleep(10);

			//   portVal = portVal And &HDF    ' Clear D.5
			//   QuickUsbCtl.WritePort 3, portVal
			//   Sleep 10
			portVal &= 0xDF;
			qusb.WritePort(QuickUsb.Port.D, portVal);
			Thread.Sleep(10);

			//   portVal = portVal And &HF7    ' Clear D.3
			//   QuickUsbCtl.WritePort 3, portVal
			//   Sleep 10
			portVal &= 0xF7;
			qusb.WritePort(QuickUsb.Port.D, portVal);
			Thread.Sleep(10);

			//   portVal = portVal Or &H8      ' Set D3 to take the sensor out of reset
			//   QuickUsbCtl.WritePort 3, portVal
			//   Sleep 10
			//End Sub
			portVal |= 0x08;
			qusb.WritePort(QuickUsb.Port.D, portVal);
			Thread.Sleep(10);
		}
		private void SensorSelect(QuickUsb qusb)
		{
			if (qusb == null)
			{
				return;
			}

			qusb.SetTimeout(2000);

			byte valueByte;
			ushort valueWord;
			string sensorType = "";
			ushort setting;
			QuickUsb.Error qusbError;
			ushort length;

			byte[] buffer = new byte[3];

			bool foundSensor;
			byte[] i2cAddr;


			// Disable IFCLK drive
			if (!qusb.ReadSetting(QuickUsb.Setting.FifoConfig, out setting))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				return;
			}
			setting &= 0xFFDF; // IFCLKOE = tri-state (0xFFDF = ~0x20)
			setting |= 0x0002; // IFCFG = GPIF Master Mode
			if (!qusb.WriteSetting(QuickUsb.Setting.FifoConfig, setting))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				return;
			}

			// Configure PA[5..0] to default values
			length = 1;
			if (!qusb.ReadPort((ushort)QuickUsb.Port.PORT_A, buffer, ref length))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				return;
			}
			buffer[0] &= 0xC0; // nRESET = 0)
			if (!qusb.WritePort((ushort)QuickUsb.Port.PORT_A, buffer, 1))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				return;
			}

			// Configure PA[5..0] to be outputs
			length = 1;
			if (!qusb.ReadPortDir((ushort)QuickUsb.Port.PORT_A, out valueByte))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				return;
			}
			valueByte |= 0x3F;
			if (!qusb.WritePortDir((ushort)QuickUsb.Port.PORT_A, valueByte))
			{
				// Error
				qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
				return;
			}

			// Just in case we have a 'LumaView' connected....
			InitLumaView(qusb);

			// Set the clock speed to 24 MHz
			//SetClockSpeed(SensorClockSpeed.Clock48MHz);


			// We don't know if the reset line is active high or active low, so we must try both
			foundSensor = false;
			i2cAddr = new byte[] { 0x60, (0xBA >> 1) };
			foreach (bool resetActiveHigh in new bool[] { false, true })
			{
				// Reset the sensor
				ResetSensor(qusb, resetActiveHigh);
				sensorResetActiveHigh = resetActiveHigh;

				// Loop through all I2C addresses
				for (int addr = 0; addr < 0xff; addr += 2)
				{
					// Disregard reserved I2C addresses
					if ((addr & 0x7f) == 81)
					{
						continue;
					}

					// Scan for Omnivision sensors
					valueByte = 0xff;
					sensorUseCachedWrite = false;
					if (!ReadSensorReg(qusb, (byte)addr, 0x0A, ref valueByte))
					{
						break;
					}

					switch (valueByte)
					{
						case 0x76:
							sensorType = "OV7640/OV7141";
							sensorAddress = (byte)addr;
							sensorFile = Directory.GetCurrentDirectory() + @"\..\..\Sensors\ov7141.txt";
							sensorDepthBytes = 1;
							sensorClockSpeed = SensorClockSpeed.Clock24MHz;
							sensorRegWidth = 8;
							sensorDepthBytes = 1;
							foundSensor = true;
							break;
						case 0x96:
							sensorType = "OV9620/OV9121";
							sensorAddress = (byte)addr;
							sensorFile = Directory.GetCurrentDirectory() + @"\..\..\Sensors\ov9121.txt";
							sensorDepthBytes = 1;
							sensorClockSpeed = SensorClockSpeed.Clock24MHz;
							sensorRegWidth = 8;
							sensorDepthBytes = 1;
							foundSensor = true;
							break;
						case 0x97:
							sensorType = "OV9715/OV9215";
							sensorAddress = (byte)addr;
							sensorFile = Directory.GetCurrentDirectory() + @"\..\..\Sensors\ov9215.txt";
							sensorDepthBytes = 1;
							sensorClockSpeed = SensorClockSpeed.Clock24MHz;
							sensorRegWidth = 8;
							sensorDepthBytes = 1;
							foundSensor = true;
							break;
						default:
							break;
					}
					if (foundSensor)
					{
						break;
					}

					// Scan for Micron sensors
					sensorUseCachedWrite = true;
					valueWord = 0xffff;
					if (!ReadSensorReg(qusb, (byte)addr, 0, ref valueWord))
					{
						break;
					}

					/*length = 1;
					buffer[0] = 0x00; // Register address: Chip version
					if (!qusb.WriteI2C((ushort)(addr | (length << 8)), buffer, length)) // Cached write of 1 byte
					{
						continue;
					}
					length = 2;
					if (!qusb.ReadI2C(addr, buffer, ref length))
					{
						continue;
					}*/
					//switch ((buffer[0] << 8) | buffer[1])

					switch (valueWord)
					{
						case 0x1801:// MT9P401
							sensorType = "MT9P401";
							sensorAddress = (byte)addr;
							sensorFile = Directory.GetCurrentDirectory() + @"\..\..\Sensors\MT9P401.txt";
							sensorDepthBytes = 2;
							sensorClockSpeed = SensorClockSpeed.Clock12MHz;
							sensorRegWidth = 16;
							foundSensor = true;
							break;
					}


					if (foundSensor)
					{
						break;
					}
				}


				if (foundSensor)
				{
					break;
				}
			}

			// Configure the identified sensor
			if (foundSensor)
			{
				SetClockSpeed(qusb, sensorClockSpeed);
				LoadConfigFile(qusb, sensorFile);
			}
		}



		public bool LoadConfigFile(QuickUsb qusb, string fileName)
		{
			if (!File.Exists(fileName))
			{
				return false;
			}

			using (StreamReader fin = new StreamReader(fileName))
			{
				string line;
				string[] tokens;
				while ((line = fin.ReadLine()) != null)
				{
					if (line.Contains(";"))
					{
						line = line.Split(';')[0];
					}
					tokens = line.Trim().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
					if (tokens.Length == 0)
					{
						continue;
					}

					switch (tokens[0].ToLower())
					{
						case "rows":
							m_rows = ushort.Parse(tokens[1]);
							break;
						case "cols":
							m_cols = ushort.Parse(tokens[1]);
							break;
						case "depth":
							sensorDepthBytes = (byte)((Convert.ToInt32(tokens[1]) <= 8) ? 1 : 2);
							break;
						case "reg":
							// Add the register definition to the combobox
							break;
						case "regwidth":
							sensorRegWidth = (Convert.ToInt32(tokens[1]) <= 8) ? (byte)8 : (byte)16;
							break;
						case "i2ccachedwrite":
							sensorUseCachedWrite = (Convert.ToInt32(tokens[1]) == 0) ? false : true;
							break;
						default:
							// Execute sensor "boot code"
							if (tokens.Length == 3 && byte.Parse(tokens[0], System.Globalization.NumberStyles.HexNumber) == sensorAddress)
							{
								if (sensorRegWidth == 8)
								{
									if (!WriteSensorReg(qusb, byte.Parse(tokens[0], System.Globalization.NumberStyles.HexNumber),
														byte.Parse(tokens[1], System.Globalization.NumberStyles.HexNumber),
														byte.Parse(tokens[2], System.Globalization.NumberStyles.HexNumber)))
									{
										return false;
									}
								}
								else if (sensorRegWidth == 16)
								{
									if (!WriteSensorReg(qusb, byte.Parse(tokens[0], System.Globalization.NumberStyles.HexNumber),
														byte.Parse(tokens[1], System.Globalization.NumberStyles.HexNumber),
														ushort.Parse(tokens[2], System.Globalization.NumberStyles.HexNumber)))
									{
										return false;
									}
								}
								else
								{
									return false;
								}
							}
							else
							{
								return false;
							}
							break;
					}
				}
			}

			return true;
		}



		public bool ReadSensorReg(QuickUsb qusb, byte sensorAddr, byte regAddr, ref byte value)
		{
			if (qusb == null)
			{
				return false;
			}

			bool result;
			byte[] data = new byte[2] { regAddr, 0 };
			ushort length;

			length = 1;
			result = qusb.WriteI2C((ushort)(sensorAddr >> 1), data, length);
			result &= qusb.ReadI2C((ushort)(sensorAddr >> 1), data, ref length);

			value = result ? data[0] : (byte)0xff;

			return result;
		}



		public bool ReadSensorReg(QuickUsb qusb, byte sensorAddr, byte regAddr, ref ushort value)
		{
			if (qusb == null)
			{
				return false;
			}

			bool result;
			byte[] data = new byte[2] { regAddr, 0 };
			ushort length;

			length = 1;
			if (sensorUseCachedWrite)
			{
				result = qusb.WriteI2C((ushort)((sensorAddr >> 1) | (length << 8)), data, length);
				length = 2;
				result &= qusb.ReadI2C((ushort)(sensorAddr >> 1), data, ref length);
			}
			else
			{
				result = qusb.WriteI2C((ushort)(sensorAddr >> 1), data, length);
				length = 2;
				result &= qusb.ReadI2C((ushort)(sensorAddr >> 1), data, ref length);
			}

			value = (ushort)(result ? ((data[0] << 8) | data[1]) : 0xffff);

			return result;
		}



		public bool WriteSensorReg(QuickUsb qusb, byte sensorAddr, byte regAddr, byte value)
		{
			if (qusb == null)
			{
				return false;
			}

			return qusb.WriteI2C((ushort)(sensorAddr >> 1), new byte[] { regAddr, value }, 2);
		}



		public bool WriteSensorReg(QuickUsb qusb, byte sensorAddr, byte regAddr, ushort value)
		{
			if (qusb == null)
			{
				return false;
			}

			return qusb.WriteI2C((ushort)(sensorAddr >> 1), new byte[] { regAddr, (byte)((value >> 8) & 0xff), (byte)(value & 0xff) }, 3);
		}



		public void SetClockSpeed(QuickUsb qusb, SensorClockSpeed clock)
		{
			if (qusb == null)
			{
				return;
			}

			ushort value = 0;
			if (!qusb.ReadSetting(QuickUsb.Setting.CpuConfig, out value))
			{
				return;
			}

			switch (clock)
			{
				case SensorClockSpeed.Clock12MHz:
					qusb.WriteSetting(QuickUsb.Setting.CpuConfig, (ushort)(value & ~0x18));
					break;
				case SensorClockSpeed.Clock24MHz:
					qusb.WriteSetting(QuickUsb.Setting.CpuConfig, (ushort)((value & ~0x18) | 0x08));
					break;
				case SensorClockSpeed.Clock48MHz:
					qusb.WriteSetting(QuickUsb.Setting.CpuConfig, (ushort)(value | 0x18));
					break;
			}
		}



		private void GrabFrame(QuickUsb qusb, byte[] data, uint frameSize)
		{
			QuickUsb.Error qusbError;
			uint bytes;

			if (qusb == null)
			{
				return;
			}

			//  Grab the new frame
			bytes = frameSize;
			if (sensorDepthBytes == 1)
			{
				if (!qusb.ReadData(data, ref bytes))
				{
					qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
					return;
				}
			}
			else if (sensorDepthBytes == 2)
			{
				/*
				if (!qusb.ReadData(imageRawData, ref bytes))
				{
					qusbError = (QuickUsb.Error)QuickUsb.GetLastError();
					return;
				}

				for (int k = 0; k < imageBackBuffer.Length; ++k)
				{
					pixel = ((imageRawData[(k * 2) + 1] & 0x0f) << 8) | imageRawData[k * 2];
					imageBackBuffer[k] = (byte)(pixel >> 4);
				}
				*/
			}
			else
			{
				return;
			}
		}
	}
}
