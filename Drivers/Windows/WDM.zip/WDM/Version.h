#ifndef	VERSION_INCLUDED
#define	VERSION_INCLUDED

//////////////////////////////////////////////////////////////////////
//
// File:      version.h
// $Archive: /Projects/Bitwise/QuickUSB/Library/Driver/Version.h $
//
// Purpose:
//    Version information header file for EZ-USB General Purpose Driver
//
// Environment:
//    kernel mode
//
// $Author: Blake Henry $
//
//  
// Copyright (c) 1997 Anchor Chips, Inc.  May not be reproduced without
// permission.  See the license agreement for more details.
//
//////////////////////////////////////////////////////////////////////

//
// Make sure to keep these in sync with the version
// information in ezusbsys.rc
//
#define EZUSB_MAJOR_VERSION		02
#define EZUSB_MINOR_VERSION		14
#define EZUSB_BUILD_VERSION		02

#endif	//	VERSION_INCLUDED

